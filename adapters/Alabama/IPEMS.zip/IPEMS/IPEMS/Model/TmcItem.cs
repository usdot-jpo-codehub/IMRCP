﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPEMS.Model
{
  public partial class TmcItem : ModelBase
  {
    public string rw_li { get; set; }
    public string rw_de { get; set; }
    public DateTime? rw_pbt { get; set; }
    public string tmc_pc { get; set; }
    public string tmc_de { get; set; }
    public string cf_ty { get; set; }
    public decimal? cf_sp { get; set; }
    public decimal? cf_su { get; set; }
    public decimal? cf_ff { get; set; }
    public decimal? cf_jf { get; set; }
    public decimal? cf_cn { get; set; }
    public string cf_ts { get; set; }
    public decimal? ss_le { get; set; }
    public decimal? ss_sp { get; set; }
    public decimal? ss_su { get; set; }
    public decimal? ss_ff { get; set; }
    public decimal? ss_jf { get; set; }
    public string ss_ts { get; set; }
  }
}
