﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IPEMS.Model
{
  public partial class TmcItem : ModelBase
  {
    internal override async Task<bool> InsertAsync(SqlConnection conn)
    {
      bool result = false;
      string query = "INSERT INTO TmcItems " +
        "(RW_LI, RW_DE, RW_PBT, TMC_PC, TMC_DE, CF_TY, CF_SP, CF_SU, CF_FF, CF_JF, CF_CN, CF_TS, SS_LE, SS_SP, SS_SU, SS_FF, SS_JF, SS_TS) " +
        "VALUES " +
        "(@rw_li, @rw_de, @rw_pbt, @tmc_pc, @tmc_de, @cf_ty, @cf_sp, @cf_su, @cf_ff, @cf_jf, @cf_cn, @cf_ts, @ss_le, @ss_sp, @ss_su, @ss_ff, @ss_jf, @ss_ts); " +
        "SELECT CAST(SCOPE_IDENTITY() AS INT) ID";

      SqlCommand cmd = new SqlCommand(query, conn);
      cmd.Parameters.AddWithValue("@rw_li", rw_li == null ? DBNull.Value : (object)rw_li);
      cmd.Parameters.AddWithValue("@rw_de", rw_de == null ? DBNull.Value : (object)rw_de);
      cmd.Parameters.AddWithValue("@rw_pbt", rw_pbt == null ? DBNull.Value : (object)rw_pbt);
      cmd.Parameters.AddWithValue("@tmc_pc", tmc_pc == null ? DBNull.Value : (object)tmc_pc);
      cmd.Parameters.AddWithValue("@tmc_de", tmc_de == null ? DBNull.Value : (object)tmc_de);
      cmd.Parameters.AddWithValue("@cf_ty", cf_ty == null ? DBNull.Value : (object)cf_ty);
      cmd.Parameters.AddWithValue("@cf_sp", cf_sp == null ? DBNull.Value : (object)cf_sp);
      cmd.Parameters.AddWithValue("@cf_su", cf_su == null ? DBNull.Value : (object)cf_su);
      cmd.Parameters.AddWithValue("@cf_ff", cf_ff == null ? DBNull.Value : (object)cf_ff);
      cmd.Parameters.AddWithValue("@cf_jf", cf_jf == null ? DBNull.Value : (object)cf_jf);
      cmd.Parameters.AddWithValue("@cf_cn", cf_cn == null ? DBNull.Value : (object)cf_cn);
      cmd.Parameters.AddWithValue("@cf_ts", cf_ts == null ? DBNull.Value : (object)cf_ts);
      cmd.Parameters.AddWithValue("@ss_le", ss_le == null ? DBNull.Value : (object)ss_le);
      cmd.Parameters.AddWithValue("@ss_sp", ss_sp == null ? DBNull.Value : (object)ss_sp);
      cmd.Parameters.AddWithValue("@ss_su", ss_su == null ? DBNull.Value : (object)ss_su);
      cmd.Parameters.AddWithValue("@ss_ff", ss_ff == null ? DBNull.Value : (object)ss_ff);
      cmd.Parameters.AddWithValue("@ss_jf", ss_jf == null ? DBNull.Value : (object)ss_jf);
      cmd.Parameters.AddWithValue("@ss_ts", ss_ts == null ? DBNull.Value : (object)ss_ts);

      ID = (int)await cmd.ExecuteScalarAsync();

      return result;
    }
  }
}
