﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

using IPEMS.Model;

namespace IPEMS
{
  class Program
  {
    //static void Main(string[] args)
    //{
    //  string url = "http://mlrealtime.traffic.data.here.com/ver3.2.2/tableA0101/RealtimeFlowA0101.xml.gz";
    //  string destFile = "RealtimeFlowA0101.xml.gz";
    //  string domain = "mlrealtime.traffic.data.here.com";
    //  string username = "alabamadot";
    //  string password = "yI-472nn";

    //  NetworkCredential credential = new NetworkCredential() { UserName = username, Password = password };
    //  WebClient client = new WebClient();
    //  client.UseDefaultCredentials = false;
    //  client.Credentials = credential;
    //  client.DownloadFile(url, destFile);
    //}

    //static void Main(string[] args)
    //{
    //  string destFile = "RealtimeFlowA0101.xml.gz";
    //  string processPath = "C:\\Program Files\\7-Zip\\7z.exe";
    //  string processParams = string.Format("x {0}", destFile);

    //  Process.Start(processPath, processParams);
    //}

    static void Main(string[] args)
    {
      DateTime start = DateTime.Now;

      Task.WaitAll(new Task[] { Process() });

      Console.WriteLine(string.Format("Total time elapsed: {0}", (DateTime.Now - start).ToString()));
      Console.Write("Press enter to finish");
      Console.ReadLine();
    }

    private static async Task Process()
    {
      string targFile = "RealtimeFlowA0101.xml";
      List<TmcItem> result = new List<TmcItem>();

      XmlDocument doc = new XmlDocument();
      doc.Load(targFile);

      XmlNamespaceManager mgr = new XmlNamespaceManager(doc.NameTable);
      mgr.AddNamespace("x", doc.DocumentElement.NamespaceURI);

      XmlNodeList rwsList = doc.DocumentElement.SelectNodes("//x:RWS[@TY=\"TMC\"]", mgr);

      DateTime dt;
      int i;
      decimal d;

      foreach (XmlNode rws in rwsList)
      {
        TmcItem currentItem = null;
        XmlNodeList rwList = rws.SelectNodes("x:RW", mgr);
        foreach (XmlNode rw in rwList)
        {
          string rw_li, rw_de, rw_pbts;
          DateTime? rw_pbt;

          XmlElement rwe = (XmlElement)rw;
          rw_li = rwe.HasAttribute("LI") ? rwe.Attributes["LI"].Value : null;
          rw_de = rwe.HasAttribute("DE") ? rwe.Attributes["DE"].Value : null;
          rw_pbts = rwe.HasAttribute("PBT") ? rwe.Attributes["PBT"].Value : null;
          rw_pbt = DateTime.TryParse(rw_pbts, out dt) ? dt : (DateTime?)null;

          XmlNodeList fiList = rw.SelectNodes("descendant::x:FI", mgr);
          foreach (XmlNode fi in fiList)
          {
            string tmc_pc, tmc_de, cf_ty, cf_sps, cf_sus, cf_ffs, cf_jfs, cf_cns, cf_ts;
            decimal? cf_sp, cf_su, cf_ff, cf_jf, cf_cn;

            XmlElement tmc = fi.SelectSingleNode("x:TMC", mgr) as XmlElement;
            if (tmc != null)
            {
              tmc_pc = tmc.HasAttribute("PC") ? tmc.Attributes["PC"].Value : null;
              tmc_de = tmc.HasAttribute("DE") ? tmc.Attributes["DE"].Value : null;
            }
            else
            {
              tmc_pc = tmc_de = null;
            }

            XmlElement cf = fi.SelectSingleNode("x:CF", mgr) as XmlElement;
            if (cf != null)
            {
              cf_ty = cf.HasAttribute("TY") ? cf.Attributes["TY"].Value : null;
              cf_sps = cf.HasAttribute("SP") ? cf.Attributes["SP"].Value : null;
              cf_sp = decimal.TryParse(cf_sps, out d) ? d : (decimal?)null;
              cf_sus = cf.HasAttribute("SU") ? cf.Attributes["SU"].Value : null;
              cf_su = decimal.TryParse(cf_sus, out d) ? d : (decimal?)null;
              cf_ffs = cf.HasAttribute("FF") ? cf.Attributes["FF"].Value : null;
              cf_ff = decimal.TryParse(cf_ffs, out d) ? d : (decimal?)null;
              cf_jfs = cf.HasAttribute("JF") ? cf.Attributes["JF"].Value : null;
              cf_jf = decimal.TryParse(cf_jfs, out d) ? d : (decimal?)null;
              cf_cns = cf.HasAttribute("CN") ? cf.Attributes["CN"].Value : null;
              cf_cn = decimal.TryParse(cf_cns, out d) ? d : (decimal?)null;
              cf_ts = cf.HasAttribute("TS") ? cf.Attributes["TS"].Value : null;

              XmlNodeList ssList = cf.SelectNodes("descendant::x:SS", mgr);
              if (ssList.Count > 0)
              {
                foreach (XmlNode ss in ssList)
                {
                  string ss_les, ss_sps, ss_sus, ss_ffs, ss_jfs, ss_ts;
                  decimal? ss_le, ss_sp, ss_su, ss_ff, ss_jf;

                  XmlElement sse = (XmlElement)ss;
                  ss_les = sse.HasAttribute("LE") ? sse.Attributes["LE"].Value : null;
                  ss_le = decimal.TryParse(ss_les, out d) ? d : (decimal?)null;
                  ss_sps = sse.HasAttribute("SP") ? sse.Attributes["SP"].Value : null;
                  ss_sp = decimal.TryParse(ss_sps, out d) ? d : (decimal?)null;
                  ss_sus = sse.HasAttribute("SU") ? sse.Attributes["SU"].Value : null;
                  ss_su = decimal.TryParse(ss_sus, out d) ? d : (decimal?)null;
                  ss_ffs = sse.HasAttribute("FF") ? sse.Attributes["FF"].Value : null;
                  ss_ff = decimal.TryParse(ss_ffs, out d) ? d : (decimal?)null;
                  ss_jfs = sse.HasAttribute("JF") ? sse.Attributes["JF"].Value : null;
                  ss_jf = decimal.TryParse(ss_jfs, out d) ? d : (decimal?)null;
                  ss_ts = sse.HasAttribute("TS") ? sse.Attributes["TS"].Value : null;

                  currentItem = new TmcItem()
                  {
                    rw_li = rw_li,
                    rw_de = rw_de,
                    rw_pbt = rw_pbt,
                    tmc_pc = tmc_pc,
                    tmc_de = tmc_de,
                    cf_ty = cf_ty,
                    cf_sp = cf_sp,
                    cf_su = cf_su,
                    cf_ff = cf_ff,
                    cf_jf = cf_jf,
                    cf_cn = cf_cn,
                    cf_ts = cf_ts,
                    ss_le = ss_le,
                    ss_sp = ss_sp,
                    ss_su = ss_su,
                    ss_ff = ss_ff,
                    ss_jf = ss_jf,
                    ss_ts = ss_ts
                  };

                  //result.Add(currentItem);
                  await currentItem.InsertAsync();
                }
              }
              else
              {
                currentItem = new TmcItem()
                {
                  rw_li = rw_li,
                  rw_de = rw_de,
                  rw_pbt = rw_pbt,
                  tmc_pc = tmc_pc,
                  tmc_de = tmc_de,
                  cf_ty = cf_ty,
                  cf_sp = cf_sp,
                  cf_su = cf_su,
                  cf_ff = cf_ff,
                  cf_jf = cf_jf,
                  cf_cn = cf_cn,
                  cf_ts = cf_ts,
                  ss_le = null,
                  ss_sp = null,
                  ss_su = null,
                  ss_ff = null,
                  ss_jf = null,
                  ss_ts = null
                };

                //result.Add(currentItem);
                await currentItem.InsertAsync();
              }
            }
          }
        }
      }
    }
  }
}
