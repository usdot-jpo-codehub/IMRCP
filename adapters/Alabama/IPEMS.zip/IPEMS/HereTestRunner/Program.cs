﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using HereDataImport.Process;

namespace HereTestRunner
{
  class Program
  {
    static void Main(string[] args)
    {
      DataImportController _controller = new DataImportController();
      Thread _controllerThread = new Thread(new ThreadStart(_controller.Process));
      _controllerThread.Start();
    }
  }
}
