﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using NLog;

using HereDataImport.Process;

namespace HereDataService
{
  public partial class HereService : ServiceBase
  {
    Logger _log;
    DataImportController _controller;
    Thread _controllerThread;

    public HereService()
    {
      InitializeComponent();

      _log = LogManager.GetLogger(this.GetType().Name);

      CanStop = true;
      CanShutdown = true;
    }

    #region Action command handlers

    protected override void OnStart(string[] args)
    {
      try
      {
        _log.Info("Starting service...\r\n=====================================================================================\r\n");

        _controller = new DataImportController();
        _controllerThread = new Thread(new ThreadStart(_controller.Process));
        _controllerThread.Start();
      }
      catch (Exception ex)
      {
        _log.Error(string.Format("OnStart, {0}: {1}\r\n{2}", ex.GetType().Name, ex.Message, ex.StackTrace));
      }
    }

    protected override void OnStop()
    {
      try
      {
        _log.Info("Stop service pending...\r\n=====================================================================================\r\n");
        _controller.Stop();
        while (_controllerThread.ThreadState == System.Threading.ThreadState.Running)
        {
          RequestAdditionalTime(10000);
          Thread.Sleep(5000);
        }
        _log.Info("Service stopped...\r\n=====================================================================================\r\n");
      }
      catch (Exception ex)
      {
        _log.Error(string.Format("OnStop, {0}: {1}\r\n{2}", ex.GetType().Name, ex.Message, ex.StackTrace));
      }
    }

    protected override void OnShutdown()
    {
      try
      {
        _log.Info("Service shutdown pending...\r\n=====================================================================================\r\n");
        _controller.Shutdown();
        _log.Info("Service shutdown complete...\r\n=====================================================================================\r\n");

        base.OnShutdown();
      }
      catch(Exception ex)
      {
        _log.Error(string.Format("OnShutdown, {0}: {1}\r\n{2}", ex.GetType().Name, ex.Message, ex.StackTrace));
      }
    }

    #endregion
  }
}
