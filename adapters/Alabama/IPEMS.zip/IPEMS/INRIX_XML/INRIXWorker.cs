﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace INRIX_XML
{
    public class INRIXWorker
    {
        static string LOG_LOCATION = @"D:\Logs\INRIX_XML_Ingester";

        public static void Ingest()
        {
            File.AppendAllText(LOG_LOCATION + @"\" + DateTime.Now.ToString("yyyy_MM_dd") + ".log",
                    "Starting job >>> " + DateTime.Now.ToString("yyyy_MM_dd HH:mm:ss") + "\n");

            // this is the URL that we go to to fetch our INRIX token 
            string tokenURL = "http://api.inrix.com/Traffic/Inrix.ashx?action=getsecuritytoken&Vendorid=2109059254&consumerid=d3894b51-576c-43cc-a836-00e2d4514cc0";

            // calling a web request using the URL provided
            WebRequest request = WebRequest.Create(tokenURL);

            // grabbing the response from the request object's function
            WebResponse response = request.GetResponse();

            // a placeholder for the token which will be pulled from the response's XML later
            string token = null;

            Stream responseStream = response.GetResponseStream();
            StreamReader responseStreamReader = new StreamReader(responseStream);

            XmlSerializer serializer = new XmlSerializer(typeof(Inrix));
            Inrix inrix = (Inrix)(serializer.Deserialize(responseStreamReader));
            token = inrix.AuthResponse.AuthToken.Value;

            responseStreamReader.Close();
            responseStream.Close();

            DB db = new DB("INRIX_XD");

            string query_insertXD = "INSERT INTO XDSpeeds (tstamp, xdid, speed, score, cvalue) VALUES (@tstamp, @xdid, @speed, @score, @cvalue);";
            string query_insertSubSpeed = "INSERT INTO SubSpeeds (tstamp, xdid, ostart, oend, speed) VALUES (@tstamp, @xdid, @ostart, @oend, @speed)";

            // parse out the segments from external file that defines what XDs we want to pull
            string[] xds = File.ReadAllLines(@"D:\Services\INRIX_XML_Ingester\xds.txt");
            StringBuilder xdsStringBuilder = new StringBuilder();
            bool isFirst = true;
            foreach (string xd in xds)
            {
                if (!isFirst)
                    xdsStringBuilder.Append(",");
                else
                    isFirst = false;

                xdsStringBuilder.Append(xd);
            }

            // Get speeds
            string speedURL = "http://api.inrix.com/Traffic/Inrix.ashx?action=getsegmentspeed&segments=" + xdsStringBuilder.ToString() + "&token=" + token;

            request = WebRequest.Create(speedURL);
            response = request.GetResponse();

            responseStream = response.GetResponseStream();
            responseStreamReader = new StreamReader(responseStream);

            Inrix inrixSpeed = (Inrix)(serializer.Deserialize(responseStreamReader));
            string timestamp = inrixSpeed.SegmentSpeedResultSet.SegmentSpeedResults.timestamp;

            int numXDs = 0;
            int numSSs = 0;

            foreach (InrixSegmentSpeedResultSetSegmentSpeedResultsSegment i in inrixSpeed.SegmentSpeedResultSet.SegmentSpeedResults.Segment)
            {
                // insert XD speed into SQL Server
                db.addParam("@tstamp", DateTime.Parse(timestamp).ToUniversalTime());
                db.addParam("@xdid", (int)i.code);
                db.addParam("@speed", (int)i.speed);
                db.addParam("@score", (int)i.score);
                db.addParam("@cvalue", (int)i.cvalue);

                try
                {
                    db.queryScalar(query_insertXD);
                    numXDs++;
                }
                catch (Exception e)
                {
                    File.AppendAllText(LOG_LOCATION + @"\" + DateTime.Now.ToString("yyyy_MM_dd") + ".log", e.Message + "\n");
                }

                db.clearParams();

                if (i.SubSegment != null && i.SubSegment.Length > 0)
                {
                    foreach (InrixSegmentSpeedResultSetSegmentSpeedResultsSegmentSubSegment j in i.SubSegment)
                    {
                        // parse out the beginning and ending offset
                        string[] offsets = j.offset.Split(',');

                        // insert SubSpeed into SQL Server
                        db.addParam("@tstamp", DateTime.Parse(timestamp).ToUniversalTime());
                        db.addParam("@xdid", (int)i.code);
                        if (offsets.Length == 2)
                        {
                            db.addParam("@ostart", offsets[0]);
                            db.addParam("@oend", offsets[1]);
                        }
                        else
                        {
                            db.addParam("@ostart", offsets[0]);
                        }
                        db.addParam("@speed", (int)j.speed);

                        try
                        {
                            db.queryScalar(query_insertSubSpeed);
                            numSSs++;
                        }
                        catch (Exception e)
                        {
                            File.AppendAllText(LOG_LOCATION + @"\" + DateTime.Now.ToString("yyyy_MM_dd") + ".log", e.Message + "\n");
                        }

                        db.clearParams();
                    }
                }
            }

            responseStreamReader.Close();
            responseStream.Close();

            db.close();

            File.AppendAllText(LOG_LOCATION + @"\" + DateTime.Now.ToString("yyyy_MM_dd") + ".log",
                    numXDs + " XD ingested.\n");
            File.AppendAllText(LOG_LOCATION + @"\" + DateTime.Now.ToString("yyyy_MM_dd") + ".log",
                    numSSs + " SS ingested.\n");
        }
    }
}
