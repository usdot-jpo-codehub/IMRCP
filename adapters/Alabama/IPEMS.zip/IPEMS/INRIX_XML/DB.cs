﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;

namespace INRIX_XML
{
    public class DB
    {
        SqlConnection conn;
        SqlCommand cmd;
        SqlBulkCopy sbc;

        public DB(string db) : this(db, "civl1122db01.ecn.purdue.edu") { }

        public DB(string db, string DataSource)
        {
            string ConnStr = @"Data Source=" + DataSource + ";Initial Catalog=" + db + @";User Id=sa;Password=purdue123;Connection Timeout=1200";
            conn = new SqlConnection(ConnStr);
            conn.Open();
            cmd = conn.CreateCommand();
            cmd.CommandTimeout = 1200;
            sbc = new SqlBulkCopy(conn);
            sbc.BulkCopyTimeout = 1200;
        }

        public void addParam(string key, object value)
        {
            cmd.Parameters.AddWithValue(key, value);
        }

        public SqlDataReader query(string query)
        {
            cmd.CommandText = query;
            SqlDataReader reader = cmd.ExecuteReader();
            return reader;
        }

        public bool queryScalar(string query)
        {
            cmd.CommandText = query;
            object result = cmd.ExecuteScalar();
            if (result == null)
                return false;
            return true;
        }

        public int queryScalarInt(string query)
        {
            cmd.CommandText = query;
            object resultObj = cmd.ExecuteScalar();
            int result = 0;
            if (resultObj != null)
                result = int.Parse(resultObj.ToString());
            return result;
        }

        public int update(string query)
        {
            cmd.CommandText = query;
            int result = cmd.ExecuteNonQuery();           
            return result;
        }

        public void bulkInsert(string tblName, DataTable dt)
        {
            sbc.DestinationTableName = tblName;
            sbc.WriteToServer(dt);
        }

        public void clearParams()
        {
            cmd.Parameters.Clear();
        }

        public void close()
        {
            sbc.Close();
            conn.Close();
        }
    }
}
