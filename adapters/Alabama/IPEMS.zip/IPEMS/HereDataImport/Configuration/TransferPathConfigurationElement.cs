﻿using System.Configuration;

namespace HereDataImport.Configuration
{
  public class TransferPathConfigurationElement : ConfigurationElement
  {
    [ConfigurationProperty("local-work-directory", IsRequired = true)]
    public string LocalWorkDirectory
    {
      get { return (string)this["local-work-directory"]; }
      set { this["local-work-directory"] = value; }
    }

    [ConfigurationProperty("local-archive-directory", IsRequired = true)]
    public string LocalArchiveDirectory
    {
      get { return (string)this["local-archive-directory"]; }
      set { this["local-archive-directory"] = value; }
    }

    [ConfigurationProperty("target-filename-pattern", IsRequired = false)]
    public string TargetFilenamePattern
    {
      get { return (string)this["target-filename-pattern"]; }
      set { this["target-filename-pattern"] = value; }
    }

    [ConfigurationProperty("destination-filename-format", IsRequired = true)]
    public string DestinationFilenameFormat
    {
      get { return (string)this["destination-filename-format"]; }
      set { this["destination-filename-format"] = value; }
    }

    [ConfigurationProperty("internal-package-target-path", DefaultValue = "", IsRequired = false)]
    public string InternalTargetPath
    {
      get { return (string)this["internal-package-target-path"]; }
      set { this["internal-package-target-path"] = value; }
    }

    [ConfigurationProperty("maximum-files-to-transfer", DefaultValue = 0, IsRequired = false)]
    public int MaximumFilesToTransfer
    {
      get { return (int)this["maximum-files-to-transfer"]; }
      set { this["maximum-files-to-transfer"] = value; }
    }

    [ConfigurationProperty("zip-executable-path", IsRequired = true)]
    public string ZipExecutablePath
    {
      get { return (string)this["zip-executable-path"]; }
      set { this["zip-executable-path"] = value; }
    }

    [ConfigurationProperty("service-log-path", IsRequired = true)]
    public string ServiceLogPath
    {
      get { return (string)this["service-log-path"]; }
      set { this["service-log-path"] = value; }
    }
  }
}
