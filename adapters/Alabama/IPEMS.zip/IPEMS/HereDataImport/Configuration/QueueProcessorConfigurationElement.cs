﻿using System.Configuration;

namespace HereDataImport.Configuration
{
  public class QueueProcessorConfigurationElement : ConfigurationElement
  {
    [ConfigurationProperty("maximum-processes", IsRequired = true)]
    public int MaximumProcesses
    {
      get { return (int)this["maximum-processes"]; }
      set { this["maximum-processes"] = value; }
    }

    [ConfigurationProperty("maximum-queue-length", IsRequired = true)]
    public int MaximumQueueLength
    {
      get { return (int)this["maximum-queue-length"]; }
      set { this["maximum-queue-length"] = value; }
    }

    [ConfigurationProperty("queue-available-length", IsRequired = false)]
    public int QueueAvailableLength
    {
      get
      {
        if (this["queue-available-length"] != null)
          return (int)this["queue-available-length"];
        else
          return (int)((int)this["maximum-queue-length"] * .90);
      }
      set
      {
        this["queue-available-length"] = value;
      }
    }

    [ConfigurationProperty("maximum-retry-attempts", IsRequired = false)]
    public int MaximumRetryAttempts
    {
      get { return (int)this["maximum-retry-attempts"]; }
      set { this["maximum-retry-attempts"] = value; }
    }
  }
}
