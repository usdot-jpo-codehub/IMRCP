﻿using System;
using System.Configuration;

namespace HereDataImport.Configuration
{
  public class DataImportConfigurationSection : ConfigurationSection
  {
    private static DataImportConfigurationSection _instance = null;
    private static bool _refreshed = false;
    private static object lockObj = new object();

    public static DataImportConfigurationSection Instance
    {
      get
      {
        lock (lockObj)
        {
          if (_instance == null)
          {
            _instance = (DataImportConfigurationSection)ConfigurationManager
              .GetSection("data-import-configuration");
            ConfigurationManager.RefreshSection("data-import-configuration");
            _instance = (DataImportConfigurationSection)ConfigurationManager
              .GetSection("data-import-configuration");
            //_refreshed = true;
          }
          else if (!_refreshed)
          {
            ConfigurationManager.RefreshSection("data-import-configurtaion");
            _instance = (DataImportConfigurationSection)ConfigurationManager
              .GetSection("data-import-configuration");
            _refreshed = true;
          }
        }

        return _instance;
      }
    }

    [ConfigurationProperty("network-recovery-notification-interval", IsRequired = true)]
    public TimeSpan NetworkRecoveryNotificationInterval
    {
      get { return (TimeSpan)this["network-recovery-notification-interval"]; }
      set { this["network-recovery-notification-interval"] = value; }
    }

    [ConfigurationProperty("transfer-connection", IsRequired = true)]
    public TransferConnectionConfigurationElement TransferConnection
    {
      get { return (TransferConnectionConfigurationElement)this["transfer-connection"]; }
      set { this["transfer-connection"] = value; }
    }

    [ConfigurationProperty("path-configuration", IsRequired = true)]
    public TransferPathConfigurationElement PathConfiguration
    {
      get { return (TransferPathConfigurationElement)this["path-configuration"]; }
      set { this["path-configuration"] = value; }
    }

    [ConfigurationProperty("input-queue-configuration", IsRequired = true, DefaultValue = null)]
    public QueueProcessorConfigurationElement InputQueueConfiguration
    {
      get { return (QueueProcessorConfigurationElement)this["input-queue-configuration"]; }
      set { this["input-queue-configuration"] = value; }
    }

    [ConfigurationProperty("insertion-queue-configuration", IsRequired = true)]
    public QueueProcessorConfigurationElement InsertionQueueConfiguration
    {
      get { return (QueueProcessorConfigurationElement)this["insertion-queue-configuration"]; }
      set { this["insertion-queue-configuration"] = value; }
    }

    [ConfigurationProperty("replacement-queue-configuration", IsRequired = true)]
    public QueueProcessorConfigurationElement ReplacementQueueConfiguration
    {
      get { return (QueueProcessorConfigurationElement)this["replacement-queue-configuration"]; }
      set { this["replacement-queue-configuration"] = value; }
    }

    [ConfigurationProperty("error-queue-configuration", IsRequired = true)]
    public QueueProcessorConfigurationElement ErrorQueueConfiguration
    {
      get { return (QueueProcessorConfigurationElement)this["error-queue-configuration"]; }
      set { this["error-queue-configuration"] = value; }
    }
  }
}
