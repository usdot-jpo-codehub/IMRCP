﻿using System.Configuration;

namespace HereDataImport.Configuration
{
  public class TransferConnectionConfigurationElement : ConfigurationElement
  {
    [ConfigurationProperty("host-domain", IsRequired = true)]
    public string HostDomain
    {
      get { return (string)this["host-domain"]; }
      set { this["host-domain"] = value; }
    }

    [ConfigurationProperty("host-path-format", IsRequired = false, DefaultValue = null)]
    public string HostPathFormat
    {
      get { return (string)this["host-path-format"]; }
      set { this["host-path-format"] = value; }
    }

    [ConfigurationProperty("host-scheme", IsRequired = false, DefaultValue = null)]
    public string HostScheme
    {
      get { return (string)this["host-scheme"]; }
      set { this["host-scheme"] = value; }
    }

    [ConfigurationProperty("host-port", IsRequired =false)]
    public int? HostPort
    {
      get { return (int?)this["host-port"]; }
      set { this["host-port"] = value; }
    }

    [ConfigurationProperty("username", IsRequired = true)]
    public string UserName
    {
      get { return (string)this["username"]; }
      set { this["username"] = value; }
    }

    [ConfigurationProperty("password", IsRequired = true)]
    public string Password
    {
      get { return (string)this["password"]; }
      set { this["password"] = value; }
    }

    [ConfigurationProperty("transfer-frequency-minutes", IsRequired = true)]
    public int TransferFrequecyMinutes
    {
      get { return (int)this["transfer-frequency-minutes"]; }
      set { this["transfer-frequency-minutes"] = value; }
    }

    [ConfigurationProperty("maximum-download-cycles", IsRequired = true)]
    public int MaximumDownloadCycles
    {
      get { return (int)this["maximum-download-cycles"]; }
      set { this["maximum-download-cycles"] = value; }
    }

    [ConfigurationProperty("available-download-files", IsRequired = true)]
    public string AvailableDownloadFiles
    {
      get { return (string)this["available-download-files"]; }
      set { this["available-download-files"] = value; }
    }
  }
}
