﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Xml.Serialization;

using NLog;

namespace HereDataImport.Model
{
  public abstract class ModelBase
  {
    protected static readonly string CONN_STRING;
    protected static Logger _log;

    static ModelBase()
    {
      try
      {
        _log = LogManager.GetLogger("Model");

        CONN_STRING = ConfigurationManager.ConnectionStrings["ModelConnection"].ConnectionString;

        if (string.IsNullOrWhiteSpace(CONN_STRING))
          throw new Exception("ModelBase ctor: ModelConnection connection string not found in configuration");
      }
      catch (Exception ex)
      {
        throw ex;
      }
    }

    [XmlIgnore]
    public long ID { get; set; }

    public virtual async Task<bool> InsertAsync()
    {
      bool result = false;

      try
      {
        using (SqlConnection conn = new SqlConnection(CONN_STRING))
        {
          conn.Open();

          result = await InsertAsync(conn);

          conn.Close();
        }
      }
      catch (Exception ex)
      {
        result = false;
        _log.Error(string.Format("InsertAsync: {0}\r\n{1}", ex.Message, ex.StackTrace));
      }

      return result;
    }

    internal abstract Task<bool> InsertAsync(SqlConnection conn);
  }

}
