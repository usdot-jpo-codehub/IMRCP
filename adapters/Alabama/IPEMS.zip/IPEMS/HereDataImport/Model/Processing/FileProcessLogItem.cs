﻿using System;

namespace HereDataImport.Model.Processing
{
  public partial class FileProcessLogItem : ModelBase
  {
    public string PackageName { get; set; }

    public string FileName { get; set; }

    public string ArchiveLocation { get; set; }

    public DateTime DownloadDate { get; set; }

    public DateTime ExtractionDate { get; set; }

    public DateTime ProcessDate { get; set; }

    public DateTime ArchiveDate { get; set; }

    //CREATED_TIMESTAMP from file XML data, TRAFFICML_REALTIME document.
    public DateTime FileCreatedTimestamp { get; set; }

    //Common transfer session timestamp for both files, to RW_PBT for each TmcItem in session.
    public DateTime SessionTimestamp { get; set; }

    public int NumberProcessed { get; set; }

    public int NumberFailed { get; set; }
  }
}
