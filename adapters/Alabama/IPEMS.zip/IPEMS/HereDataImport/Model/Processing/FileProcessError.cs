﻿using System;

namespace HereDataImport.Model.Processing
{
  public partial class FileProcessError : ModelBase
  {
    public long FileProcessLogItemId { get; set; }

    public long? OuterExceptionId { get; set; }

    public DateTime OccurredDate { get; set; }

    public string ErrorType { get; set; }

    public string Message { get; set; }

    public string StackTrace { get; set; }

    public string Remarks { get; set; }
  }
}
