﻿using System;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace HereDataImport.Model.Processing
{
  public partial class FileProcessError : ModelBase
  {
    public bool Insert()
    {
      bool result = false;

      string query = "INSERT INTO FileProcessErrors (FileProcessLogItemId, OuterExceptionId, OccurredDate, ErrorType, Message, StackTrace, Remarks) " +
        "VALUES (@fileProcessLogItemId, @outerExceptionId, @occurredDate, @errorType, @message, @stackTrace, @remarks);" +
        "SELECT CAST(IDENT_CURRENT('FileProcessErrors') AS INT) id;";

      try
      {
        using (SqlConnection conn = new SqlConnection(CONN_STRING))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@fileProcessLogItemId", FileProcessLogItemId);
          cmd.Parameters.AddWithValue("@outerExceptionId", OuterExceptionId == null ? DBNull.Value : (object)OuterExceptionId);
          cmd.Parameters.AddWithValue("@occurredDate", OccurredDate);
          cmd.Parameters.AddWithValue("@errorType", string.IsNullOrWhiteSpace(ErrorType) ? DBNull.Value : (object)ErrorType);
          cmd.Parameters.AddWithValue("@message", string.IsNullOrWhiteSpace(Message) ? DBNull.Value : (object)Message);
          cmd.Parameters.AddWithValue("@stackTrace", string.IsNullOrWhiteSpace(StackTrace) ? DBNull.Value : (object)StackTrace);
          cmd.Parameters.AddWithValue("@remarks", string.IsNullOrWhiteSpace(Remarks) ? DBNull.Value : (object)Remarks);

          conn.Open();

          ID = (int)cmd.ExecuteScalar();

          conn.Close();

          result = ID > 0;
        }
      }
      catch (Exception ex)
      {
        result = false;
        _log.Error(string.Format("FileProcessError.Insert, Error inserting Log error for log item {2}: {0}\r\n{1}", 
          ex.Message, ex.StackTrace, this.FileProcessLogItemId));
      }

      return result;
    }

    #region ModelBase implementation

    internal override Task<bool> InsertAsync(SqlConnection conn)
    {
      throw new NotImplementedException();
    }

    #endregion
  }
}
