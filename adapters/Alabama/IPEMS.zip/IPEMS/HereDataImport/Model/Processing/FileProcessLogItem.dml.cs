﻿using System;
using System.Data.SqlClient;
using System.Reflection;
using System.Threading.Tasks;

namespace HereDataImport.Model.Processing
{
  public partial class FileProcessLogItem : ModelBase
  {
    public bool Insert()
    {
      bool result = false;

      string query = "INSERT INTO FileProcessLogItems (PackageName) VALUES (@packageName);" +
        "SELECT CAST(IDENT_CURRENT('FileProcessLogItems') AS INT) id;";

      try
      {
        using (SqlConnection conn = new SqlConnection(CONN_STRING))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@packageName", PackageName);

          conn.Open();

          ID = (int)cmd.ExecuteScalar();

          conn.Close();

          result = ID > 0;
        }
      }
      catch (Exception ex)
      {
        result = false;
        _log.Error(string.Format("FileProcessLogItem.Insert, Error inserting Log item for {2}: {0}\r\n{1}", ex.Message, ex.StackTrace, this.PackageName));
      }

      return result;
    }

    public bool UpdateField(string fieldName)
    {
      bool result = false;

      PropertyInfo pi = this.GetType().GetProperty(fieldName);

      if (pi == null)
        throw new ArgumentException(string.Format("FileProcessLogItem.UpdateField: invalid field identifier - {0}", fieldName));

      string query = "UPDATE FileProcessLogItems SET {0} = @param WHERE Id = @id";

      try
      {
        using (SqlConnection conn = new SqlConnection(CONN_STRING))
        {
          SqlCommand cmd = new SqlCommand(string.Format(query, fieldName), conn);
          cmd.Parameters.AddWithValue("@id", this.ID);
          cmd.Parameters.AddWithValue("@param", pi.GetValue(this) != null ? pi.GetValue(this) : DBNull.Value);

          conn.Open();
          result = cmd.ExecuteNonQuery() == 1;
          conn.Close();
        }
      }
      catch (Exception ex)
      {
        result = false;
        _log.Error(string.Format("FileProcessLogItem.UpdateField, Error updating Log item {3} for field {2}|{4}: {0}\r\n{1}", 
          ex.Message, ex.StackTrace, fieldName, this.ID, pi.GetValue(this).ToString()));
      }

      return result;
    }

    //Convenience method to avoid 3 separate updates.
    public bool UpdateProcessCompletionFields()
    {
      bool result = false;

      string query = "UPDATE FileProcessLogItems SET ProcessDate = @processDate, NumberProcessed = @numberProcessed, NumberFailed = @numberFailed WHERE Id = @id";

      try
      {
        using (SqlConnection conn = new SqlConnection(CONN_STRING))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@id", this.ID);
          cmd.Parameters.AddWithValue("@processDate", ProcessDate);
          cmd.Parameters.AddWithValue("@numberProcessed", NumberProcessed);
          cmd.Parameters.AddWithValue("@numberFailed", NumberFailed);

          conn.Open();
          result = cmd.ExecuteNonQuery() == 1;
          conn.Close();
        }
      }
      catch (Exception ex)
      {
        result = false;
        _log.Error(string.Format("FileProcessLogItem.UpdateProcessCompletionFields, Error updating Log item {2}: {0}\r\n{1}",
          ex.Message, ex.StackTrace, this.ID));
      }

      return result;
    }

    #region ModelBase implementation

    internal override Task<bool> InsertAsync(SqlConnection conn)
    {
      throw new NotImplementedException();
    }

    #endregion
  }
}
