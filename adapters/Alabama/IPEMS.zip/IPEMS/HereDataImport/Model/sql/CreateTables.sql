﻿-- Alabama roadways are described in TMC_ATTR.csv(.zip), included in this folder.
-- To recreate the table, use the Sql Server Mgmt Studio database tasks to import the csv.
-- The table is required by the application to select only the Alabama roadways from the bulk files: GA/AL, FL/AL.
-- In replicating the table, don't forget to create the following index:
--
--CREATE CLUSTERED INDEX IDX_Linear_Point_Desc ON TMC_ATTR
--(
--	PRIMARY_LINEAR ASC,
--	POINT_DESC ASC
--)


IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID('TmcItems') AND type = 'U')
	DROP TABLE TmcItems

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID('FileProcessErrors') AND type = 'U')
  DROP TABLE FileProcessErrors
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID('FileProcessLogItems') AND type = 'U')
  DROP TABLE FileProcessLogItems

GO

CREATE TABLE FileProcessLogItems
(
  Id INT IDENTITY,
  PackageName VARCHAR(50) NOT NULL,
  FileName VARCHAR(50),
  ArchiveLocation VARCHAR(200),
  DownloadDate DATETIME,
  ExtractionDate DATETIME,
  ProcessDate DATETIME,
  ArchiveDate DATETIME,
  NumberProcessed INT,
  NumberFailed INT,
  CONSTRAINT FileProcessLogItems_Id_Pk PRIMARY KEY (Id)
)

ALTER TABLE FileProcessLogItems
	ADD FileCreatedTimestamp DATETIME,
		SessionTimestamp DATETIME

CREATE INDEX FileProcessLogItems_SessionTimestamp_x ON FileProcessLogItems
(
  SessionTimestamp
)

CREATE TABLE FileProcessErrors
(
  Id INT IDENTITY,
  FileProcessLogItemId INT NOT NULL,
  OuterExceptionId INT,
  OccurredDate DATETIME NOT NULL,
  ErrorType VARCHAR(100),
  Message VARCHAR(MAX),
  StackTrace VARCHAR(MAX),
  Remarks VARCHAR(MAX),
  CONSTRAINT FileProcessErrors_Id_Pk PRIMARY KEY (Id),
  CONSTRAINT FileProcessErrors_FileProcessLogItemId_fk FOREIGN KEY (FileProcessLogItemId)
    REFERENCES FileProcessLogItems (Id),
  CONSTRAINT FileProcessErrors_OuterExceptionId_fk FOREIGN KEY (OuterExceptionId)
    REFERENCES FileProcessErrors (Id)
)

CREATE TABLE TmcItems
(
	Id BIGINT IDENTITY,
	PackageId INT,
	CreationDate DATETIME,
	RW_LI VARCHAR(10),
	RW_DE VARCHAR(100),
	RW_PBT DATETIME,
	TMC_PC VARCHAR(6),
	TMC_DE VARCHAR(100),
	CF_TY VARCHAR(2),
	CF_SP DECIMAL(6,2),
	CF_SU DECIMAL(6,2),
	CF_FF DECIMAL(6,2),
	CF_JF DECIMAL(10,6),
	CF_CN DECIMAL(6,2),
	CF_TS VARCHAR(1),
	SS_LE DECIMAL(10,6),
	SS_SP DECIMAL(6,2),
	SS_SU DECIMAL(6,2),
	SS_FF DECIMAL(6,2),
	SS_JF DECIMAL(10,6),
	SS_TS VARCHAR(1),
  SS_ORDER INT,
	LINEAR AS REPLACE(REPLACE(RW_LI, '+', 'P'), '-', 'N')
)

CREATE CLUSTERED INDEX TmcItems_RW_PBT_x ON TmcItems
(
	RW_PBT
)
