﻿IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID('LookupRoadway') AND type = 'P')
	DROP PROCEDURE LookupRoadway

GO

CREATE PROCEDURE LookupRoadway (@linear VARCHAR(50), @point_desc VARCHAR(100))
AS
SELECT COUNT(*) FROM TMC_ATTR WHERE PRIMARY_LINEAR = @linear AND POINT_DESC = @point_desc

--Don't forget to give the user EXECUTE permission on the procedure, either as follows
--or via the Securables tab of the User properties dialog (in mgmt studio).
GRANT EXECUTE ON LookupRoadway TO HereApp
