﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HereDataImport.Model
{
  public partial class TmcItem : ModelBase
  {
    private static SqlConnection _marsConn;

    static TmcItem()
    {
      string connStr = ConfigurationManager.ConnectionStrings["MarsConnection"].ConnectionString;
      if (!string.IsNullOrWhiteSpace(connStr))
        _marsConn = new SqlConnection(connStr);
      _marsConn.Open();
    }

    public class TmcItemResult { public bool Result { get; set; } public TmcItem TmcItem { get; set; } }

    public async Task<TmcItemResult> InsertWithResultAsync()
    {
      TmcItemResult result = new TmcItemResult() { TmcItem = this };
      result.Result = await this.InsertAsync();

      return result;
    }

    internal override async Task<bool> InsertAsync(SqlConnection conn)
    {
      bool result = false;
      string query = "INSERT INTO TmcItems " +
        "(PackageId, CreationDate, " +
        "RW_LI, RW_DE, RW_PBT, TMC_PC, TMC_DE, CF_TY, CF_SP, CF_SU, CF_FF, CF_JF, CF_CN, CF_TS, SS_LE, SS_SP, SS_SU, SS_FF, SS_JF, SS_TS, SS_ORDER) " +
        "VALUES " +
        "(@packageId, @creationDate, " +
        "@rw_li, @rw_de, @rw_pbt, @tmc_pc, @tmc_de, @cf_ty, @cf_sp, @cf_su, @cf_ff, @cf_jf, @cf_cn, @cf_ts, @ss_le, @ss_sp, @ss_su, @ss_ff, @ss_jf, @ss_ts, @ss_order); " +
        "SELECT CAST(SCOPE_IDENTITY() AS BIGINT) ID";

      SqlCommand cmd = new SqlCommand(query, conn);
      cmd.Parameters.AddWithValue("@packageId", PackageId);
      cmd.Parameters.AddWithValue("@creationDate", CreationDate);
      cmd.Parameters.AddWithValue("@rw_li", rw_li == null ? DBNull.Value : (object)rw_li);
      cmd.Parameters.AddWithValue("@rw_de", rw_de == null ? DBNull.Value : (object)rw_de);
      cmd.Parameters.AddWithValue("@rw_pbt", rw_pbt == null ? DBNull.Value : (object)rw_pbt);
      cmd.Parameters.AddWithValue("@tmc_pc", tmc_pc == null ? DBNull.Value : (object)tmc_pc);
      cmd.Parameters.AddWithValue("@tmc_de", tmc_de == null ? DBNull.Value : (object)tmc_de);
      cmd.Parameters.AddWithValue("@cf_ty", cf_ty == null ? DBNull.Value : (object)cf_ty);
      cmd.Parameters.AddWithValue("@cf_sp", cf_sp == null ? DBNull.Value : (object)cf_sp);
      cmd.Parameters.AddWithValue("@cf_su", cf_su == null ? DBNull.Value : (object)cf_su);
      cmd.Parameters.AddWithValue("@cf_ff", cf_ff == null ? DBNull.Value : (object)cf_ff);
      cmd.Parameters.AddWithValue("@cf_jf", cf_jf == null ? DBNull.Value : (object)cf_jf);
      cmd.Parameters.AddWithValue("@cf_cn", cf_cn == null ? DBNull.Value : (object)cf_cn);
      cmd.Parameters.AddWithValue("@cf_ts", cf_ts == null ? DBNull.Value : (object)cf_ts);
      cmd.Parameters.AddWithValue("@ss_le", ss_le == null ? DBNull.Value : (object)ss_le);
      cmd.Parameters.AddWithValue("@ss_sp", ss_sp == null ? DBNull.Value : (object)ss_sp);
      cmd.Parameters.AddWithValue("@ss_su", ss_su == null ? DBNull.Value : (object)ss_su);
      cmd.Parameters.AddWithValue("@ss_ff", ss_ff == null ? DBNull.Value : (object)ss_ff);
      cmd.Parameters.AddWithValue("@ss_jf", ss_jf == null ? DBNull.Value : (object)ss_jf);
      cmd.Parameters.AddWithValue("@ss_ts", ss_ts == null ? DBNull.Value : (object)ss_ts);
      cmd.Parameters.AddWithValue("@ss_order", ss_order == null ? DBNull.Value : (object)ss_order);

      ID = (long)await cmd.ExecuteScalarAsync();

      result = true;

      return result;
    }

    public bool LinearExists()
    {
      bool result = false;
      //string query = "SELECT COUNT(*) FROM TMC_ATTR WHERE POINT_DESC = @point_desc AND LINEAR = @linear";
      //This was changed from a SELECT query to a stored procedure in order to force the DB engine to
      //optimize the execution plan. Using Index Scan (slow) for the query vs Index Seek (fast) for the sp for some reason.
      string query = "LookupRoadway";

      try
      {
        using (SqlCommand cmd = new SqlCommand(query, _marsConn))
        {
          cmd.CommandType = System.Data.CommandType.StoredProcedure;
          //Parameter names must agree with those defined in the stored procedure.
          cmd.Parameters.AddWithValue("@point_desc", string.IsNullOrWhiteSpace(tmc_de) ? DBNull.Value : (object)tmc_de);
          cmd.Parameters.AddWithValue("@linear", string.IsNullOrWhiteSpace(linear) ? DBNull.Value : (object)linear);

          int c = (int)cmd.ExecuteScalar();

          result = c > 0;
        }
      }
      catch(Exception ex)
      {
        _log.Error("LinearExists, {0}: {1}\r\n{2}", ex.GetType().Name, ex.Message, ex.StackTrace);
      }

      return result;
    }

    public async Task<TmcItemResult> LinearExistsAsync()
    {
      TmcItemResult result = new TmcItemResult() { TmcItem = this };
      result.Result = await Task.Run(() => LinearExists());

      return result;
    }
  }
}
