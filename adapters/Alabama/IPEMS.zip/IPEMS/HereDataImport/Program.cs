﻿using System;

using NLog;

using HereDataImport.Configuration;
using HereDataImport.Process;

namespace HereDataImport
{
  class Program
  {
    private static Logger _log = LogManager.GetLogger("Main");

    static void Main(string[] args)
    {
      try
      {
        DataImportConfigurationSection config = DataImportConfigurationSection.Instance;
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message + "\r\n" + ex.StackTrace);
      }

      DataImportController _controller = new DataImportController();
      _controller.Process();
    }
  }
}
