﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Timers;
using Timer = System.Timers.Timer;
using System.Threading;
using System.Threading.Tasks;

using NLog;

using HereDataImport.Configuration;
using HereDataImport.Process.Events;

namespace HereDataImport.Process
{
  public enum FileTransferProcessorStatus
  {
    READY,
    RUNNING,
    FINISHED,
    ERROR,
    NETWORK_ERROR
  }

  public class HttpFileTransferProcessor
  {
    private class FileTimestamp
    {
      public string stringValue;
      public DateTime dateValue;
    }

    private Logger _log;
    private DataImportConfigurationSection _config;

    private string _httpHost, _httpPathFormat, _httpScheme, _httpUser, _httpPassword, _targUrl;
    private string[] _availFiles;
    private int? _httpPort;
    private string _localArchDir, _localWorkDir, _destFilenameFormat, _internalPackagePath;
    private int _maxFiles, _transferFrequency, _intervalsToWait, _intervalsWaited;
    private long? _currentObjectId = null;
    private FileTransferProcessorStatus _status;
    private Timer _processTimer, _listTimer;
    private EventWaitHandle _listWait;
    private List<Thread> _threads;
    private Dictionary<string, FileTimestamp> _fileModTimestamps;

    private NetworkCredential _credentials;
    private WebClient _client;

    public event FileProcessEventHandler FileTransferStarted;
    public event FileProcessEventHandler FileTransferCompleted;
    public event FileProcessEventHandler FileTransferNoWork;
    public event FileProcessEventHandler FileTransferFailed;
    public event FileProcessEventHandler FileTransferFatalException;
    public event FileProcessEventHandler FileTransferNetworkError;
    public event FileProcessEventHandler FileTransferNetworkErrorRecovered;

    public HttpFileTransferProcessor()
    {
      _log = LogManager.GetLogger(this.GetType().Name);
      _config = DataImportConfigurationSection.Instance;

      _httpHost = _config.TransferConnection.HostDomain;
      _httpPathFormat = _config.TransferConnection.HostPathFormat;
      _httpScheme = _config.TransferConnection.HostScheme;
      _httpPort = _config.TransferConnection.HostPort;
      _httpUser = _config.TransferConnection.UserName;
      _httpPassword = _config.TransferConnection.Password;
      string availFiles = _config.TransferConnection.AvailableDownloadFiles;
      if (!string.IsNullOrWhiteSpace(availFiles))
        _availFiles = availFiles.Split(new char[] { ';' });

      //Initialize a last modified timestamp for each target file to use when checking for new data.
      //Roll back the current timestamp by the transfer interval so we don't miss on the first try because
      //the latest file was created before this process was started.
      _fileModTimestamps = new Dictionary<string, FileTimestamp>();
      foreach (string f in _availFiles)
      {
        DateTime d = DateTime.Now.AddMinutes(-_config.TransferConnection.TransferFrequecyMinutes);
        _fileModTimestamps.Add(f, new FileTimestamp()
        {
          //must be in correct format for if-modified-since header:
          //https://developer.mozilla.org/en-US/docs/Web/HTTP/Headers/Last-Modified
          stringValue = d.ToUniversalTime().ToString("ddd, dd MMM yyyy HH:mm.ss G\\MT"),
          dateValue = d
        });
      }
      _credentials = new NetworkCredential() { UserName = _httpUser, Password = _httpPassword };

      //convert to milliseconds for timer
      _transferFrequency = _config.TransferConnection.TransferFrequecyMinutes * 60 * 1000;
      _threads = new List<Thread>();
      _listWait = new EventWaitHandle(false, EventResetMode.AutoReset);

      _localArchDir = _config.PathConfiguration.LocalArchiveDirectory;
      _localWorkDir = _config.PathConfiguration.LocalWorkDirectory;
      _destFilenameFormat = _config.PathConfiguration.DestinationFilenameFormat;
      _internalPackagePath = _config.PathConfiguration.InternalTargetPath;
      _maxFiles = _config.PathConfiguration.MaximumFilesToTransfer;

      _intervalsToWait = 1;
      _intervalsWaited = 0;

      _status = FileTransferProcessorStatus.READY;
    }

    public FileTransferProcessorStatus Status { get { return _status; } }

    public void Stop()
    {
      _status = FileTransferProcessorStatus.FINISHED;
      _listWait.Set();
    }

    //Make this available to other processes
    public void ClearWorkDirectory()
    {
      try
      {
        string[] files = Directory.GetFiles(_localWorkDir);
        foreach (string file in files)
          File.Delete(file);

        files = Directory.GetDirectories(_localWorkDir);
        foreach (string file in files)
          Directory.Delete(file, true);
      }
      catch (Exception ex)
      {
        _log.Error("ClearWorkDirectory: Error clearing work directory: {0}\r\n{1}", ex.Message, ex.StackTrace);
      }
    }

    public async Task Process()
    {
      if (Directory.Exists(_localWorkDir))
      {
        if (_status != FileTransferProcessorStatus.RUNNING && _status != FileTransferProcessorStatus.NETWORK_ERROR)
          await Task.Run(() => _mainLoop());
      }
      else
      {
        string message = string.Format("Process: Configured work directory not found: {0}", _localWorkDir);
        _log.Error(message);

        FileProcessEventArgs args = new FileProcessEventArgs(null, FileProcessEventType.PROCESS_ERROR, new Exception(message));
        OnFileTransferFatalException(args);
      }
    }

    #region Private work procedures

    private void _mainLoop()
    {
      List<Thread> toRemove = new List<Thread>();

      _status = FileTransferProcessorStatus.RUNNING;

      _processTimer = new Timer(_transferFrequency);
      _processTimer.Elapsed += _threadProcess;
      _processTimer.Start();
      _listTimer = new Timer(10 * 1000); //10 seconds
      _listTimer.Elapsed += _listTimerExpired;
      _listTimer.Start();

      _threadProcess();

      while (_status == FileTransferProcessorStatus.RUNNING || _status == FileTransferProcessorStatus.NETWORK_ERROR)
      {
        foreach (Thread t in _threads)
          if (t.ThreadState != ThreadState.Unstarted && t.ThreadState != ThreadState.Running)
            toRemove.Add(t);

        foreach (Thread t in toRemove)
          _threads.Remove(t);
        toRemove.Clear();

        //Thread.Sleep would cause the process to be unresponsive while sleeping.
        //We want to be able to shut it down quickly.
        _listWait.WaitOne();
      }

      _processTimer.Stop();
      _listTimer.Stop();
    }

    private void _listTimerExpired(object sender, ElapsedEventArgs args)
    {
      _listWait.Set();
    }

    private void _threadProcess(object sender, ElapsedEventArgs args)
    {
      if (_status == FileTransferProcessorStatus.NETWORK_ERROR && _intervalsWaited < _intervalsToWait)
        _intervalsWaited++;
      else if (_status == FileTransferProcessorStatus.RUNNING || _status == FileTransferProcessorStatus.NETWORK_ERROR)
        _threadProcess();
    }

    private void _threadProcess()
    {
      Thread pt = new Thread(new ThreadStart(_process));
      _threads.Add(pt);
      pt.Start();
    }

    private void _process()
    {
      DateTime sessionTimestamp = DateTime.Now;

      if (GetFreshServerFilesStatus())
      {
        try
        {
          foreach (string availFile in _availFiles)
          {
            string destFilename = string.Format(_destFilenameFormat, DateTime.Now.Ticks.ToString(), availFile);
            string destFilepath = Path.Combine(_localWorkDir, destFilename);
            _targUrl = GetFileUrl(availFile);

            FileProcessEventArgs args = new FileProcessEventArgs(destFilepath, FileProcessEventType.TRANSFER, null) { FileTimestamp = sessionTimestamp };
            OnFileTransferStarted(args);
            //Since the event runs synchronously, the data controller (subscriber) can pass back the record ID of the 
            //log item created for this package, to be used in further events, by updating the event arg Object ID property.
            _currentObjectId = args.ObjectId;

            _client = new WebClient();
            _client.UseDefaultCredentials = false;
            _client.Credentials = _credentials;
            _client.DownloadFile(_targUrl, destFilepath);

            //Update file timestamp to use in next session
            string fileModified = _client.ResponseHeaders[HttpResponseHeader.LastModified];
            DateTime d;
            if (!DateTime.TryParse(fileModified, out d))
            {
              d = DateTime.Now;
              fileModified = d.ToUniversalTime().ToString("ddd, dd MMM yyyy HH:mm.ss G\\MT");
              _log.Error($"_process: could not parse file modified date, {fileModified}, for {availFile}");
            }
            _fileModTimestamps[availFile].dateValue = d;
            _fileModTimestamps[availFile].stringValue = fileModified;

            _client.Dispose();

            //If recovering from network error, reset the recovery flags.
            if (_status == FileTransferProcessorStatus.NETWORK_ERROR)
            {
              _status = FileTransferProcessorStatus.RUNNING;
              _intervalsToWait = 1;
              OnFileTransferNetworkErrorRecovered(args);
            }

            OnFileTransferCompleted(args);
          }
        }
        catch (WebException wex)
        {
          _status = FileTransferProcessorStatus.NETWORK_ERROR;
          _intervalsToWait *= 2;
          _intervalsWaited = 0;

          HttpWebResponse resp = (HttpWebResponse)wex.Response;
          string respInfo = resp == null ? string.Empty : string.Format("\r\nResponse Status Code: {0}, Status Description: {1}", resp.StatusCode, resp.StatusDescription);

          _log.Error(string.Format("_process Web Exception, waiting {0} minutes to retry: {1}\r\n{2}{3}",
            _intervalsToWait.ToString(),
            wex.Message,
            wex.StackTrace,
            respInfo));

          FileProcessEventArgs args = new FileProcessEventArgs(null, FileProcessEventType.PROCESS_ERROR, wex);
          OnFileTransferNetworkError(args);
        }
        catch (Exception ex)
        {
          _status = FileTransferProcessorStatus.ERROR;

          _log.Error(string.Format("HttpFileTransferProcesser.Process {2}: {0}\r\n{1}", ex.Message, ex.StackTrace, ex.GetType().Name));

          FileProcessEventArgs args = new FileProcessEventArgs(null, FileProcessEventType.PROCESS_ERROR, ex);
          OnFileTransferException(args);
        }
      }
      else
      {
        _log.Info("Process: session skipped, waiting for fresh data.");
      }
    }

    private string GetFileUrl(string filename)
    {
      return string.Format("{0}://{1}{2}/{3}",
        _httpScheme,
        _httpHost,
        _httpPort.HasValue ? string.Format(":{0}", _httpPort.Value) : string.Empty,
        string.Format(_httpPathFormat, filename));
    }

    //Have files on server been updated since last download?
    private bool GetFreshServerFilesStatus()
    {
      bool result = true;

      try
      {
        int fndx = 0;
        while (result && fndx < _availFiles.Length)
        {
          string fUrl = GetFileUrl(_availFiles[fndx]);
          HttpWebRequest req = WebRequest.CreateHttp(fUrl);
          req.Method = "HEAD";
          req.UseDefaultCredentials = false;
          req.Credentials = new NetworkCredential(_config.TransferConnection.UserName, _config.TransferConnection.Password);

          HttpWebResponse resp = (HttpWebResponse)req.GetResponse();
          result = _fileModTimestamps[_availFiles[fndx]].dateValue < resp.LastModified;
          if (!result)
            _log.Info($"GetFileAvailability: found stale file - {_availFiles[fndx]}, " +
              $"last downloaded - {_fileModTimestamps[_availFiles[fndx]].dateValue}, " +
              $"currently available - {resp.LastModified}");
          resp.Close();
          resp.Dispose();
          fndx++;
        }
      }
      catch (Exception ex)
      {
        result = false;
        _log.Error(string.Format("GetFileAvailability: {2}: {0}\r\n{1}", ex.Message, ex.StackTrace, ex.GetType().Name));
      }

      return result;
    }

    private string GetAuthHeader()
    {
      string result = null;
      string cred = $"{_httpUser}:{_httpPassword}";


      return result;
    }

    #endregion

    #region Fire events

    protected virtual void OnFileTransferException(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileTransferFailed;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileTransferFatalException(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileTransferFatalException;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileTransferNetworkError(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileTransferNetworkError;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileTransferNetworkErrorRecovered(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileTransferNetworkErrorRecovered;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileTransferStarted(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileTransferStarted;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileTransferCompleted(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileTransferCompleted;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileTransferNoWork(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileTransferNoWork;

      if (handler != null)
        handler(this, args);
    }

    #endregion
  }
}
