﻿using System;
using System.Threading;
using System.Threading.Tasks;

using HereDataImport.Model;
using HereDataImport.Process.Events;

namespace HereDataImport.Process
{
  public class InputQueue : ProcessingQueue<TmcItem, TmcItem.TmcItemResult>
  {
    private bool _iqPause, _iqFull;
    private EventWaitHandle _iqWait, _pWait;

    public InputQueue(ProcessingQueue<TmcItem, TmcItem.TmcItemResult> nextQueue) : base()
    {
      _maxQueueLen = _config.InputQueueConfiguration.MaximumQueueLength;
      if (_config.InputQueueConfiguration.QueueAvailableLength != 0)
        _queueAvailableLen = _config.InputQueueConfiguration.QueueAvailableLength;
      else
        _queueAvailableLen = (int)(_maxQueueLen * .9);

      _maxProcesses = _config.InputQueueConfiguration.MaximumProcesses;

      _iqPause = _iqFull = false;
      _iqWait = new EventWaitHandle(false, EventResetMode.AutoReset);
      _pWait = new EventWaitHandle(false, EventResetMode.AutoReset);

      _nextQueue = nextQueue;
      _nextQueue.QueueEvent += InsertionQueueEventHandler;
    }

    #region Public properties

    public object BlockingQueue
    {
      get
      {
        object result;

        if (_iqPause)
          result = _nextQueue;
        else
          result = null;

        return result;
      }
    }

    #endregion

    public override void Stop()
    {
      base.Stop();
      _iqPause = false;
      _iqWait.Set();
    }

    #region Work/utility procedures

    protected override async void _process()
    {
      _log.Info("_process: Input queue process starting.");
      _run = true;

      while (_run)
      {
        try
        {
          if (_pause || _queue.Count + _processes.Count == 0)
          {
            if (_queue.Count == 0)
            {
              OnQueueEvent(ProcessingQueueEventType.QUEUE_EMPTY);
              if (_statReset)
              {
                _log.Info(string.Format("{0} statistics for current file: processed - {1}, failed - {2}", this.GetType().Name, _processed.ToString(), _failed.ToString()));
                _processed = 0;
                _failed = 0;
                _statReset = false;
                _nextQueue.ResetStatistics();
              }

            }
            _pause = true;
            _log.Debug("_wait");
            _wait.WaitOne();
          }

          while (_queue.Count > 0 && _processes.Count <= _maxProcesses)
          {
            TmcItem currentItem = null;
            lock (_qlock)
            {
              currentItem = _queue.Dequeue();
            }

            if (currentItem != null)
            {
              Task<TmcItem.TmcItemResult> currentTask = currentItem.LinearExistsAsync();
              _processes.Add(currentTask);
            }

            if (_full && _queue.Count <= _queueAvailableLen)
            {
              _full = false;
              OnQueueEvent(ProcessingQueueEventType.QUEUE_AVAILABLE);
            }

            if (_processes.Count > 0)
            {
              //Finish at least one process, but whatever it takes to go below max.
              do
              {
                Task<TmcItem.TmcItemResult> nextResult = await Task.WhenAny(_processes);
                _processes.Remove(nextResult);
                if (nextResult.Result.Result)
                {
                  if (_iqFull)
                  {
                    _state = ProcessingQueueState.BLOCKED;
                    OnQueueEvent(ProcessingQueueEventType.QUEUE_BLOCKED);
                    _iqPause = true;
                    _log.Debug("_eqWait");
                    _iqWait.WaitOne();
                  }
                  ((ProcessingQueue<TmcItem, TmcItem.TmcItemResult>)_nextQueue).Enqueue(nextResult.Result.TmcItem);
                }
                _processed++;
              } while (_processes.Count >= _maxProcesses);
            }
          }
        }
        catch (Exception ex)
        {
          _log.Error(string.Format("_process: Exception during execution - {0}, {1}\r\n{2}", ex.GetType().Name, ex.Message, ex.StackTrace));

          _run = false;
          OnQueueEvent(ProcessingQueueEventType.QUEUE_STOPPED);
        }
      }

      _log.Info("_process: Input queue process stopping");
    }

    #endregion

    #region Fire and handle events

    private void InsertionQueueEventHandler(object sender, ProcessingQueueEventArgs args)
    {
      switch (args.EventType)
      {
        case ProcessingQueueEventType.QUEUE_AVAILABLE:
          _iqFull = false;
          if (_iqPause)
          {
            _iqPause = false;
            _iqWait.Set();
            OnQueueEvent(ProcessingQueueEventType.QUEUE_READY);
          }
          break;
        case ProcessingQueueEventType.QUEUE_FULL:
          _iqFull = true;
          break;
        case ProcessingQueueEventType.QUEUE_STOPPED:
          _run = false;
          OnQueueEvent(ProcessingQueueEventType.QUEUE_STOPPED);
          break;
      }
    }

    #endregion
  }
}
