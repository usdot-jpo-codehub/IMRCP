﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Timers;
using Timer = System.Timers.Timer;
using System.Threading;
using System.Threading.Tasks;

using NLog;

using HereDataImport.Model.Processing;
using HereDataImport.Configuration;
using HereDataImport.Process.Events;

namespace HereDataImport.Process
{
  public class DataImportController
  {
    private static readonly string FILE_IMPORT_START_MSG = "File deserialzation starting up";
    private static readonly string FILE_IMPORT_COMPLETE_MSG = "File deserialization has completed";
    private static readonly string FILE_IMPORT_FAILED_MSG = "File deserialization failed";

    private enum ProcessTrackingStatus
    {
      DOWNLOADING,
      EXTRACTING,
      PROCESSING,
      FAILED,
      DONE
    }

    private class ProcessTrackingItem
    {
      public FileProcessLogItem LogItem { get; set; }
      public ProcessTrackingStatus Status { get; set; }
    }

    private Logger _log;
    private DataImportConfigurationSection _config;
    private HttpFileTransferProcessor _transferProcessor;
    private GzipPackageProcessor _zipProcessor;
    private XmlXpathImportProcessor _fileProcessor;
    private InputQueue _inputQueue;
    private InsertionQueue _insertionQueue;
    private ErrorQueue _errorQueue;

    private bool _monitor;
    private int _maxDownloadCycles, _downloadCycleCount;
    private Timer _monitorTimer;
    private EventWaitHandle _monitorWait;

    private bool _networkRecovery;
    private TimeSpan _networkRecoveryNotificationInterval;
    private DateTime _networkRecoveryLastNotificationTime, _networkRecoveryStartTime;

    private List<ProcessTrackingItem> _processLogItems;
    private Task[] _tasks;

    public DataImportController()
    {
      _log = LogManager.GetLogger(this.GetType().Name);
      _config = DataImportConfigurationSection.Instance;

      _processLogItems = new List<ProcessTrackingItem>();

      _transferProcessor = new HttpFileTransferProcessor();
      _transferProcessor.FileTransferStarted += TransferStartHandler;
      _transferProcessor.FileTransferCompleted += TransferCompleteHandler;
      _transferProcessor.FileTransferNoWork += TransferNoWorkHandler;
      _transferProcessor.FileTransferFailed += TransferErrorHandler;
      _transferProcessor.FileTransferNetworkError += TransferNetworkErrorHandler;
      _transferProcessor.FileTransferNetworkErrorRecovered += TransferNetworkErrorRecoveryHandler;

      _zipProcessor = new GzipPackageProcessor();
      _zipProcessor.FileExtractionCompleted += ExtractionCompleteHandler;
      _zipProcessor.FileExtractionFailed += ExtractionFailedHandler;
      _zipProcessor.FileArchiveCompleted += LocalArchiveCompleteHandler;
      _zipProcessor.FileArchiveFailed += LocalArchiveFailedHandler;

      _errorQueue = new ErrorQueue();
      _errorQueue.QueueEvent += ErrorQueueEventHandler;

      _insertionQueue = new InsertionQueue(_errorQueue);
      _insertionQueue.QueueEvent += InsertionQueueEventHandler;

      _inputQueue = new InputQueue(_insertionQueue);
      _inputQueue.QueueEvent += InputQueueEventHandler;

      _fileProcessor = new XmlXpathImportProcessor(_inputQueue);
      _fileProcessor.XmlFileImportStarted += FileImportStartHandler;
      _fileProcessor.XmlFileImportCompleted += FileImportCompleteHandler;
      _fileProcessor.XmlFileImportFailed += FileImportFailedHandler;
      _fileProcessor.XmlRecordImportFailed += RecordImportFailedHandler;

      _maxDownloadCycles = _config.TransferConnection.MaximumDownloadCycles;
      _downloadCycleCount = 0;

      _monitorWait = new EventWaitHandle(false, EventResetMode.AutoReset);

      _networkRecoveryNotificationInterval = _config.NetworkRecoveryNotificationInterval;
    }

    public bool HasFinishedPackages()
    {
      return _processLogItems.Any(li => li.Status == ProcessTrackingStatus.DONE);
    }

    public void Process()
    {
      _log.Info("Starting up...\r\n=====================================================================================\r\n");
      SendStartNotification();

      _monitor = true;
      Thread mon = new Thread(new ThreadStart(Monitor));
      mon.Start();

      ProcessFiles();
      SendStopNotification();

      _monitor = false;
      _log.Info("Shutting down...\r\n=====================================================================================\r\n\r\n");
    }

    public void Stop()
    {
      _transferProcessor.Stop();
    }

    public void Shutdown()
    {
      _transferProcessor.Stop();
      StopQueues();
    }

    #region Work/utility methods

    private void MonitorTimerExpired(object sender, ElapsedEventArgs args)
    {
      _monitorWait.Set();
    }

    private void Monitor()
    {
      _monitorTimer = new Timer(2000);
      _monitorTimer.Elapsed += MonitorTimerExpired;
      _monitorTimer.Start();

      while (_monitor)
      {
        if (_transferProcessor.Status == FileTransferProcessorStatus.FINISHED && _zipProcessor.Count == 0)
          _zipProcessor.Stop();

        if (_insertionQueue.Count > 0 && _insertionQueue.State != ProcessingQueueState.BLOCKED)
        {
          _errorQueue.Pause();
          _insertionQueue.Continue();
        }
        else if (_errorQueue.Count > 0)
        {
          _insertionQueue.Pause();
          _errorQueue.Continue();
        }

        //Console.WriteLine("");
        //Console.WriteLine(string.Format("File processor - Count {0}, Processed {1}, Failed {3}, State {2}", _fileProcessor.Count, _fileProcessor.Processed, _fileProcessor.State.ToString(), _fileProcessor.Failed));
        //Console.WriteLine(string.Format("Input Queue - Count {0}", _inputQueue.Count));
        //Console.WriteLine(string.Format("Insertion Queue - Count {0}, Processed {3}, Failed {1}, State {2}", _insertionQueue.Count, _insertionQueue.Failed, _insertionQueue.State.ToString(), _insertionQueue.Processed));
        //Console.WriteLine(string.Format("Error Queue - Count {0}, Processed {3}, Failed {1}, State {2}", _errorQueue.Count, _errorQueue.Failed, _errorQueue.State.ToString(), _errorQueue.Processed));

        _monitorWait.WaitOne();

        ReviewAndStopQueues();
      }

      _monitorTimer.Stop();
    }

    private void ProcessFiles()
    {
      _insertionQueue.Continue();

      _tasks = new Task[]
      {
        _transferProcessor.Process(),
        _zipProcessor.Process(),
        _fileProcessor.Process(),
        _inputQueue.Process(),
        _insertionQueue.Process(),
        _errorQueue.Process(),

      };

      Task.WaitAll(_tasks);

      ReviewAndStopQueues();
      _transferProcessor.ClearWorkDirectory();
    }

    private void StopQueues()
    {
      _zipProcessor.Stop();
      _fileProcessor.Stop();
      _inputQueue.Stop();
      _insertionQueue.Stop();
      _errorQueue.Stop();
      _transferProcessor.Stop();
    }

    private void ReviewAndStopQueues()
    {
      if (
        (_transferProcessor.Status == FileTransferProcessorStatus.FINISHED ||
        _transferProcessor.Status == FileTransferProcessorStatus.ERROR) &&
        _zipProcessor.Count == 0 &&
        (_zipProcessor.State == ProcessingQueueState.PAUSED ||
        _zipProcessor.State == ProcessingQueueState.STOPPED) &&
        _fileProcessor.Count == 0 &&
        !_fileProcessor.Processing &&
        _inputQueue.Count == 0 &&
        _insertionQueue.Count == 0 &&
        _errorQueue.Count == 0
        )
      {
        StopQueues();
      }
    }

    private void LogPackageError(FileProcessEventArgs args, string handler, string logRemarks)
    {
      long? ptid = args.ObjectId;
      if (ptid.HasValue)
      {
        ProcessTrackingItem pti = _processLogItems.FirstOrDefault(i => i.LogItem.ID == ptid.Value);

        if (pti != null)
        {
          FileProcessLogItem logItem = pti.LogItem;

          long? prevExId = null;
          Exception ex = args.Exception;
          while (ex != null)
          {
            FileProcessError fpe = new FileProcessError()
            {
              FileProcessLogItemId = logItem.ID,
              OuterExceptionId = prevExId,
              OccurredDate = DateTime.Now,
              ErrorType = ex.GetType().Name,
              Message = ex.Message,
              StackTrace = ex.StackTrace,
              Remarks = string.Format("{0}: {1}", handler, logRemarks)
            };

            if (fpe.Insert())
            {
              prevExId = fpe.ID;
              ex = ex.InnerException;
              _log.Info(string.Format("{1}: {2} (Package Name: {0})", logItem.PackageName, handler, logRemarks));
            }
            else
            {
              ex = null;
              _log.Error(string.Format("LogPackageError ({1}): error recording download error for package {0}", logItem.PackageName, handler));
            }
          }

          pti.Status = ProcessTrackingStatus.FAILED;
        }
        else
        {
          //Not sure this is important enough to throw exception, just see it if happens and fix it.
          _log.Error(string.Format("LogPackageError ({0}): record for failed transfer not found in pending items list.", handler));
        }
      }
      else
      {
        //Not sure this is important enough to throw exception, just see it if happens and fix it.
        _log.Error(string.Format("LogPackageError ({0}): record ID for failed transfer not provided.", handler));
      }
    }

    #endregion

    #region Notifications

    private void SendStartNotification()
    {
      string recipList = ConfigurationManager.AppSettings["notification-recipients"];
      if (!string.IsNullOrWhiteSpace(recipList))
      {
        try
        {
          StringBuilder sb = new StringBuilder();
          sb.Append(string.Format("HERE Data Import Service started on {0}\r\n\r\n", DateTime.Now));

          string[] recips = recipList.Split(new char[] { ';' });

          using (SmtpClient client = new SmtpClient())
          {
            MailMessage msg = new MailMessage();
            msg.Subject = "HERE Data Import Service Start Notification";

            foreach (string recip in recips)
              msg.To.Add(new MailAddress(recip));

            msg.Body = sb.ToString();

            client.Send(msg);
          }
        }
        catch (Exception ex)
        {
          _log.Error(string.Format("SendNotification: {2} sending notification, {0}\r\n{1}", ex.Message, ex.StackTrace, ex.GetType().Name));
        }
      }
      else
      {
        _log.Error("SendNotification: notification could not be sent, app setting \"notification-recipients\" not configured");
      }
    }

    private void SendStopNotification()
    {
      string recipList = ConfigurationManager.AppSettings["notification-recipients"];
      if (!string.IsNullOrWhiteSpace(recipList))
      {
        try
        {
          StringBuilder sb = new StringBuilder();
          sb.Append(string.Format("HERE Data Import Service stopped on {0}\r\n\r\n", DateTime.Now));
          sb.Append(string.Format("More information may be available in the log file, located at {0}", _config.PathConfiguration.ServiceLogPath));

          string[] recips = recipList.Split(new char[] { ';' });

          using (SmtpClient client = new SmtpClient())
          {
            MailMessage msg = new MailMessage();
            msg.Subject = "HERE Data Import Service Stop Notification";

            foreach (string recip in recips)
              msg.To.Add(new MailAddress(recip));

            msg.Body = sb.ToString();

            client.Send(msg);
          }
        }
        catch (Exception ex)
        {
          _log.Error(string.Format("SendNotification: {2} sending notification, {0}\r\n{1}", ex.Message, ex.StackTrace, ex.GetType().Name));
        }
      }
      else
      {
        _log.Error("SendNotification: notification could not be sent, app setting \"notification-recipients\" not configured");
      }
    }

    private void SendNetworkErrorNotification(string errorCodeMessage)
    {
      string recipList = ConfigurationManager.AppSettings["notification-recipients"];
      if (!string.IsNullOrWhiteSpace(recipList))
      {
        try
        {
          StringBuilder sb = new StringBuilder();
          sb.Append(string.Format("HERE Data Import Process network interruption beginning at {0}\r\n\r\n", _networkRecoveryStartTime));
          sb.Append(string.Format("Network interruption duration currently is {0}\r\n", DateTime.Now - _networkRecoveryStartTime));
          if (!string.IsNullOrWhiteSpace(errorCodeMessage))
            sb.Append(string.Format("Most recent network error was {0}\r\n", errorCodeMessage));

          string[] recips = recipList.Split(new char[] { ';' });

          using (SmtpClient client = new SmtpClient())
          {
            MailMessage msg = new MailMessage();
            msg.Subject = "HERE Data Import Process Interruption";

            foreach (string recip in recips)
              msg.To.Add(new MailAddress(recip));

            msg.Body = sb.ToString();

            client.Send(msg);
          }
        }
        catch (Exception ex)
        {
          _log.Error(string.Format("SendNetworkErrorNotification: {2} sending notification, {0}\r\n{1}", ex.Message, ex.StackTrace, ex.GetType().Name));
        }
      }
      else
      {
        _log.Error("SendNetworkErrorNotification: notification could not be sent, app setting \"notification-recipients\" not configured");
      }
    }

    private void SendNetworkErrorRecoveryNotification(string recoveryMessage)
    {
      string recipList = ConfigurationManager.AppSettings["notification-recipients"];
      if (!string.IsNullOrWhiteSpace(recipList))
      {
        try
        {
          StringBuilder sb = new StringBuilder();
          sb.Append(string.Format("HERE Data Import Process has recovery from network interruption at {0}\r\n\r\n", DateTime.Now));
          sb.Append(string.Format("Network interruption total duration is {0}\r\n", DateTime.Now - _networkRecoveryStartTime));
          if (!string.IsNullOrWhiteSpace(recoveryMessage))
            sb.Append(recoveryMessage);

          string[] recips = recipList.Split(new char[] { ';' });

          using (SmtpClient client = new SmtpClient())
          {
            MailMessage msg = new MailMessage();
            msg.Subject = "HERE Data Import Process Interruption Recovery";

            foreach (string recip in recips)
              msg.To.Add(new MailAddress(recip));

            msg.Body = sb.ToString();

            client.Send(msg);
          }
        }
        catch (Exception ex)
        {
          _log.Error(string.Format("SendNetworkErrorRecoveryNotification: {2} sending notification, {0}\r\n{1}", ex.Message, ex.StackTrace, ex.GetType().Name));
        }
      }
      else
      {
        _log.Error("SendNetworkErrorRecoveryNotification: notification could not be sent, app setting \"notification-recipients\" not configured");
      }
    }

    #endregion

    #region Event handlers

    #region Transfer

    private void TransferStartHandler(object sender, FileProcessEventArgs args)
    {
      string pkgName = Path.GetFileName(args.FilePath);
      FileProcessLogItem logItem = new FileProcessLogItem()
      {
        PackageName = pkgName,
        SessionTimestamp = args.FileTimestamp.Value
      };

      _processLogItems.Add(new ProcessTrackingItem() { LogItem = logItem, Status = ProcessTrackingStatus.DOWNLOADING });
      if (logItem.Insert())
      {
        //Pass the record ID back to the event publisher (transfer processor).
        args.ObjectId = logItem.ID;
        _log.Info(string.Format("TransferStartHandler: start package {0} download at {1}", logItem.PackageName, DateTime.Now));

        if (logItem.UpdateField("SessionTimestamp"))
          _log.Info(string.Format("TransferStartHandler: recorded session timestamp {0} for package {1}", logItem.SessionTimestamp, logItem.PackageName));
        else
          _log.Error($"TransferStartHandler: error recording session timestamp {logItem.SessionTimestamp} for package {logItem.PackageName}");
      }
      else
      {
        _log.Error(string.Format("TransferStartHandler: error recording start of package {0} download", logItem.PackageName));
      }
    }

    private void TransferCompleteHandler(object sender, FileProcessEventArgs args)
    {
      long? oid = args.ObjectId;
      if (oid.HasValue)
      {
        ProcessTrackingItem pti = _processLogItems.FirstOrDefault(i => i.LogItem.ID == oid.Value);
        if (pti != null)
        {
          FileProcessLogItem logItem = pti.LogItem;
          logItem.DownloadDate = DateTime.Now;
          if (logItem.UpdateField("DownloadDate"))
            _log.Info(string.Format("TransferCompleteHandler: recorded finish package {1}, ID {0}, download at {2}",
              logItem.ID, logItem.PackageName, logItem.DownloadDate));
          else
            _log.Error(string.Format("TransferCompleteHandler: error recording finish of package {0} download", logItem.PackageName));


          pti.Status = ProcessTrackingStatus.EXTRACTING;
          _zipProcessor.Enqueue(logItem);
        }
        else
        {
          _log.Error(string.Format("TransferCompleteHandler: record for completed transfer, {0},  not found in pending items list.", oid.Value));
        }
      }
      else
      {
        _log.Error("TransferCompleteHandler: record ID for completed transfer not provided.");
      }

      if (_maxDownloadCycles > 0)
      {
        //Don't count cycles unless a max cycle count is configured.
        _downloadCycleCount++;
        if (_downloadCycleCount >= _maxDownloadCycles)
        {
          _transferProcessor.Stop();
        }
      }
    }

    private void TransferNoWorkHandler(object sender, FileProcessEventArgs args)
    {
      _log.Info("TransferNoWorkHandler: no files to download, shutting down.");
      ReviewAndStopQueues();
    }

    private void TransferErrorHandler(object sender, FileProcessEventArgs args)
    {
      _transferProcessor.Stop();

      string msg = "Processing error during download of package";
      LogPackageError(args, "TransferErrorHandler", msg);
    }

    private void TransferFatalHandler(object sender, FileProcessEventArgs args)
    {
      _log.Error(string.Format("TransferFatalHandler: Fatal exception {0} encountered in transfer processor, process cannot continue.\r\n{1}\r\n{2}",
        args.Exception.GetType().Name, args.Exception.Message, args.Exception.StackTrace));

      StopQueues();
    }

    private void TransferNetworkErrorHandler(object sender, FileProcessEventArgs args)
    {
      if (!_networkRecovery)
      {
        //Enter network recovery mode
        _networkRecovery = true;
        _networkRecoveryStartTime = DateTime.Now;
        //Just record the start of interval, do not send notification yet.
        _networkRecoveryLastNotificationTime = _networkRecoveryStartTime;
        _log.Info(string.Format("Network error recovery mode entered at {0}", _networkRecoveryStartTime));
      }
      else if (DateTime.Now - _networkRecoveryLastNotificationTime >= _networkRecoveryNotificationInterval)
      {
        string errorMsg = null;
        if (args.Exception is WebException)
        {
          HttpWebResponse resp = (HttpWebResponse)((WebException)args.Exception).Response;
          errorMsg = resp == null ? string.Empty : string.Format("\r\nResponse Status Code: {0}, Status Description: {1}", resp.StatusCode, resp.StatusDescription);
        }

        SendNetworkErrorNotification(errorMsg);
        _networkRecoveryLastNotificationTime = DateTime.Now;
        _log.Info(string.Format("Network error notification sent at {0}", _networkRecoveryLastNotificationTime));
      }
      else
      {
        _log.Info("Network error still not recovered");
      }
    }

    private void TransferNetworkErrorRecoveryHandler(object sender, FileProcessEventArgs args)
    {
      //Exit network recovery mode.
      _networkRecovery = false;
      if (_networkRecoveryLastNotificationTime > _networkRecoveryStartTime) //meaning at least one notification has been sent.
      {
        string msg = string.Format("The file {0} has been successfully downloaded", args.FilePath);
        SendNetworkErrorRecoveryNotification(msg);
        _networkRecoveryLastNotificationTime = DateTime.Now;
      }
    }

    #endregion

    #region Extraction

    private void ExtractionCompleteHandler(object sender, FileProcessEventArgs args)
    {
      long? oid = args.ObjectId;
      if (oid.HasValue)
      {
        ProcessTrackingItem pti = _processLogItems.FirstOrDefault(i => i.LogItem.ID == oid.Value);
        if (pti != null)
        {
          FileProcessLogItem logItem = pti.LogItem;
          logItem.ExtractionDate = DateTime.Now;
          if (logItem.UpdateField("ExtractionDate"))
            _log.Info(string.Format("ExtractionCompleteHandler: recorded finished package {0}, ID {1}, extraction at {2}",
              logItem.PackageName, logItem.ID, logItem.ExtractionDate));
          else
            _log.Error(string.Format("ExtractionCompleteHandler: error recording finish of package {0} extraction", logItem.PackageName));

          logItem.FileName = Path.GetFileName(args.FilePath);
          if (logItem.UpdateField("FileName"))
            _log.Info(string.Format("ExtractionCompleteHandler: recorded finished package {0}, ID {1}, file name: {2}",
              logItem.PackageName, logItem.ID, logItem.FileName));
          else
            _log.Error(string.Format("ExtractionCompleteHandler: error recording file name of package {0}", logItem.PackageName));

          pti.Status = ProcessTrackingStatus.PROCESSING;
          _fileProcessor.Enqueue(logItem);
        }
        else
        {
          _log.Error(string.Format("ExtractionCompleteHandler: record for completed extraction, {0},  not found in pending items list.", oid.Value));
        }
      }
      else
      {
        _log.Error("ExtractionCompleteHandler: record ID for completed extraction not provided.");
      }
    }

    private void ExtractionFailedHandler(object sender, FileProcessEventArgs args)
    {
      LogPackageError(args, "ExtractionFailedHandler", "Processing error during extraction");
      long? oid = args.ObjectId;
      if (oid.HasValue)
      {
        ProcessTrackingItem pti = _processLogItems.FirstOrDefault(i => i.LogItem.ID == oid.Value);
        if (pti != null)
          pti.Status = ProcessTrackingStatus.FAILED;
        else
          _log.Error(string.Format("ExtractionFailedHandler: record for completed extraction, {0},  not found in pending items list.", oid.Value));
      }
      else
      {
        _log.Error("ExtractionFailedHandler: record ID for completed extraction not provided.");
      }

      //If no other work is being done, it's time to quit.
      //(If EventType is FILE_ERROR, one package could not be extracted, but there could be more packages.
      //  Furthermore, the package still needs to be archived, so we don't want to quit yet. The local archive
      //  events will trigger the review.)
      if (args.EventType == FileProcessEventType.PROCESS_ERROR)
        ReviewAndStopQueues();
    }

    private void LocalArchiveCompleteHandler(object sender, FileProcessEventArgs args)
    {
      long? oid = args.ObjectId;
      if (oid.HasValue)
      {
        ProcessTrackingItem pti = _processLogItems.FirstOrDefault(i => i.LogItem.ID == oid.Value);
        if (pti != null)
        {
          FileProcessLogItem logItem = pti.LogItem;
          logItem.ArchiveDate = DateTime.Now;
          logItem.ArchiveLocation = args.FilePath;
          if (logItem.UpdateField("ArchiveDate"))
            _log.Info(string.Format("LocalArchiveCompleteHandler: recorded finish package {1}, ID {0}, archive at {2}",
              logItem.ID, logItem.PackageName, logItem.DownloadDate));
          else
            _log.Error(string.Format("LocalArchiveCompleteHandler: error recording finish of package {0} archive", logItem.PackageName));
          if (logItem.UpdateField("ArchiveLocation"))
            _log.Info(string.Format("LocalArchiveCompleteHandler: recorded package {1}, ID {0}, archive location at {2}",
              logItem.ID, logItem.PackageName, logItem.DownloadDate));
          else
            _log.Error(string.Format("LocalArchiveCompleteHandler: error recording package {0} archive location", logItem.PackageName));
        }
        else
        {
          _log.Error(string.Format("LocalArchiveCompleteHandler: record for completed extraction, {0},  not found in pending items list.", oid.Value));
        }
      }
      else
      {
        _log.Error("LocalArchiveCompleteHandler: record ID for completed extraction not provided.");
      }

      //If no other work is being done, it's time to quit.
      ReviewAndStopQueues();
    }

    private void LocalArchiveFailedHandler(object sender, FileProcessEventArgs args)
    {
      Console.WriteLine("Local archive of {0} failed", args.FilePath);

      LogPackageError(args, "LocalArchiveFailedHandler", "Processing error during local archive");

      //If no other work is being done, it's time to quit.
      ReviewAndStopQueues();
    }

    #endregion

    #region Import

    private void FileImportStartHandler(object sender, FileProcessEventArgs args)
    {
      _log.Info(string.Format("FileImportStartHandler: {0}: {1}", FILE_IMPORT_START_MSG, args.FilePath));
    }

    private void FileImportCompleteHandler(object sender, FileProcessEventArgs args)
    {
      _log.Info(string.Format("{0}: {1}", FILE_IMPORT_COMPLETE_MSG, args.FilePath));

      long? oid = args.ObjectId;
      if (oid.HasValue)
      {
        ProcessTrackingItem pti = _processLogItems.FirstOrDefault(i => i.LogItem.ID == oid.Value);
        if (pti != null)
        {
          pti.Status = ProcessTrackingStatus.DONE;
          FileProcessLogItem logItem = pti.LogItem;
          logItem.ProcessDate = DateTime.Now;
          logItem.NumberProcessed = _fileProcessor.Processed;
          logItem.NumberFailed = _fileProcessor.Failed;
          logItem.FileCreatedTimestamp = args.FileTimestamp.Value;
          if (logItem.UpdateField("FileCreatedTimestamp"))
            _log.Info(string.Format("FileImportCompleteHandler: recorded file created timestamp {0} for package {1}", logItem.FileCreatedTimestamp, logItem.PackageName));
          else
            _log.Error($"FileImportCompleteHandler: error recording file created timestamp {logItem.FileCreatedTimestamp} for package {logItem.PackageName}");
          if (logItem.UpdateProcessCompletionFields())
            _log.Info(string.Format("FileImportCompleteHandler: recorded finish package {1}, ID {0}, import process completion at {2}",
              logItem.ID, logItem.PackageName, logItem.DownloadDate));
          else
            _log.Error(string.Format("FileImportCompleteHandler: error recording import process completion of package {0} archive", logItem.PackageName));

          _inputQueue.ResetStatistics();

          _processLogItems.Remove(pti); //otherwise the list will grow indefinitely.
        }
        else
        {
          _log.Error(string.Format("FileImportCompleteHandler: record for import process completion, {0},  not found in pending items list.", oid.Value));
        }
      }
      else
      {
        _log.Error("FileImportCompleteHandler: record ID for import process completion not provided.");
      }
    }

    private void FileImportFailedHandler(object sender, FileProcessEventArgs args)
    {
      long? oid = args.ObjectId;
      if (oid.HasValue)
      {
        ProcessTrackingItem pti = _processLogItems.FirstOrDefault(i => i.LogItem.ID == oid.Value);
        if (pti != null)
          pti.Status = ProcessTrackingStatus.FAILED;
      }

      _log.Info(string.Format("FileImportFailedHandler: {0}: {1}", FILE_IMPORT_FAILED_MSG, args.FilePath));
    }

    private void RecordImportFailedHandler(object sender, FileProcessEventArgs args)
    {
      //There was a problem with a specific Incident. Don't need to fail the whole process.
      _log.Info("RecordImportFailedHandler: failure noted, should be handled.");
    }

    #endregion

    #region Queue events

    private void InputQueueEventHandler(object sender, ProcessingQueueEventArgs args)
    {
      switch (args.EventType)
      {
        case ProcessingQueueEventType.QUEUE_BLOCKED:
          break;
        case ProcessingQueueEventType.QUEUE_STOPPED:
          _insertionQueue.Stop();
          _errorQueue.Stop();
          break;
        case ProcessingQueueEventType.QUEUE_EMPTY:
          if (_fileProcessor.Count == 0)
            ReviewAndStopQueues();
          break;
      }
    }

    private void InsertionQueueEventHandler(object sender, ProcessingQueueEventArgs args)
    {
      switch (args.EventType)
      {
        case ProcessingQueueEventType.QUEUE_BLOCKED:
          Console.WriteLine("Insertion queue blocked");
          break;
        case ProcessingQueueEventType.QUEUE_AVAILABLE:
        case ProcessingQueueEventType.QUEUE_READY:
          Console.WriteLine("Insertion queue ready");
          break;
        case ProcessingQueueEventType.QUEUE_STOPPED:
          Console.WriteLine("Insertion queue stopped");
          break;
        case ProcessingQueueEventType.QUEUE_FULL:
          Console.WriteLine("Insertion queue full");
          break;
        case ProcessingQueueEventType.QUEUE_EMPTY:
          if (_errorQueue.Count > 0)
            _errorQueue.Continue();
          else
            ReviewAndStopQueues();
          break;
      }
    }

    private void ErrorQueueEventHandler(object sender, ProcessingQueueEventArgs args)
    {
      switch (args.EventType)
      {
        case ProcessingQueueEventType.QUEUE_BLOCKED:
          Console.WriteLine("Error queue blocked");
          break;
        case ProcessingQueueEventType.QUEUE_AVAILABLE:
        case ProcessingQueueEventType.QUEUE_READY:
          Console.WriteLine("Error queue ready");
          break;
        case ProcessingQueueEventType.QUEUE_STOPPED:
          Console.WriteLine("Error queue stopped");
          break;
        case ProcessingQueueEventType.QUEUE_FULL:
          Console.WriteLine("Error queue full");
          break;
        case ProcessingQueueEventType.QUEUE_EMPTY:
          if (_insertionQueue.Count > 0)
            _insertionQueue.Continue();
          else
            ReviewAndStopQueues();
          break;
      }
    }

    #endregion

    #endregion
  }
}
