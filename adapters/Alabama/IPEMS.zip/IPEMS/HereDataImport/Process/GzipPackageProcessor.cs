﻿using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

using HereDataImport.Model.Processing;
using HereDataImport.Process.Events;

namespace HereDataImport.Process
{
  public class GzipPackageProcessor : ProcessingQueue<FileProcessLogItem, object>
  {
    private string _localArchDir, _localWorkDir, _internalPackagePath, _zipExePath;

    public GzipPackageProcessor() : base()
    {
      _localArchDir = _config.PathConfiguration.LocalArchiveDirectory;
      _localWorkDir = _config.PathConfiguration.LocalWorkDirectory;
      _internalPackagePath = _config.PathConfiguration.InternalTargetPath;
      _zipExePath = _config.PathConfiguration.ZipExecutablePath;

      _maxQueueLen = int.MaxValue; //Not expected to be more than a few.

      _state = ProcessingQueueState.READY;
    }

    #region Events

    public event FileProcessEventHandler FileExtractionCompleted;
    public event FileProcessEventHandler FileExtractionFailed;
    public event FileProcessEventHandler FileArchiveCompleted;
    public event FileProcessEventHandler FileArchiveFailed;

    #endregion

    #region Work procedures

    protected override void _process()
    {
      _log.Info("_process: Zip Package Processor process starting");
      _run = true;
      _processed = 0;

      while (_run)
      {
        if (_pause || _queue.Count == 0)
        {
          _state = ProcessingQueueState.PAUSED;
          _pause = true;
          _log.Debug("_wait");
          _wait.WaitOne();
          _state = ProcessingQueueState.READY;
        }

        while (_queue.Count > 0)
        {
          bool procErr = false; //Flag to suppress archiving if previous error occurred.

          FileProcessLogItem item = _queue.Dequeue();
          string pkgPath = Path.Combine(_localWorkDir, item.PackageName);

          try
          {
            if (File.Exists(pkgPath))
            {
              string xmlName = Path.GetFileNameWithoutExtension(item.PackageName);
              string extrPath = Path.GetFileNameWithoutExtension(xmlName);
              //Where to put the extracted files
              string extractionDir = Path.Combine(_localWorkDir, extrPath);
              //The path to the xml file after extraction, including the working directory,
              // root zip folder, any path internal to the zip file, and the xml file name.
              string xmlFullPath = Path.Combine(extractionDir, xmlName);
              //Where the extracted xml file should end up (e.g., in the working directory).
              string finalFullPath = Path.Combine(_localWorkDir, xmlName);

              //A zip file, xxx.zip, in work dir d:\work will be extracted into <appdir>\work\<filename>.<ticks>
              //As per current project specifics, after extraction, the package <appdir>\work\<filename>.<ticks>.xml.gz will be extracted into
              //  <appdir>\work\<filename>.<ticks>\<filename>.<ticks>.xml, which will be moved to
              //  <appdir>\work\<filename>.<ticks>.xml and the extraction folder, <appdir>\work\<filename>.<ticks> will be deleted with its contents.

              //Parameters:
              //  x: extract command
              //  -y: assume answer to any dialog questions is "yes"
              //  -o: output directory
              //  extaction target
              string processParams = string.Format("x -y -o{0} {1}", extractionDir, pkgPath);
              // _zipExePath: path to 7z.exe (7-zip)
              System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo(_zipExePath, processParams);
              psi.UseShellExecute = false;
              psi.RedirectStandardOutput = true;
              System.Diagnostics.Process zp = new System.Diagnostics.Process() { StartInfo = psi };
              zp.Start();
              _log.Info(zp.StandardOutput.ReadToEnd());
              zp.WaitForExit(10000);

              if (File.Exists(xmlFullPath))
              {
                File.Move(xmlFullPath, finalFullPath);
                Directory.Delete(extractionDir, true);

                _log.Info(string.Format("_process: package {0} extraction completed", pkgPath));

                FileProcessEventArgs args = new FileProcessEventArgs(finalFullPath, FileProcessEventType.EXTRACTION, null, item.ID);
                OnFileExtractionCompleted(args);
              }
              else
              {
                //we didn't find the xml file, now what?
                _log.Error(string.Format("_process: package {0} extracted but target file {1} not found in package", pkgPath, xmlFullPath));

                FileProcessEventArgs args = new FileProcessEventArgs(pkgPath, FileProcessEventType.FILE_ERROR, null, item.ID);
                OnFileExtractionFailed(args);
              }
            }
          }
          catch (Exception ex)
          {
            procErr = true;
            _log.Error("_process: error extracting package {0}: {1} - {2}\r\n{3}", pkgPath, ex.GetType().Name, ex.Message, ex.StackTrace);

            FileProcessEventArgs args = new FileProcessEventArgs(pkgPath, FileProcessEventType.PROCESS_ERROR, ex, item.ID);
            OnFileExtractionFailed(args);
          }

          if (!procErr)
          {
            try
            {
              string archYear = DateTime.Now.Year.ToString("0000"), archMonth = DateTime.Now.Month.ToString("00"), archDay = DateTime.Now.Day.ToString("00"),
                archHour = DateTime.Now.Hour.ToString("00");
              string archiveDirectory = Path.Combine(_localArchDir, archYear, archMonth, archDay, archHour);
              if (!Directory.Exists(archiveDirectory))
                Directory.CreateDirectory(archiveDirectory);

              //Prepare to generate a unique name for the archived package in the event
              //there is already a package with the same name in the archive.
              string packageBaseName = Path.GetFileNameWithoutExtension(item.PackageName);
              string packageExtn = Path.GetExtension(item.PackageName);
              int archiveVersion = 0;
              string archivePath = null, packageVersionName = null;
              do
              {
                packageVersionName = string.Format("{0}{1}{2}", //Path.GetExtension() includes the "."
                  packageBaseName,
                  archiveVersion > 0 ? string.Format(".{0}", archiveVersion) : string.Empty,
                  packageExtn);
                archiveVersion++;
                item.PackageName = packageVersionName;
                archivePath = Path.Combine(archiveDirectory, item.PackageName);
              } while (File.Exists(archivePath));

              File.Move(pkgPath, archivePath);

              _log.Info(string.Format("_process: package {0} local archive completed", archivePath));

              FileProcessEventArgs args = new FileProcessEventArgs(archivePath, FileProcessEventType.EXTRACTION, null, item.ID);
              OnFileArchiveCompleted(args);
            }
            catch (Exception ex)
            {
              _log.Error("_process: error archiving package {0}: {1} - {2}\r\n{3}", pkgPath, ex.GetType().Name, ex.Message, ex.StackTrace);

              FileProcessEventArgs args = new FileProcessEventArgs(pkgPath, FileProcessEventType.PROCESS_ERROR, ex, item.ID);
              OnFileArchiveFailed(args);
            }
          }
        }
      }

      _state = ProcessingQueueState.STOPPED;
    }

    #endregion

    #region Fire events

    protected virtual void OnFileExtractionCompleted(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileExtractionCompleted;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileExtractionFailed(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileExtractionFailed;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileArchiveCompleted(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileArchiveCompleted;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileArchiveFailed(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = FileArchiveFailed;

      if (handler != null)
        handler(this, args);
    }

    #endregion
  }
}
