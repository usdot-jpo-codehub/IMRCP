﻿using System;
using System.Threading;
using System.Threading.Tasks;

using HereDataImport.Model;
using HereDataImport.Process.Events;

namespace HereDataImport.Process
{
  public class InsertionQueue : ProcessingQueue<TmcItem, TmcItem.TmcItemResult>
  {
    private bool _eqPause, _eqFull;
    private EventWaitHandle _eqWait;

    public InsertionQueue(ProcessingQueue<TmcItem, TmcItem.TmcItemResult> errorQueue) : base()
    {
      _maxQueueLen = _config.InsertionQueueConfiguration.MaximumQueueLength;
      if (_config.InsertionQueueConfiguration.QueueAvailableLength != 0)
        _queueAvailableLen = _config.InsertionQueueConfiguration.QueueAvailableLength;
      else
        _queueAvailableLen = (int)(_maxQueueLen * .9);
      _maxProcesses = _config.InsertionQueueConfiguration.MaximumProcesses;

      _eqPause = _eqFull = false;
      _eqWait = new EventWaitHandle(false, EventResetMode.AutoReset);

      _nextQueue = errorQueue;
      _nextQueue.QueueEvent += ErrorQueueEventHandler;
    }

    public override void Stop()
    {
      base.Stop();
      _eqPause = false;
      _eqWait.Set();
    }

    protected override async void _process()
    {
      _log.Info("_process: Insertion queue process starting.");
      _run = true;
      _processed = 0;

      while (_run)
      {
        try
        {
          //_pause could be set externally by the Pause method command.
          if (_pause || _queue.Count + _processes.Count == 0)
          {
            if (_queue.Count + _processes.Count == 0)
            {
              OnQueueEvent(ProcessingQueueEventType.QUEUE_EMPTY);
              if (_statReset)
              {
                _log.Info(string.Format("{0} statistics for current file: processed - {1}, failed - {2}", this.GetType().Name, _processed.ToString(), _failed.ToString()));
                _processed = 0;
                _failed = 0;
                _statReset = false;
                _nextQueue.ResetStatistics();
              }
            }
            _state = ProcessingQueueState.PAUSED;
            _pause = true;
            _log.Debug("_wait");
            _wait.WaitOne();
          }

          while (_queue.Count > 0 && _processes.Count <= _maxProcesses)
          {
            TmcItem currentItem = null;
            try
            {
              lock (_qlock)
              {
                currentItem = _queue.Dequeue();
              }
              if (currentItem != null)
              {
                Task<TmcItem.TmcItemResult> currentTask = currentItem.InsertWithResultAsync();
                _processes.Add(currentTask);
              }
              if (_full && _queue.Count <= _queueAvailableLen)
              {
                _full = false;
                OnQueueEvent(ProcessingQueueEventType.QUEUE_AVAILABLE);
              }
            }
            catch (Exception ex)
            {
              _log.Error(string.Format("_process - error adding process: {0}\r\n{1}", ex.Message, ex.StackTrace));
              if (currentItem != null)
              {
                if (_eqFull)
                {
                  _state = ProcessingQueueState.BLOCKED;
                  OnQueueEvent(ProcessingQueueEventType.QUEUE_BLOCKED);
                  _eqPause = true;
                  _log.Debug("_eqWait");
                  _eqWait.WaitOne();
                }
                ((ProcessingQueue<TmcItem, TmcItem.TmcItemResult>)_nextQueue).Enqueue(currentItem);
                _failed++;
              }
            }
          }

          if (_processes.Count > 0)
          {
            //Finish at least one process, but whatever it takes to go below max.
            do
            {
              Task<TmcItem.TmcItemResult> nextResult = await Task.WhenAny(_processes);
              _processes.Remove(nextResult);
              if (nextResult.Result.Result)
              {
                _processed++;
              }
              else
              {
                if (_eqFull)
                {
                  _state = ProcessingQueueState.BLOCKED;
                  OnQueueEvent(ProcessingQueueEventType.QUEUE_BLOCKED);
                  _eqPause = true;
                  _log.Debug("_eqWait");
                  _eqWait.WaitOne();
                }
                ((ProcessingQueue<TmcItem, TmcItem.TmcItemResult>)_nextQueue).Enqueue(nextResult.Result.TmcItem);
                _failed++;
              }
            } while (_processes.Count >= _maxProcesses);
          }
        }
        catch (Exception ex)
        {
          _log.Error(string.Format("_process: {0}\r\n{1}", ex.Message, ex.StackTrace));
          _run = false;
          _state = ProcessingQueueState.STOPPED;

          OnQueueEvent(ProcessingQueueEventType.QUEUE_STOPPED);
        }
      }

      _log.Info("_process: Insertion queue process stopping.");
    }

    private void ErrorQueueEventHandler(object sender, ProcessingQueueEventArgs args)
    {
      switch (args.EventType)
      {
        case ProcessingQueueEventType.QUEUE_READY:
        case ProcessingQueueEventType.QUEUE_EMPTY:
        case ProcessingQueueEventType.QUEUE_AVAILABLE:
          _eqFull = false;
          if (_eqPause)
          {
            _eqPause = false;
            _eqWait.Set();
          }
          break;
        case ProcessingQueueEventType.QUEUE_FULL:
          _eqFull = true;
          break;
        case ProcessingQueueEventType.QUEUE_STOPPED:
          _run = false;
          _state = ProcessingQueueState.STOPPED;
          OnQueueEvent(ProcessingQueueEventType.QUEUE_STOPPED);
          break;
      }
    }
  }
}
