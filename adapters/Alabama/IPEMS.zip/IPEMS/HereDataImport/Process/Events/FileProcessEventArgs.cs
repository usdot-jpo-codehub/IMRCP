﻿using System;

namespace HereDataImport.Process.Events
{
  public enum FileProcessEventType
  {
    TRANSFER,
    EXTRACTION,
    ARCHIVE,
    IMPORT,
    ITEM_ERROR,
    FILE_ERROR,
    PROCESS_ERROR,
    PROCESS_FINISHED
  }

  public delegate void FileProcessEventHandler(object sender, FileProcessEventArgs args);

  public class FileProcessEventArgs : EventArgs
  {
    private string _filePath;
    private long? _objectId;
    private FileProcessEventType _eventType;
    private Exception _exception;

    public FileProcessEventArgs(string filePath, FileProcessEventType eventType, Exception ex, long? objectId = null)
    {
      _filePath = filePath;
      _eventType = eventType;
      _exception = ex;
      _objectId = objectId;
    }

    public string FilePath { get { return _filePath; } }

    //For passing timestamps from processors to controller
    public DateTime? FileTimestamp { get; set; }

    public FileProcessEventType EventType { get { return _eventType; } }

    public Exception Exception { get { return _exception; } }

    //Provide a setter to permit the controller (subscriber) to update the Object ID 
    // after the File Process Log Item has been created in the database, as a way to
    // pass back that value to the transfer processor (publisher) in order to be able
    // to provide that information in further events.
    public long? ObjectId { get { return _objectId; } set { _objectId = value; } }
  }
}
