﻿namespace HereDataImport.Process.Events
{
  public enum ProcessingQueueEventType
  {
    QUEUE_READY,
    QUEUE_FULL,
    QUEUE_EMPTY,
    QUEUE_AVAILABLE,
    QUEUE_BLOCKED,
    QUEUE_STOPPED
  }

  public delegate void ProcessingQueueEventHandler(object sender, ProcessingQueueEventArgs args);

  public class ProcessingQueueEventArgs
  {
    private ProcessingQueueEventType _eventType;

    public ProcessingQueueEventArgs(ProcessingQueueEventType eventType)
    {
      _eventType = eventType;
    }

    public ProcessingQueueEventType EventType { get { return _eventType; } }
  }
}
