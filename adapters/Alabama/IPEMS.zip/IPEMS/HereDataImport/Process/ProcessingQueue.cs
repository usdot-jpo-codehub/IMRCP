﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using NLog;

using HereDataImport.Configuration;
using HereDataImport.Model;
using HereDataImport.Process.Events;

namespace HereDataImport.Process
{
  public enum ProcessingQueueState
  {
    READY,
    PAUSED,
    BLOCKED,
    FULL,
    STOPPED
  }

  public abstract class ProcessingQueue
  {
    public event ProcessingQueueEventHandler QueueEvent;

    protected Logger _log;
    protected DataImportConfigurationSection _config;

    protected int _processed, _failed;
    protected bool _run, _pause, _xPause, _full, _statReset;
    protected EventWaitHandle _wait;

    protected ProcessingQueue _nextQueue;

    protected ProcessingQueueState _state;

    public ProcessingQueue()
    {
      _log = LogManager.GetLogger(this.GetType().Name);
      _config = DataImportConfigurationSection.Instance;

      _run = true;
      _pause = _xPause = _full = false;
      _wait = new EventWaitHandle(false, EventResetMode.AutoReset);

      _state = ProcessingQueueState.READY;
      _statReset = false;
    }

    public int Processed { get { return _processed; } }

    public int Failed { get { return _failed; } }

    public abstract int Count { get; }

    public void ResetStatistics()
    {
      if (Count > 0)
      {
        //If the processor is not empty, set a flag to reset after it finishes processing.
        _statReset = true;
      }
      else
      {
        _log.Info(string.Format("{0} statistics for current file: processed - {1}, failed - {2}", this.GetType().Name, _processed.ToString(), _failed.ToString()));
        _processed = 0;
        _failed = 0;
        if (_nextQueue != null)
          _nextQueue.ResetStatistics();
      }
    }

    public ProcessingQueueState State { get { return _state; } }

    public void Pause()
    {
      _pause = _xPause = true;
      _state = ProcessingQueueState.PAUSED;
    }

    public virtual void Continue()
    {
      _xPause = false;

      if (_pause)
      {
        _state = ProcessingQueueState.READY;
        _pause = false;
        _log.Debug("Continue: _wait cleared");
        _wait.Set();
      }
    }

    public virtual void Stop()
    {
      _state = ProcessingQueueState.STOPPED;
      _run = _pause = _xPause = false;
      _wait.Set();
    }

    public virtual async Task Process()
    {
      await Task.Run(() => _process());
    }

    protected abstract void _process();

    protected void OnQueueEvent(ProcessingQueueEventType eventType)
    {
      ProcessingQueueEventHandler handler = QueueEvent;

      if (handler != null)
      {
        ProcessingQueueEventArgs args = new ProcessingQueueEventArgs(eventType);
        handler(this, args);
      }
    }
  }

  public abstract class ProcessingQueue<TQueueType, TProcessTaskType> : ProcessingQueue
  {
    protected int _maxQueueLen, _queueAvailableLen, _maxProcesses;
    protected object _qlock;
    protected Queue<TQueueType> _queue;
    protected List<Task<TProcessTaskType>> _processes;

    public ProcessingQueue() : base()
    {
      _qlock = new object();
      _queue = new Queue<TQueueType>();
      _processes = new List<Task<TProcessTaskType>>();
    }

    public void Enqueue(TQueueType item)
    {
      lock (_qlock)
      {
        _queue.Enqueue(item);
      }

      if (_pause && !_xPause)
      {
        _state = ProcessingQueueState.READY;
        _pause = false;
        _wait.Set();
      }

      if (_queue.Count >= _maxQueueLen)
      {
        _full = true;
        OnQueueEvent(ProcessingQueueEventType.QUEUE_FULL);
      }
    }

    public override int Count { get { return _queue.Count + _processes.Count; } }
  }
}
