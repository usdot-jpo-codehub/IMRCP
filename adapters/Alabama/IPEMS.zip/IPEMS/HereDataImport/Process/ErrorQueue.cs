﻿using System;
using System.Threading.Tasks;

using HereDataImport.Model;
using HereDataImport.Model.Processing;
using HereDataImport.Process.Events;

namespace HereDataImport.Process
{
  public class ErrorQueue : ProcessingQueue<TmcItem, TmcItem.TmcItemResult>
  {
    private int _maxRetryAttempts;

    public ErrorQueue() : base()
    {
      _maxQueueLen = _config.ErrorQueueConfiguration.MaximumQueueLength;
      if (_config.ErrorQueueConfiguration.QueueAvailableLength != 0)
        _queueAvailableLen = _config.ErrorQueueConfiguration.QueueAvailableLength;
      else
        _queueAvailableLen = (int)(_maxQueueLen * .9);
      _maxProcesses = _config.ErrorQueueConfiguration.MaximumProcesses;

      if (_config.ErrorQueueConfiguration.MaximumRetryAttempts != 0)
        _maxRetryAttempts = _config.ErrorQueueConfiguration.MaximumRetryAttempts;
      else
        _maxRetryAttempts = 1;
    }

    protected override async void _process()
    {
      _log.Info("_process: Error queue process starting.");
      _run = true;
      _processed = 0;

      while (_run)
      {
        try
        {
          //_pause could be set externally by the Pause method command.
          if (_pause || _queue.Count + _processes.Count == 0)
          {
            if (_queue.Count + _processes.Count == 0)
            {
              OnQueueEvent(ProcessingQueueEventType.QUEUE_EMPTY);
              if (_statReset)
              {
                _log.Info(string.Format("{0} statistics for current file: processed - {1}, failed - {2}", this.GetType().Name, _processed.ToString(), _failed.ToString()));
                _processed = 0;
                _failed = 0;
                _statReset = false;
              }
            }
            _pause = true;
            _log.Debug("_wait");
            _wait.WaitOne();
          }

          while (_queue.Count > 0 && _processes.Count <= _maxProcesses)
          {
            TmcItem currentItem = null;
            try
            {
              lock (_qlock)
              {
                currentItem = _queue.Dequeue();
              }
              if (currentItem != null)
              {
                Task<TmcItem.TmcItemResult> currentTask = currentItem.InsertWithResultAsync();
                _processes.Add(currentTask);
              }
            }
            catch (Exception ex)
            {
              _log.Error(string.Format("_process - error adding process: {0}\r\n{1}", ex.Message, ex.StackTrace));
              if (currentItem != null)
              {
                currentItem.RetryAttempts++;
                if (currentItem.RetryAttempts < _maxRetryAttempts)
                {
                  _queue.Enqueue(currentItem);
                }
                else
                {
                  string msg = string.Format("_process: Giving up on TmcItem {0}, insertion failed", 
                    string.Format("{0}: {1}", currentItem.rw_li, currentItem.tmc_de));
                  _log.Error(string.Format("{0}\r\n\r\n{1}", msg, currentItem.OuterXml));
                  _failed++;
                  FileProcessError fpe = new FileProcessError()
                  {
                    ErrorType = "ErrorQueue",
                    FileProcessLogItemId = currentItem.PackageId,
                    Message = msg,
                    OccurredDate = DateTime.Now,
                    Remarks = currentItem.OuterXml
                  };
                  fpe.Insert();
                }
              }
            }
          }

          if (_processes.Count > 0)
          {
            //Finish at least one process, but whatever it takes to go below max.
            do
            {
              Task<TmcItem.TmcItemResult> nextResult = await Task.WhenAny(_processes);
              _processes.Remove(nextResult);
              if (nextResult.Result.Result)
              {
                _processed++;
              }
              else
              {
                TmcItem failedItem = nextResult.Result.TmcItem;
                if (failedItem != null)
                {
                  failedItem.RetryAttempts++;
                  if (failedItem.RetryAttempts < _maxRetryAttempts)
                  {
                    _queue.Enqueue(failedItem);
                  }
                  else
                  {
                    string msg = string.Format("_process: Giving up on TmcItem {0}, insertion failed",
                      string.Format("{0}: {1}", failedItem.rw_li, failedItem.tmc_de));
                    _log.Error(string.Format("{0}\r\n\r\n{1}", msg, failedItem.OuterXml));
                    _failed++;
                    FileProcessError fpe = new FileProcessError()
                    {
                      ErrorType = "ErrorQueue",
                      FileProcessLogItemId = failedItem.PackageId,
                      Message = msg,
                      OccurredDate = DateTime.Now,
                      Remarks = failedItem.OuterXml
                    };
                    fpe.Insert();
                  }
                }
              }
            } while (_processes.Count >= _maxProcesses);
          }
        }
        catch (Exception ex)
        {
          _log.Error(string.Format("_process: {0}\r\n{1}", ex.Message, ex.StackTrace));
          _run = false;

          OnQueueEvent(ProcessingQueueEventType.QUEUE_STOPPED);
        }
      }

      _log.Info("_process: Error queue process stopping.");
    }
  }
}
