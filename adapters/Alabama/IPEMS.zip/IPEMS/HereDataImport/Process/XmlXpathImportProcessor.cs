﻿using System;
using System.IO;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

using HereDataImport.Model;
using HereDataImport.Model.Processing;
using HereDataImport.Process.Events;

namespace HereDataImport.Process
{
  public enum XmlFileImportProcessorStatus
  {
    READY,
    RUNNING,
    PAUSED,
    FINISHED,
    ERROR
  }

  public class XmlXpathImportProcessor : ProcessingQueue<FileProcessLogItem, object>
  {
    private bool _processing;
    private string _localWorkDir;
    private DateTime _start, _stop;

    private InputQueue _inputQueue;

    #region Events

    public event FileProcessEventHandler XmlFileImportStarted;
    public event FileProcessEventHandler XmlFileImportCompleted;
    public event FileProcessEventHandler XmlFileImportFailed;
    public event FileProcessEventHandler XmlRecordImportFailed;

    #endregion

    public bool Processing { get { return _processing; } }

    public XmlXpathImportProcessor(InputQueue inputQueue)
    {
      _processing = false;

      _maxQueueLen = int.MaxValue; //Not expected to be more than five or ten, at most.

      _localWorkDir = _config.PathConfiguration.LocalWorkDirectory;

      _inputQueue = inputQueue;
      _inputQueue.QueueEvent += InputQueueEventHandler;
    }

    protected override void _process()
    {
      _log.Info("_process: File import process starting.");
      _run = true;
      FileProcessEventArgs args;
      string targetFileName = null;

      while (_run)
      {
        //Begin process for each batch of extracted files.
        try
        {
          //Self pause, waiting for items to process
          if (_queue.Count == 0)
          {
            _state = ProcessingQueueState.PAUSED;
            _processing = false;
            _pause = true;
            _log.Debug("_wait for work");
            _wait.WaitOne();
          }

          while (_queue.Count > 0)
          {
            //Begin process for each extracted file.
            _processing = true;
            FileProcessLogItem item = _queue.Dequeue();

            if (item != null)
            {
              _processed = _failed = 0;

              targetFileName = Path.Combine(_localWorkDir, item.FileName);
              if (File.Exists(targetFileName))
              {
                try
                {
                  _start = DateTime.Now;
                  _log.Info(string.Format("_process: starting to process file {0}", targetFileName));

                  args = new FileProcessEventArgs(targetFileName, FileProcessEventType.IMPORT, null, item.ID);
                  OnFileImportStarted(args);

                  _log.Info(string.Format("_process: opening file {0}", targetFileName));

                  XmlDocument doc = new XmlDocument();
                  doc.Load(targetFileName);

                  XmlNamespaceManager mgr = new XmlNamespaceManager(doc.NameTable);
                  mgr.AddNamespace("x", doc.DocumentElement.NamespaceURI);

                  XmlNodeList rwsList = doc.DocumentElement.SelectNodes("//x:RWS[@TY=\"TMC\"]", mgr);

                  DateTime dt;
                  decimal d;

                  _log.Info(string.Format("_process: reading file {0}", targetFileName));

                  //Each TMCItem rw_pbt will now be set to the session timestamp, which will be the same for both files.
                  //The created_timestamp, from the document timestamp attribute, will be passed back to the controller 
                  //  for logging to the file metadata record in the database.
                  //The rw_pbt attribute of the record will be ignored.
                  string created_timestamp_s;
                  DateTime? created_timestamp;
                  DateTime session_timestamp = item.SessionTimestamp;

                  created_timestamp_s = doc.DocumentElement.HasAttribute("CREATED_TIMESTAMP") ? doc.DocumentElement.Attributes["CREATED_TIMESTAMP"].Value : null;
                  created_timestamp = DateTime.TryParse(created_timestamp_s, out dt) ? dt : (DateTime?)null;

                  foreach (XmlNode rws in rwsList)
                  {
                    TmcItem currentItem = null;
                    XmlNodeList rwList = rws.SelectNodes("x:RW", mgr);
                    foreach (XmlNode rw in rwList)
                    {
                      string rw_li, rw_de, rw_pbts;
                      DateTime? rw_pbt;

                      XmlElement rwe = (XmlElement)rw;
                      rw_li = rwe.HasAttribute("LI") ? rwe.Attributes["LI"].Value : null;
                      rw_de = rwe.HasAttribute("DE") ? rwe.Attributes["DE"].Value : null;
                      rw_pbts = rwe.HasAttribute("PBT") ? rwe.Attributes["PBT"].Value : null;
                      rw_pbt = DateTime.TryParse(rw_pbts, out dt) ? dt : (DateTime?)null;

                      XmlNodeList fiList = rw.SelectNodes("descendant::x:FI", mgr);
                      foreach (XmlNode fi in fiList)
                      {
                        //External pause because input queue is full
                        if (_pause)
                        {
                          _log.Debug("_wait for clearance");
                          _wait.WaitOne();
                        }

                        try
                        {
                          string tmc_pc, tmc_de, cf_ty, cf_sps, cf_sus, cf_ffs, cf_jfs, cf_cns, cf_ts;
                          decimal? cf_sp, cf_su, cf_ff, cf_jf, cf_cn;

                          XmlElement tmc = fi.SelectSingleNode("x:TMC", mgr) as XmlElement;
                          if (tmc != null)
                          {
                            tmc_pc = tmc.HasAttribute("PC") ? tmc.Attributes["PC"].Value : null;
                            tmc_de = tmc.HasAttribute("DE") ? tmc.Attributes["DE"].Value : null;
                          }
                          else
                          {
                            tmc_pc = tmc_de = null;
                          }

                          XmlElement cf = fi.SelectSingleNode("x:CF", mgr) as XmlElement;
                          if (cf != null)
                          {
                            cf_ty = cf.HasAttribute("TY") ? cf.Attributes["TY"].Value : null;
                            cf_sps = cf.HasAttribute("SP") ? cf.Attributes["SP"].Value : null;
                            cf_sp = decimal.TryParse(cf_sps, out d) ? d : (decimal?)null;
                            cf_sus = cf.HasAttribute("SU") ? cf.Attributes["SU"].Value : null;
                            cf_su = decimal.TryParse(cf_sus, out d) ? d : (decimal?)null;
                            cf_ffs = cf.HasAttribute("FF") ? cf.Attributes["FF"].Value : null;
                            cf_ff = decimal.TryParse(cf_ffs, out d) ? d : (decimal?)null;
                            cf_jfs = cf.HasAttribute("JF") ? cf.Attributes["JF"].Value : null;
                            cf_jf = decimal.TryParse(cf_jfs, out d) ? d : (decimal?)null;
                            cf_cns = cf.HasAttribute("CN") ? cf.Attributes["CN"].Value : null;
                            cf_cn = decimal.TryParse(cf_cns, out d) ? d : (decimal?)null;
                            cf_ts = cf.HasAttribute("TS") ? cf.Attributes["TS"].Value : null;

                            XmlNodeList ssList = cf.SelectNodes("descendant::x:SS", mgr);
                            if (ssList.Count > 0)
                            {
                              int ss_order = 0;

                              foreach (XmlNode ss in ssList)
                              {
                                string ss_les, ss_sps, ss_sus, ss_ffs, ss_jfs, ss_ts;
                                decimal? ss_le, ss_sp, ss_su, ss_ff, ss_jf;

                                XmlElement sse = (XmlElement)ss;
                                ss_les = sse.HasAttribute("LE") ? sse.Attributes["LE"].Value : null;
                                ss_le = decimal.TryParse(ss_les, out d) ? d : (decimal?)null;
                                ss_sps = sse.HasAttribute("SP") ? sse.Attributes["SP"].Value : null;
                                ss_sp = decimal.TryParse(ss_sps, out d) ? d : (decimal?)null;
                                ss_sus = sse.HasAttribute("SU") ? sse.Attributes["SU"].Value : null;
                                ss_su = decimal.TryParse(ss_sus, out d) ? d : (decimal?)null;
                                ss_ffs = sse.HasAttribute("FF") ? sse.Attributes["FF"].Value : null;
                                ss_ff = decimal.TryParse(ss_ffs, out d) ? d : (decimal?)null;
                                ss_jfs = sse.HasAttribute("JF") ? sse.Attributes["JF"].Value : null;
                                ss_jf = decimal.TryParse(ss_jfs, out d) ? d : (decimal?)null;
                                ss_ts = sse.HasAttribute("TS") ? sse.Attributes["TS"].Value : null;

                                currentItem = new TmcItem()
                                {
                                  rw_li = rw_li,
                                  rw_de = rw_de,
                                  //rw_pbt = rw_pbt,
                                  //rw_pbt = created_timestamp,
                                  rw_pbt = session_timestamp,
                                  tmc_pc = tmc_pc,
                                  tmc_de = tmc_de,
                                  cf_ty = cf_ty,
                                  cf_sp = cf_sp,
                                  cf_su = cf_su,
                                  cf_ff = cf_ff,
                                  cf_jf = cf_jf,
                                  cf_cn = cf_cn,
                                  cf_ts = cf_ts,
                                  ss_le = ss_le,
                                  ss_sp = ss_sp,
                                  ss_su = ss_su,
                                  ss_ff = ss_ff,
                                  ss_jf = ss_jf,
                                  ss_ts = ss_ts,
                                  ss_order = ++ss_order
                                };

                                currentItem.PackageId = item.ID;
                                currentItem.CreationDate = DateTime.Now;
                                currentItem.OuterXml = fi.OuterXml;
                                if (currentItem != null)
                                {
                                  _inputQueue.Enqueue(currentItem);
                                  _processed++;
                                }
                                else
                                {
                                  _log.Error(string.Format("_process: Could not instantiate Incident from XML:\r\n\r\n{0}", fi.OuterXml));
                                  _failed++;
                                }
                              }
                            }
                            else
                            {
                              currentItem = new TmcItem()
                              {
                                rw_li = rw_li,
                                rw_de = rw_de,
                                //rw_pbt = rw_pbt,
                                //rw_pbt = created_timestamp,
                                rw_pbt = session_timestamp,
                                tmc_pc = tmc_pc,
                                tmc_de = tmc_de,
                                cf_ty = cf_ty,
                                cf_sp = cf_sp,
                                cf_su = cf_su,
                                cf_ff = cf_ff,
                                cf_jf = cf_jf,
                                cf_cn = cf_cn,
                                cf_ts = cf_ts,
                                ss_le = null,
                                ss_sp = null,
                                ss_su = null,
                                ss_ff = null,
                                ss_jf = null,
                                ss_ts = null,
                                ss_order = null
                              };
                              currentItem.PackageId = item.ID;
                              currentItem.CreationDate = DateTime.Now;
                              currentItem.OuterXml = fi.OuterXml;
                              if (currentItem != null)
                              {
                                _inputQueue.Enqueue(currentItem);
                                _processed++;
                              }
                              else
                              {
                                _log.Error(string.Format("_process: Could not instantiate TMCItem from XML:\r\n\r\n{0}", fi.OuterXml));
                                _failed++;
                              }
                            }
                          }
                        }
                        catch (Exception ex)
                        {
                          _failed++;
                          _log.Error(string.Format("_process: Error, {3}, parsing TMCItem - {0}\r\n{1}\r\n\r\n{2}",
                            ex.Message, ex.StackTrace, fi.OuterXml, ex.GetType().Name));

                          FileProcessEventArgs exargs = new FileProcessEventArgs(targetFileName, FileProcessEventType.ITEM_ERROR, ex);
                          OnRecordImportFailed(exargs);
                        }
                      }
                    }
                  }

                  _stop = DateTime.Now;
                  _log.Info(string.Format("_process: finished processing file {0}, processed {1} TMCItems in {2} minutes",
                    targetFileName, _processed, ((TimeSpan)(_stop - _start)).TotalMinutes));
                  args = new FileProcessEventArgs(targetFileName, FileProcessEventType.IMPORT, null, item.ID) { FileTimestamp = created_timestamp };
                  OnFileImportCompleted(args);

                  File.Delete(targetFileName);
                }
                catch (Exception ex)
                {
                  _log.Error(string.Format("_process: General error, {3}, processing file {0}, ID {4}: {1}\r\n{2}",
                    targetFileName, ex.Message, ex.StackTrace, ex.GetType().Name, item.ID));

                  args = new FileProcessEventArgs(targetFileName, FileProcessEventType.PROCESS_ERROR, ex, item.ID);
                  OnFileImportFailed(args);
                }
              }
              else
              {
                _log.Error(string.Format("_process: target file {0}, ID {1}, not found", targetFileName, item.ID));
              }
            }
          }
        }
        catch (Exception ex)
        {
          _log.Error(string.Format("_process: Error processing file {0}:\r\n{1}\r\n{2}", targetFileName, ex.Message, ex.StackTrace));
          args = new FileProcessEventArgs(targetFileName, FileProcessEventType.EXTRACTION, ex);
          OnFileImportFailed(args);
        }
      }

      _log.Info("_process: File import process stopping.");
    }

    #region Handle and fire events

    private void InputQueueEventHandler(object sender, ProcessingQueueEventArgs args)
    {
      if (args.EventType == ProcessingQueueEventType.QUEUE_READY)
      {
        //_run = true;
        //_pause = false;
        //_wait.Set();
        Continue();
      }
      else if (args.EventType == ProcessingQueueEventType.QUEUE_FULL)
      {
        //_run = true;
        //_pause = true;
        Pause();
      }
      else if (args.EventType == ProcessingQueueEventType.QUEUE_AVAILABLE)
      {
        //_run = true;
        //_pause = false;
        //_wait.Set();
        Continue();
      }
      else if (args.EventType == ProcessingQueueEventType.QUEUE_STOPPED)
      {
        _run = false;
      }
    }

    protected virtual void OnFileImportStarted(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = XmlFileImportStarted;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileImportCompleted(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = XmlFileImportCompleted;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnFileImportFailed(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = XmlFileImportFailed;

      if (handler != null)
        handler(this, args);
    }

    protected virtual void OnRecordImportFailed(FileProcessEventArgs args)
    {
      FileProcessEventHandler handler = XmlRecordImportFailed;

      if (handler != null)
        handler(this, args);
    }

    #endregion
  }
}
