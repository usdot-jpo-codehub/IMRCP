﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;

using System.IO;
using System.Timers;

using INRIX_XML;

namespace INRIX_XML_Ingester_Service
{
    public partial class INRIX_XML_Ingestion_Service : ServiceBase
    {
        Timer timer = new Timer();

        public INRIX_XML_Ingestion_Service()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            //handle Elapsed event
            timer.Elapsed += new ElapsedEventHandler(startService);

            //This statement is used to set interval to 1 minute (= 60,000 milliseconds)
            timer.Interval = 60000;

            //enabling the timer
            timer.Enabled = true;
        }

        protected override void OnStop()
        {
            timer.Enabled = false;
        }

        private void startService(object source, ElapsedEventArgs e)
        {
            INRIXWorker.Ingest();
        }
    }
}
