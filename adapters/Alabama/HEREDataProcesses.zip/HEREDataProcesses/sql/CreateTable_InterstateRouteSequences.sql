SELECT SequenceId, ROAD_NUM RouteDesignation, ROAD_DIR Direction, MeasureAscending,
	COUNT(*) SegmentCount, SUM(GeometryLength) TotalLength, 
	CASE WHEN MeasureAscending = 1 THEN MIN(MeasureFrom) ELSE MAX(MeasureFrom) END MeasureStart,
	CASE WHEN MeasureAscending = 1 THEN MAX(MeasureTo) ELSE MIN(MeasureTo) END MeasureEnd
	INTO InterstateRouteSequences
	FROM InterstateRouteGeometry
	WHERE ParentId IS NULL
	GROUP BY SequenceId, ROAD_NUM, ROAD_DIR, MeasureAscending
