IF EXISTS (SELECT * FROM sys.objects WHERE name = 'CcsCountComparison_24HR' AND type = 'P')
	DROP PROCEDURE CcsCountComparison_24HR

GO

CREATE PROCEDURE CcsCountComparison_24Hr
(
	@startDate_1 DATETIME,
	@endDate_1 DATETIME,
	@startDate_2 DATETIME,
	@endDate_2 DATETIME
)
AS
BEGIN
DECLARE @days_1 INT = DATEDIFF(DAY, @startDate_1, @endDate_1) + 1,
	@days_2 INT = DATEDIFF(DAY, @startDate_2, @endDate_2) + 1

SELECT CCS_Number, RouteType, RouteNumber, BeginMP, EndMp, MaxMP, SegmentDistance, 
	CAST(Interval1_Counts AS INT) Interval1_Counts, 
	CAST(Interval2_Counts AS INT) Interval2_Counts,
	CAST(FLOOR(Interval1_Counts * SegmentDistance) AS INT) Interval1_VMT,
	CAST(FLOOR(Interval2_Counts * SegmentDistance) AS INT) Interval2_VMT,
	CAST(((Interval2_counts - Interval1_Counts) / Interval1_Counts * 100) AS DECIMAL(8,2)) PctChg_Counts
FROM
(
SELECT 
	@startDate_1 Interval1_Start,
	@startDate_2 Interval2_Start,
	stn.CCS_Number,
	stn.RouteType RouteType,
	stn.RouteNumber RouteNumber,
	stn.Begin_Milepoint BeginMP,
	stn.End_Milepoint EndMP,
	stn.MaxRouteM MaxMP,
	CAST((stn.End_Milepoint - stn.Begin_Milepoint) AS DECIMAL(10,6)) SegmentDistance,
	CAST((ct1.VolumeCount / @days_1) AS DECIMAL) Interval1_Counts,
	CAST(((ct2.VolumeCount) / @days_2) AS DECIMAL) Interval2_Counts
FROM
	(SELECT CCS_Number, RouteType, RouteNumber, Begin_Milepoint, End_Milepoint, MaxRouteM FROM CcsStations) stn
	LEFT OUTER JOIN
	(SELECT CcsNumber, SUM(VolumeCount)  VolumeCount
	FROM CcsHourlyVolumeCounts
	WHERE RecordDate >= @startDate_1 AND RecordDate <= @endDate_1
	GROUP BY CcsNumber) ct1 ON stn.CCS_Number = ct1.CcsNumber
	LEFT OUTER JOIN
	(SELECT CcsNumber, SUM(VolumeCount) VolumeCount
	FROM CcsHourlyVolumeCounts
	WHERE RecordDate >= @startDate_2 AND RecordDate <= @endDate_2
	GROUP BY CcsNumber) ct2 ON stn.CCS_Number = ct2.CcsNumber
) q
ORDER BY RouteType, RouteNumber, BeginMP
END

GO

GRANT EXECUTE ON CcsCountComparison_24HR TO hereDataSvc