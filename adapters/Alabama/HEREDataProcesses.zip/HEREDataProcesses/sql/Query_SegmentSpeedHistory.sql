DECLARE @start DATETIME,
	@end DATETIME,
	@sId INT,
	@sOrd INT

SET @start = DATEADD(MINUTE, -20, '4/10/2019 7:30')
SET @end = DATEADD(MINUTE, 15, @start)
SET @siD = 17
SET @sOrd = 63

SELECT h.GeometryId, g.Id, h.RW_PBT, h.SS_ORDER, g.MeasureFrom, g.MeasureTo, h.CurrentSegmentSpeed, h.DeltaSpeed
	FROM RouteSpeedHistory h
	JOIN InterstateRouteGeometry g ON h.GeometryId = g.Id
	LEFT OUTER JOIN InterstateRouteGeometry g2 ON g.ParentId = g2.Id
	WHERE h.RW_PBT >+ @start AND h.RW_PBT <= @end AND @sId = ISNULL(g.SequenceId, g2.SequenceId) AND @sOrd = ISNULL(g.SequenceOrder, g2.SequenceOrder)
	ORDER BY h.RW_PBT, h.SS_ORDER
