IF EXISTS (SELECT * FROM sys.objects WHERE name = 'RouteSpeedHistory' AND type = 'U')
	DROP TABLE RouteSpeedHistory

IF EXISTS (SELECT * FROM sys.objects WHERE name = 'RouteSpeedSession' AND type = 'U')
	DROP TABLE RouteSpeedSession

CREATE TABLE RouteSpeedSession
(
	Id BIGINT IDENTITY, 
	StartTimestamp DATETIME,
	EndTimestamp DATETIME,
	CompletedTimestamp DATETIME,
	GeometriesAttempted INT,
	GeometriesCreated INT,
	GeometriesFailed INT,
	CONSTRAINT RouteSpeedSession_Id_PK PRIMARY KEY (Id)
)

ALTER TABLE RouteSpeedSession
	ADD SessionTimestamp DATETIME

CREATE TABLE RouteSpeedHistory
(
	Id BIGINT IDENTITY,
	SessionId BIGINT NOT NULL,
	GeometryId INT,
	RW_PBT DATETIME,
	POINT_DESC VARCHAR(50),
	PRIMARY_LINEAR VARCHAR(20),
	CF_CN DECIMAL(6,2),
	SS_LE DECIMAL(10,6),
	SS_OFFSET DECIMAL(10,6),
	SS_ORDER INT,
	CurrentSegmentSpeed DECIMAL(6, 2),
	PreviousSegmentSpeed DECIMAL(6, 2),
	DeltaSpeed DECIMAL(6, 2),
	CONSTRAINT RouteSpeedHistory_Id_PK PRIMARY KEY (Id),
	CONSTRAINT RouteSpeedHistory_SessionId_FK FOREIGN KEY (SessionId)
		REFERENCES RouteSpeedSession (Id),
	CONSTRAINT RouteSpeedHistory_GeometryId_FK FOREIGN KEY (GeometryId)
		REFERENCES InterstateRouteGeometry (Id)
)

ALTER TABLE RouteSpeedHistory
	ADD CurrentSegmentFF DECIMAL(6,2)