ALTER PROCEDURE GetSdmhtableData_Archive
(
	@startTime DATETIME,
	@endTime DATETIME,
	@startMile FLOAT,
	@endMile FLOAT,
	@sequenceID INT
)
AS
BEGIN
	SELECT 
		ROW_NUMBER() OVER (PARTITION BY st.session_time ORDER BY g.SequenceOrder, s.offset) RowOrder,
		DENSE_RANK() OVER (ORDER BY st.session_time) ColumnOrder,
		st.session_time, 
		a.POINT_DESC,
		CASE WHEN g.MeasureAscending = 1 AND g.MeasureFrom < @startMile THEN @startMile 
			WHEN g.MeasureAscending = 0 AND g.MeasureFrom > @endMile THEN @endMile
			ELSE g.MeasureFrom END MeasureFrom,
		CASE WHEN g.MeasureAscending = 1 AND g.MeasureTo > @endMile THEN @endMile
			WHEN g.MeasureAscending = 0 AND g.MeasureTo < @startMile THEN @startMile
			ELSE g.MeasureTo END MeasureTo,
		s.confidence, 
		CAST (s.sub_len AS FLOAT) sub_len, 
		CASE WHEN isSub = 0 THEN NULL ELSE CAST(s.offset AS FLOAT) END sub_off,
		CASE WHEN isSub = 0 THEN NULL ELSE ROW_NUMBER() OVER (PARTITION BY st.session_time, s.tmc ORDER BY s.offset) END sub_ord, 
		CAST(s.speed AS DECIMAL), 
		CAST(s.ff_speed AS DECIMAL)
	FROM speed_tstamps st
		JOIN speeds s ON st.tstamp = s.tstamp 
		JOIN InterstateRouteGeometry g ON s.TMC = g._TMC
		JOIN TMC_ATTR_2 a ON g.TMC = a.TMC
	WHERE 
		st.session_time >= @startTime
		AND st.session_time <= @endTime
		AND g.SequenceId = @sequenceID
		AND CASE WHEN g.MeasureAscending = 1 THEN g.MeasureTo ELSE g.MeasureFrom END >= @startMile
		AND CASE WHEN g.MeasureAscending = 1 THEN g.MeasureFrom ELSE g.MeasureTo END <= @endMile
		AND ((isSub = 1)
			OR (isSub = 0 AND NOT EXISTS(SELECT * FROM speeds WTIH (NOLOCK) WHERE tstamp = s.tstamp AND tmc = s.tmc AND isSub = 1)))
	ORDER BY ColumnOrder, RowOrder
END