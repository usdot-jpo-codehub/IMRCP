IF EXISTS (SELECT * FROM sys.objects WHERE name = 'UpdateCurrentDeltas' AND type = 'P')
	DROP PROCEDURE UpdateCurrentDeltas
GO
	
CREATE PROCEDURE UpdateCurrentDeltas AS
BEGIN

DECLARE @sessionId BIGINT

--Completed timestamp null indicates the pending session.
SELECT TOP 1 @sessionId = Id FROM RouteSpeedSession WHERE CompletedTimestamp IS NULL ORDER BY Id DESC

;WITH deltas AS
(
--Columns aliased destXXX are the update targets, srcXXX the update data sources
SELECT s1.Id, s1.SequenceId, s1.CurrentSegmentSpeed, s1.PreviousSegmentSpeed destPrevSegSpd, s2.CurrentSegmentSpeed srcPrevSegSpd, 
	s1.DeltaSpeed destDeltaSpd,  s1.CurrentSegmentSpeed - s2.CurrentSegmentSpeed srcDeltaSpd FROM
(
--Subqueries s1 and s2 (the join below): s1 is update target record, s2 is the previous (physically in the sequence) record, the data source.
SELECT h.Id, g.SequenceId,
	--Speed or confidence level of -1 indicates the information is not available, confidence level less than .7 indicates not reliable
	--and will not be used. Affected delta speeds will be set null.
	IIF(h.CurrentSegmentSpeed = -1 OR h.CF_CN < .7, NULL, h.CurrentSegmentSpeed) CurrentSegmentSpeed, h.PreviousSegmentSpeed, h.DeltaSpeed,
	--Every record is ranked by its position within the physical sequence.
	ROW_NUMBER() OVER (PARTITION BY g.SequenceId ORDER BY g.SequenceOrder, h.SS_ORDER) dr
	--Geometry table contains the segment sequencing information.
	FROM InterstateRouteGeometry g 
		LEFT OUTER JOIN RouteSpeedHistory h ON h.POINT_DESC = g.POINT_DESC AND h.PRIMARY_LINEAR = g.PRIMARY_LINEAR 
			--ParentId IS NULL = Not a subsegment
			--We only want to use the primary (Parent) sequences to establish segment order.
			AND g.ParentId IS NULL
	WHERE h.SessionId = @sessionId
) s1
LEFT OUTER JOIN
(
--Only the sequence ID, ordinal, and segment speed are needed from this subquery.
SELECT g.SequenceId,
	--see s1 above for explanation of this and corresponding query elements following.
	IIF(h.CurrentSegmentSpeed = -1 OR h.CF_CN < .7, NULL, h.CurrentSegmentSpeed) CurrentSegmentSpeed,
	ROW_NUMBER() OVER (PARTITION BY g.SequenceId ORDER BY g.SequenceOrder, h.SS_ORDER) dr
	FROM InterstateRouteGeometry g 
		LEFT OUTER JOIN RouteSpeedHistory h ON h.POINT_DESC = g.POINT_DESC AND h.PRIMARY_LINEAR = g.PRIMARY_LINEAR 
			AND g.ParentId IS NULL
	WHERE h.SessionId = @sessionId
) s2
--Current and previous segments joined here (s1.dr -1 = s2.dr)
ON s1.SequenceId = s2.SequenceId AND s1.dr - 1 = s2.dr
)
UPDATE deltas SET destPrevSegSpd = srcPrevSegSpd, destDeltaSpd = srcDeltaSpd

END
