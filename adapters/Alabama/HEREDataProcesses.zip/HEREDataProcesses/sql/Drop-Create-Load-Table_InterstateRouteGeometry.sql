IF EXISTS (SELECT * FROM sys.objects WHERE name = 'InterstateRouteGeometry' AND type = 'U')
BEGIN
	IF EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'RouteSpeedHistory_GeometryId_FK' AND parent_object_id = OBJECT_ID('RouteSpeedHistory'))
	BEGIN
		ALTER TABLE RouteSpeedHistory
			DROP CONSTRAINT RouteSpeedHistory_GeometryId_FK
	END
	DROP TABLE InterstateRouteGeometry
END

CREATE TABLE InterstateRouteGeometry
(
	Id INT IDENTITY(1,1) NOT NULL,
	ParentId INT,
	SequenceId INT,
	SequenceOrder INT,
	ROAD_NUM VARCHAR(32),
	ROAD_DIR VARCHAR(32),
	PRIMARY_LINEAR VARCHAR(16),
	POINT_DESC VARCHAR(128),
	START_LAT DECIMAL(10, 7),
	START_LON DECIMAL(10, 7),
	END_LAT DECIMAL(10, 7),
	END_LON DECIMAL(10, 7),
	TMC_ORDER INT,
	GeometryLength DECIMAL(10, 6),
	MeasureAscending BIT,
	MeasureFrom FLOAT,
	MeasureTo FLOAT,
	MeasureOffset DECIMAL(10, 6),
	Shape GEOMETRY,
	CONSTRAINT InterstateRouteGeometry_Id_PK PRIMARY KEY CLUSTERED (Id),
	CONSTRAINT InterstateRouteGeometry_ParentId_FK FOREIGN KEY (ParentId)
		REFERENCES InterstateRouteGeometry (Id)
)

CREATE INDEX InterstateRouteGeometry_TmcItems_X ON InterstateRouteGeometry
(
	POINT_DESC,
	PRIMARY_LINEAR,
	ParentId
)

CREATE INDEX InterstateRouteGeometry_Offset_Length_X ON InterstateRouteGeometry
(
	POINT_DESC,
	PRIMARY_LINEAR,
	ParentId,
	MeasureOffset,
	GeometryLength
)

SET IDENTITY_INSERT InterstateRouteGeometry ON
 
INSERT INTO InterstateRouteGeometry
           (Id
		   ,ParentId
           ,SequenceId
           ,SequenceOrder
           ,ROAD_NUM
           ,ROAD_DIR
           ,PRIMARY_LINEAR
           ,POINT_DESC
           ,START_LAT
           ,START_LON
           ,END_LAT
           ,END_LON
           ,TMC_ORDER
           ,GeometryLength
           ,MeasureAscending
           ,MeasureFrom
           ,MeasureTo
           ,MeasureOffset
           ,Shape)
SELECT Id
	  ,ParentId
      ,SequenceId
      ,SequenceOrder
      ,ROAD_NUM
      ,ROAD_DIR
      ,PRIMARY_LINEAR
      ,POINT_DESC
      ,START_LAT
      ,START_LON
      ,END_LAT
      ,END_LON
      ,TMC_ORDER
      ,GeometryLength
      ,MeasureAscending
      ,MeasureFrom
      ,MeasureTo
      ,MeasureOffset
      ,Shape
  FROM InterstateRouteGeometry_bak

SET IDENTITY_INSERT InterstateRouteGeometry OFF

IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE name = 'RouteSpeedHistory_GeometryId_FK' AND parent_object_id = OBJECT_ID('RouteSpeedHistory'))
	ALTER TABLE RouteSpeedHistory
		ADD CONSTRAINT RouteSpeedHistory_GeometryId_FK FOREIGN KEY (GeometryId)
			REFERENCES InterstateRouteGeometry (Id)
