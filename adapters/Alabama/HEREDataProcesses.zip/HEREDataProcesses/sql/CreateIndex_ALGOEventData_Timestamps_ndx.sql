CREATE INDEX ALGOEventData_Timestamps_ndx ON ALGOEventData
(
	RoadType,
	VerifiedTime,
	ResponderDepartTime
)
