--The following index was specifically added to improve the performace on this procedure

--CREATE INDEX RouteSpeedHistory_TmcItems_X ON RouteSpeedHistory
--(
--	POINT_DESC,
--	PRIMARY_LINEAR
--)
--INCLUDE 
--(
--	SessionId, 
--	GeometryId, 
--	RW_PBT, 
--	SS_ORDER, 
--	CurrentSegmentSpeed, 
--	PreviousSegmentSpeed, 
--	DeltaSpeed,
--	CurrentSegmentFF
--) 
--WITH (PAD_INDEX = ON, FILLFACTOR = 80, ONLINE = ON)

IF EXISTS (SELECT * FROM sys.objects WHERE name = 'GetSdmhTableData' AND type = 'P')
	DROP PROCEDURE GetSdmhTableData

GO

CREATE PROCEDURE GetSdmhTableData
(
	@sequenceId INT,
	@startTime DATETIME,
	@endTime DATETIME,
	@startMile FLOAT, --@startMile < @endMile
	@endMile FLOAT
)
AS
BEGIN
	--Returns a 2-dimensional array of speed data over a given time interval (columns) and geographic route sequence (rows)
	SELECT h.RW_PBT SessionTimestamp, h.POINT_DESC SegmentDesc, h.CurrentSegmentSpeed, h.PreviousSegmentSpeed, h.DeltaSpeed, h.CurrentSegmentFF,
		g2.MeasureFrom, g2.MeasureTo,
		--Provides a single geographic ordinal for the items in each row (session)
		ROW_NUMBER() OVER (PARTITION BY h.RW_PBT ORDER BY g.SequenceOrder, h.SS_ORDER) RowOrder,
		--Provides a temporal ordinal for each row
		DENSE_RANK() OVER (ORDER BY s.Id) ColumnOrder
		FROM RouteSpeedHistory h WITH (NOLOCK)
			JOIN
			(
				--Subquery to determine the primary geometries coveing the given mile point interval
				SELECT * FROM InterstateRouteGeometry WITH (NOLOCK)
					WHERE SequenceId = @sequenceId AND ParentId IS NULL 
						AND CASE WHEN MeasureAscending = 1 
							THEN MeasureFrom ELSE MeasureTo END <= @endMile 
						AND CASE WHEN MeasureAscending = 1
							THEN MeasureTo  ELSE MeasureFrom END >= @startMile 
			) g ON h.POINT_DESC = g.POINT_DESC AND h.PRIMARY_LINEAR = g.PRIMARY_LINEAR
			JOIN
			(
				--Subquery to determine the history sessions covering the given time interval
				SELECT * FROM RouteSpeedSession WITH (NOLOCK)
					WHERE StartTimestamp >= @startTime AND StartTimestamp <= @endTime
			) s ON h.SessionId = s.Id
			JOIN
				--Provides the measures to and from for the actual history item, even when it refers to a subsequence 
				InterstateRouteGeometry g2 WITH (NOLOCK) ON h.GeometryId = g2.Id
		ORDER BY h.RW_PBT, g.SequenceOrder, h.SS_ORDER
END
