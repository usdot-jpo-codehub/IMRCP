--TMC_ATTR_3 table structure is a clone of TMC_ATTR_2,
--using the "script table as create to..." SSMS tool
 
INSERT INTO [dbo].[TMC_ATTR_3]
           ([TMC]
           ,[ADMIN1]
           ,[ADMIN2]
           ,[ADMIN3]
           ,[ADMIN4]
           ,[ADMIN5]
           ,[POINT_DESC]
           ,[ROAD_NAME]
           ,[ROAD_NUM]
           ,[LINEAR]
           ,[PARENT_LIN]
           ,[POS_OFF]
           ,[NEG_OFF]
           ,[ROAD_DIR]
           ,[TMC_ORDER]
           ,[TMC_TYPE]
           ,[START_LAT]
           ,[START_LON]
           ,[END_LAT]
           ,[END_LON]
           ,[TMC_LENGTH]
--           ,[REGION]
           ,[PRIMARY_LINEAR])
SELECT [TMC]
      ,[ADMIN1]
      ,[ADMIN2]
      ,[ADMIN3]
      ,[ADMIN4]
      ,[ADMIN5]
      ,[POINT_DESC]
      ,[ROAD_NAME]
      ,[ROAD_NUM]
      ,[LINEAR]
      ,[PARENT_LIN]
      ,[POS_OFF]
      ,[NEG_OFF]
      ,[ROAD_DIR]
      ,[TMC_ORDER]
      ,CAST([TMC_TYPE] AS INT)
      ,CAST([START_LAT] AS DECIMAL(10,7))
      ,CAST([START_LON] AS DECIMAL(10,7))
      ,CAST([END_LAT] AS DECIMAL(10,7))
      ,CAST([END_LON] AS DECIMAL(10,7))
      ,CAST([TMC_LENGTH] AS FLOAT)
	  ,IIF(PARENT_LIN = '', LINEAR, PARENT_LIN)
  FROM [dbo].[TMC_ATTR_20180925]

;
WITH tgt AS
(
	SELECT a.REGION src, b.REGION dest
	FROM TMC_ATTR_2 a
		JOIN TMC_ATTR_3 b ON a.TMC = b.TMC
	WHERE b.TMC IS NULL
)
UPDATE tgt SET dest = src



