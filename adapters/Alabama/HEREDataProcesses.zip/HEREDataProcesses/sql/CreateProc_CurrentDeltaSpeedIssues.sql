IF EXISTS (SELECT * FROM sys.objects WHERE name = 'CurrentDeltaSpeedIssues' AND type = 'P')
    DROP PROCEDURE CurrentDeltaSpeedIssues
GO

CREATE PROCEDURE CurrentDeltaSpeedIssues
(
    @sessionEnd DATETIME = NULL,
    @sessionLength INT = -30,
    @deltaThreshold INT = -15
)
AS
BEGIN

IF @sessionEnd IS NULL
    SET @sessionEnd = GETDATE()
ELSE
	--Trying to advance the issues found because they appear to be lagging corresponding
	--session data in the portal UI.
	SET @sessionEnd = DATEADD(minute, 1, @sessionEnd)
    
SELECT RW_PBT, SequenceId, SequenceOrder, ROAD_NUM, ROAD_DIR, POINT_DESC, START_LAT, START_LON, MeasureFrom, MeasureTo, CurrentSegmentSpeed, DeltaSpeed
    FROM
(
--Get the segment detail from session, speed history, and geometry tables for each segment identified in subquery r, including temporal rank
--for segments appearing in multiple sessions, most recent first. For subsegments, note that the segment sequence information is coming from the parent
--geometry and the start/end lat-longs and measures are coming from the subsegment geometry.
SELECT s.CompletedTimestamp, h.RW_PBT, ISNULL(g.SequenceId, g2.SequenceId) SequenceId, ISNULL(g.SequenceOrder, g2.SequenceOrder) SequenceOrder,
    g.ROAD_NUM, g.ROAD_DIR, h.POINT_DESC, g.START_LAT, g.START_LON, g.MeasureFrom, g.MeasureTo, h.CurrentSegmentSpeed, h.DeltaSpeed,
    --PARTION BY sequenceId, sequenceOrder: Single segments with mutliple delta issues over several sessions from the inner subquery (r) 
    --are grouped together and the most recent is selected.
    ROW_NUMBER() OVER (PARTITION BY ISNULL(g.SequenceId, g2.SequenceId), ISNULL(g.SequenceOrder, g2.SequenceOrder) ORDER BY RW_PBT DESC) row
    FROM RouteSpeedSession s
        JOIN RouteSpeedHistory h ON h.SessionId = s.Id
        JOIN
        (
            --Select the history record ID of each segment, or subsegment of group with the lowest (most negative) delta speed, 
            --having delta speeds less than threshold within given time period before current time. The ROW_NUMBER PARTION BY
            --clause (RW_PBT, POINT_DESC, PRIMARY_LINEAR) groups subsegments of a single segment for a single session together
            --and ranks them in order of delta speed. If multiple subsegments within a single segment and session have deltas
            --in excess of @deltaThreshold, the lowest will be ranked #1. Full segments having delta issues will also be ranked with
            --a #1 of course.  Everything with a #1 rank will be selected by the immediate outer query.
            SELECT ROW_NUMBER() OVER (PARTITION BY h.RW_PBT, h.POINT_DESC, h.PRIMARY_LINEAR ORDER BY h.DeltaSpeed) row, h.Id
                FROM RouteSpeedSession s
                JOIN RouteSpeedHistory h ON h.SessionId = s.Id
                WHERE s.CompletedTimestamp >= DATEADD(MINUTE, @sessionLength, @sessionEnd)
                    AND s.CompletedTimestamp <= @sessionEnd
                    AND h.DeltaSpeed <= @deltaThreshold
        ) r ON h.Id = r.Id
        --If the item is a subsegment, sequence ID and order will be null (in g), so g2 is provided to get those values from
        --the parent segment.
        JOIN InterstateRouteGeometry g ON h.GeometryId = g.Id
        LEFT OUTER JOIN InterstateRouteGeometry g2 ON g.ParentId = g2.Id
    WHERE r.row = 1 
) sq
WHERE sq.row = 1
ORDER BY SequenceId, SequenceOrder
OPTION (MAXDOP 1)

END
