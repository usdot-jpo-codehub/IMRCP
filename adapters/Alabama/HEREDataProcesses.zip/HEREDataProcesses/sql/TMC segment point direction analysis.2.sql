DECLARE @tol FLOAT

SET @tol = .000001

SELECT Id, SequenceId, SequenceOrder, ROAD_NUM, ROAD_DIR, TMC_ORDER, POINT_DESC, PRIMARY_LINEAR, GeometryLength, START_LAT, START_LON
	, Shape.STStartPoint().STY P0_Y, START_LAT - Shape.STStartPoint().STY P0_Y_Diff
	, Shape.STStartPoint().STX P0_X, START_LON - Shape.STStartPoint().STX P0_X_Diff
	, Shape.STEndPoint().STY PN_Y, START_LAT - Shape.STEndPoint().STY PN_Y_Diff
	, Shape.STEndPoint().STX PN_X, START_LON - Shape.STEndPoint().STX PN_X_Diff
	, CASE
		WHEN 
			ABS(START_LAT - Shape.STStartPoint().STY) < @tol AND
			ABS(START_LON - Shape.STStartPoint().STX) < @tol AND
			ABS(START_LAT - Shape.STEndPoint().STY) > @tol AND
			ABS(START_LON - Shape.STEndPoint().STX) > @tol THEN 'Direct'
		WHEN
			ABS(START_LAT - Shape.STStartPoint().STY) > @tol AND
			ABS(START_LON - Shape.STStartPoint().STX) > @tol AND
			ABS(START_LAT - Shape.STEndPoint().STY) < @tol AND
			ABS(START_LON - Shape.STEndPoint().STX) < @tol THEN 'Inverse'
		ELSE 'Undetermined'
	END POINT_MATCH
--INTO InterstateRouteDirections
FROM InterstateRouteGeometry
WHERE ROAD_NUM LIKE 'I%'
ORDER BY SequenceId, SequenceOrder