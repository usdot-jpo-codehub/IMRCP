--Provided to document generation of primary segment geometries
--Original sources for TMC segment data are the tables TMC_GEO_20180925 (the geometries)
--and TMC_ATTR_20180925 (the data attributes). These tables are data imported using
--ArcMap to convert from the native shp and dbf formatted files extracted from the 
--tar archive downloaded from the HERE endpoint. The archive and extracted tables are
--intermediate working materials and only stored locally on wk-mfrommer2. Future
--work will probably only involve using similar process on new and updated versions of
--the HERE data.

--InterstateRouteGeometry combines TMC attributes and geometries into a single table for interstates.
INSERT INTO [dbo].[InterstateRouteGeometry]
           ([ROAD_NUM]
           ,[ROAD_DIR]
           ,[PRIMARY_LINEAR]
           ,[POINT_DESC]
           ,[START_LAT]
           ,[START_LON]
           ,[END_LAT]
           ,[END_LON]
           ,[TMC_ORDER]
           ,[GeometryLength]
           ,[Shape])

SELECT
      a1.[ROAD_NUM]
      ,a1.[ROAD_DIR]
      ,a1.[PRIMARY_LINEAR]
      ,a1.[POINT_DESC]
      ,a1.[START_LAT]
      ,a1.[START_LON]
      ,a1.[END_LAT]
      ,a1.[END_LON]
      ,a1.[TMC_ORDER]
      ,a1.[TMC_LENGTH]
	  ,s.Shape
  --TMC_ATTR_3 is derived from TMC_ATTR_20180925. A previous version,
  --TMC_ATTR_2, was backed up and TMC_ATTR_3 was renamed to TMC_ATTR_2,
  --replacing the previous version.
  FROM [dbo].[TMC_ATTR_3] a1
JOIN 
(
	--TMCInterstateShapes is derived from TMC_GEO_20180925 by selecting only the
	--interstate shapes and then assembling the complete TMC shapes from smaller
	--pieces using ArcMap Create Routes.
	SELECT TMC, CAST(Shape AS VARBINARY(MAX)) Shape FROM TMCInterstateShapes 
	UNION 
	--I22_Shapes is also derived from TMC_GEO_20180925 in the same way, but had
	--to be selected separately because most of I-22 was indicated in the attributes
	--in a way inconsistent with the other interstate TMC data.
	SELECT TMC, CAST(Shape AS VARBINARY(MAX)) Shape FROM I22_Shapes
) s ON a1.TMC = s.TMC

--Added sequence id and order columns, now load columns
WITH recs AS
(
SELECT d.SequenceId destId, d.SequenceOrder destOrder, s.SequenceId srcId, s.SequenceOrder srcOrder
	FROM InterstateRouteGeometry d
	--RoadwayDeltaSequences sequences the interstate TMCs into complete routes.
	JOIN RoadwayDeltaSequences s ON d.POINT_DESC = s.POINT_DESC AND d.PRIMARY_LINEAR = s.PRIMARY_LINEAR
)
UPDATE recs SET destId = srcId, destOrder = srcOrder	