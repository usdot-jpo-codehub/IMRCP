IF EXISTS (SELECT * FROM sys.objects WHERE name = 'UpdateCurrentSpeeds' AND type = 'P')
	DROP PROCEDURE UpdateCurrentSpeeds
GO	
	
CREATE PROCEDURE UpdateCurrentSpeeds AS
BEGIN

DECLARE @start DATETIME,
	@end DATETIME,
	@sessionTimestamp DATETIME,
	@datestring VARCHAR(20),
	@processingMargin INT,
	@sessionId BIGINT

--Ensure we are not fetching from in-progress package
SET @processingMargin = -2
--Build the starting timestamp
SET @sessionTimestamp = GETDATE();
SET @datestring = 
	CAST(YEAR(@sessionTimestamp) AS VARCHAR) + '-' + 
	CAST(MONTH(@sessionTimestamp) AS VARCHAR) + '-' + 
	CAST(DAY(@sessionTimestamp) AS VARCHAR) + ' ' + 
	CAST(DATEPART(HOUR, @sessionTimestamp) AS VARCHAR) + ':' + 
	CAST(DATEPART(MINUTE, @sessionTimestamp) AS VARCHAR)

SET @start = DATEADD(MINUTE, @processingMargin, CAST(@datestring AS DATETIME))
SET @end = DATEADD(MINUTE, 1, @start)

SELECT TOP 1 @sessionTimestamp = SessionTimestamp 
	FROM FileProcessLogItems
	WHERE SessionTimestamp > @start AND SessionTimestamp <= @end
	ORDER BY SessionTimestamp DESC
	
--Create session header and get the PK ID
--Leave the completed timestamp null as a signal to subsequent procedures that this is the pending session
INSERT INTO RouteSpeedSession(StartTimestamp, EndTimestamp, SessionTimestamp) VALUES (@start, @end, @sessionTimestamp)
SELECT @sessionId = IDENT_CURRENT('RouteSpeedSession')

INSERT INTO RouteSpeedHistory (SessionId, RW_PBT, POINT_DESC, PRIMARY_LINEAR, CF_CN, SS_LE, SS_OFFSET, SS_ORDER, CurrentSegmentSpeed, CurrentSegmentFF)
SELECT
	@sessionId
	, RW_PBT
	, TMC_DE
	, LINEAR
	, CF_CN
	--Subsegment length, offset, order, and speed: all null if not a subsegment
	, SS_LE
	--Subquery s computes subsegment offset into the parent segment by summing the lengths of preceding subsegments
	, (SELECT OFFSET FROM 
		(SELECT TMC_DE, LINEAR, RW_PBT, SUM(SS_LE) OFFSET FROM TMCItems WITH (NOLOCK)
		WHERE TMC_DE = o.TMC_DE AND LINEAR = o.LINEAR AND RW_PBT = @sessionTimestamp AND SS_LE IS NOT NULL AND SS_ORDER < o.SS_ORDER
		GROUP BY TMC_DE, LINEAR, RW_PBT) s) OFFSET
	, SS_ORDER
	--If susbegment speed is null, this is a primary segment, so use the overall segment speed
	, ISNULL(o.SS_SU, o.CF_SU) CURRENT_SPEED
	, ISNULL(o.SS_FF, o.CF_FF) CURRENT_FF
FROM TmcItems o WITH (NOLOCK)
	--Just pull the info for interstates using geometry table g as filter.
	--Be sure to limit the join to primary (parent) interstate segments (g.ParentId IS NULL).
	--Subsegments have matching point desc and primary linear attributes also, 
	--and would produce spurious rows if included.
	JOIN InterstateRouteGeometry g WITH (NOLOCK) ON o.TMC_DE = g.POINT_DESC AND o.LINEAR = g.PRIMARY_LINEAR AND g.ParentId IS NULL
	WHERE o.RW_PBT = @sessionTimestamp

--Offset subquery s, above, will return null on the first subsegment since there are no preceding subsegments.
--Just fix it here.
UPDATE RouteSpeedHistory SET SS_OFFSET = 0 WHERE SessionId = @sessionId AND SS_ORDER = 1

--Update the geometry ID of the the speed history record.
; WITH gId AS
(
	SELECT h.Id, h.GeometryId dest, g.Id src
	FROM RouteSpeedHistory h
		JOIN InterstateRouteGeometry g ON h.POINT_DESC = g.POINT_DESC AND h.PRIMARY_LINEAR = g.PRIMARY_LINEAR
			--Whether the history record references a primary segment or a subsegment is indicated by the subsegment attributes of the record.
			--Subsegment length and offset are not null.
			--Join primary segment speed to primary segment geometry and subsegment speed to subsegment geometry.
			AND ((g.ParentId IS NULL AND h.SS_LE IS NULL AND h.SS_OFFSET IS NULL) OR (g.ParentId IS NOT NULL AND h.SS_LE = g.GeometryLength AND h.SS_OFFSET = g.MeasureOffset))
	WHERE h.SessionId = @sessionId
)
UPDATE gId SET dest = src

END
