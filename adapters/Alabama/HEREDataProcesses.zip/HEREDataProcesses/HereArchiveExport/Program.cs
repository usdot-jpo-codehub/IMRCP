﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;

using NLog;
using ICSharpCode.SharpZipLib.GZip;

using HereSharedTypes.Models;

namespace HereArchiveExport
{
  class Program
  {
    private static Logger _log;
    private static DateTime _sessionStart, _sessionEnd;
    private static string _workPath, _outputPath, _archivePath;
    private static string _archiveConnSelector;
    private static int _sessionInterval;

    static void Main(string[] args)
    {
      _log = LogManager.GetLogger("Main");

      DateTime processStart = DateTime.Now;
      DateTime timestampMax = DateTime.MinValue, timesstampMin = DateTime.MaxValue;
      int rowsProcessed, sessionsProcessed = 0;

      #region Parse start and end date args and load config settings
      if (args.Length == 2)
      {
        if (!DateTime.TryParse(args[0], out _sessionStart))
          throw new Exception($"Start date argument, {args[0]}, is invalide");
        if (!DateTime.TryParse(args[1], out _sessionEnd))
          throw new Exception($"End date argument, {args[1]}, is invalid");

        string s = ConfigurationManager.AppSettings["session-interval-minutes"];
        if (s == null)
          _sessionInterval = 0; //default
        else if (!int.TryParse(s, out _sessionInterval))
          throw new Exception($"Configuration setting, session-interval-minutes: {s}, is not valid");

        _archiveConnSelector = ConfigurationManager.AppSettings["archive-conn-selector"];
        if (string.IsNullOrEmpty(_archiveConnSelector))
          throw new Exception("Required configuration setting, archive-conn-selector, was not found");

        if (ConfigurationManager.ConnectionStrings[_archiveConnSelector] == null)
          throw new Exception($"Required connection string, {_archiveConnSelector}, was not found");

        _workPath = ConfigurationManager.AppSettings["work-directory"];
        if (_workPath == null)
          throw new Exception("Required configuration setting, work-directory, was not found");
        _outputPath = ConfigurationManager.AppSettings["output-directory"];
        if (_outputPath == null)
          throw new Exception("Required configuration setting, output-directory, was not found");
        _archivePath = ConfigurationManager.AppSettings["archive-directory"];
        if (_archivePath == null)
          throw new Exception("Required configuration setting, archive-directory, was not found");
      }
      else
      {
        Console.WriteLine("Usage: HereArchiveExport.exe \"<start-date>\" \"<end-date>\"");
        throw new Exception($"Incorrect number of parameters, {args.Length}, were provided");
      }
      #endregion

      _log.Info(new string('=', 40));
      _log.Info($"Starting HERE Archive Export for interval: {_sessionStart} to {_sessionEnd}");

      try
      {
        DateTime intervalStart = _sessionStart;

        while (intervalStart < _sessionEnd)
        {
          List<FileProcessLogItem> packages =
            FileProcessLogItem.GetPackageIdsFromTimestamp(intervalStart);
          if (packages == null || packages.Count == 0)
            throw new Exception($"No packages found later than {intervalStart}");

          intervalStart = packages[0].SessionTimestamp;
          timesstampMin = DateTime.MaxValue;
          timestampMax = DateTime.MinValue;

          _log.Info($"Starting process for session of {intervalStart}");
          Console.WriteLine($"Starting process for session of {intervalStart}");

          string filePath = Path.Combine(_workPath, "export.temp.txt");

          using (FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write))
          {
            StreamWriter sw = new StreamWriter(fs);

            sw.WriteLine("\"version 1.0\"");
            sw.WriteLine("\"id\"|\"description\"|\"start_time (UTC)\"|\"end_time (UTC)\"|" +
              "\"speed (kph)\"|\"volume (veh)\"|\"occupancy (%)\"|\"location ([lon,lat],...)\"");

            bool isSubseg = false;
            decimal subsegOffset = 0;

            foreach (FileProcessLogItem package in packages)
            {
              List<TmcArchiveItem> items =
                TmcArchiveItem.GetExportItems(package.Id, _archiveConnSelector);

              _log.Info($"Starting process for package {package.Id}, " +
                $"record count: {(items != null ? items.Count : 0)}");
              rowsProcessed = 0;
              TmcArchiveItem lastItem = null;

              if (items != null)
              {
                foreach (TmcArchiveItem item in items)
                {
                  if (item.ss_order.HasValue)
                  {
                    if (!isSubseg || lastItem == null || item.tmc != lastItem.tmc)
                    {
                      isSubseg = true;
                      subsegOffset = 0;
                    }

                    if (item.Shape != null)
                    {
                      try
                      {
                        item.Shape = item.Shape.GetSectionByMeasure((double)subsegOffset,
                          (double)(subsegOffset + item.ss_le));
                      }
                      catch (Exception ex)
                      {
                        _log.Error($"Geo error processing tmc: {item.tmc}, offset: {subsegOffset}, " +
                          $"length: {item.ss_le}, end offset: {subsegOffset + item.ss_le}.");
                        //LogException("Main - GetSubsectionByMeasure", ex);
                        item.Shape = null;
                      }
                    }
                    subsegOffset += item.ss_le.Value;
                  }
                  else
                  {
                    isSubseg = false;
                    subsegOffset = 0;
                  }

                  if (item.Shape != null)
                    item.location = item.Shape.Points.Select(p => new double[] { p.X, p.Y }).ToList();

                  sw.WriteLine(item.ToString());

                  if (item.start_time < timesstampMin)
                    timesstampMin = item.start_time;
                  if (item.end_time > timestampMax)
                    timestampMax = item.end_time;

                  lastItem = item;
                  rowsProcessed++;
                }
              }

              _log.Info($"Finishing process for package {package.Id}, processed {rowsProcessed} rows.");
            } //end package process

            sw.Flush();
            sw.Close();
            sw.Dispose();
            fs.Close();
            fs.Dispose();
          }

          string finalName = $"here_speed_" +
            $"{timesstampMin.ToUniversalTime().ToString("yyyyMMddHHmm")}_" +
            $"{timestampMax.ToUniversalTime().ToString("yyyyMMddHHmm")}_" +
            $"{intervalStart.ToUniversalTime().ToString("yyyyMMddHHmm")}.txt";
          string finalPath = Path.Combine(_workPath, finalName);
          File.Move(filePath, finalPath);

          string compressed = CompresssFile(finalPath);
          _log.Info($"Output package: {compressed}");

          string archivePath = Path.Combine(_archivePath,
            intervalStart.Year.ToString("0000"),
            intervalStart.Month.ToString("00"),
            intervalStart.Day.ToString("00"),
            intervalStart.Hour.ToString("00"));
          if (!Directory.Exists(archivePath))
            Directory.CreateDirectory(archivePath);
          archivePath = Path.Combine(archivePath, Path.GetFileName(compressed));

          File.Copy(compressed, archivePath);
          _log.Info($"Archive package: {archivePath}");

          sessionsProcessed++;
          intervalStart = intervalStart.AddMinutes(_sessionInterval);
        }
      }
      catch (Exception ex)
      {
        LogException("Main", ex);
      }

      _log.Info($"Finishing HERE Archive Export, processed {sessionsProcessed} sessions, " +
        $"elapsed: {DateTime.Now - processStart}.");
      _log.Info($"{new string('=', 40)}");
    }

    private static void LogException(string location, Exception ex)
    {
      _log.Error($"{location} - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      if (ex.InnerException != null)
        LogException("Inner Exception", ex.InnerException);
    }

    private static string CompresssFile(string targetFile)
    {
      string result = null;

      try
      {
        string outputFileName = $"{Path.GetFileName(targetFile)}.gz";
        string destPath = Path.Combine(_outputPath, outputFileName);

        if (!File.Exists(targetFile))
          throw new Exception($"Source file, {targetFile}, could not be found");

        using (FileStream input = new FileStream(targetFile, FileMode.Open, FileAccess.Read))
        {
          using (FileStream output = new FileStream(destPath, FileMode.Create, FileAccess.Write))
          {
            GZip.Compress(input, output, true);

            result = destPath;
          }
        }
      }
      catch (Exception ex)
      {
        LogException("CompressFile", ex);
        throw ex;
      }

      return result;
    }
  }
}
