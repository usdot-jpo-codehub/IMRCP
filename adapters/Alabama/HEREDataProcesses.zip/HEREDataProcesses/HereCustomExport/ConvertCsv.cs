﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NLog;

using HereSharedTypes.Models;

namespace HereCustomExport
{
  class ConvertCsv
  {
    private static Logger _log;
    private static DateTime _globalStartTime;
    private static DateTime _globalEndTime;
    private static DateTime _fileRecdTime;
    private static string _sourceFile;
    private static string _tempFile;
    private static string _exportFile;
    private static FileStream _inStream, _outStream;

    static void Main(string[] args)
    {
      _log = LogManager.GetLogger("CustomExport.Main");
      _sourceFile = ConfigurationManager.AppSettings["source-data-file"];
      _tempFile = ConfigurationManager.AppSettings["temp-output-file"];

      try
      {
        using (_outStream = new FileStream(_tempFile, FileMode.Create, FileAccess.Write))
        {
          StreamWriter writer = new StreamWriter(_outStream);

          writer.WriteLine("\"version 1.0\"");
          writer.WriteLine("\"id\"|\"description\"|\"start_time (UTC)\"|\"end_time (UTC)\"|" +
            "\"speed (kph)\"|\"volume (veh)\"|\"occupancy (%)\"|\"location ([lon,lat],...)\"");


          using (FileStream inStream = new FileStream(_sourceFile, FileMode.Open, FileAccess.Read))
          {
            string currentLine = null;
            int lineCtr = 0;
            bool firstLine = true, subseg = false;
            DateTime dt;
            decimal dec;
            bool b;
            TmcExportItem currentItem = null, previousItem = null;
            TmcAttribute currentAttribute = null;
            StreamReader sr = new StreamReader(inStream);

            do
            {
              lineCtr++;

              if (!firstLine) //skipping first line with column names
              {
                currentItem = new TmcExportItem();

                #region Parse the current input line

                currentLine = sr.ReadLine();
                string[] columns = currentLine.Split(',');
                
                //start, end time
                if (!string.IsNullOrEmpty(columns[0]))
                {
                  if (!DateTime.TryParse(columns[0], out dt))
                    dt = DateTime.MinValue.AddMinutes(2);
                }
                else
                {
                  dt = DateTime.MinValue.AddMinutes(2);
                }
                currentItem.end_time = dt;
                currentItem.start_time = dt.AddMinutes(-2);

                //tmc
                if (!string.IsNullOrEmpty(columns[4]))
                  currentItem.id = columns[4];
                else
                  currentItem.id = null;

                //length
                if (!string.IsNullOrEmpty(columns[5]))
                {
                  if (!decimal.TryParse(columns[5], out dec))
                    dec = 0;
                }
                else
                {
                  dec = 0;
                }
                currentItem.length = dec;

                //speed
                if (!string.IsNullOrEmpty(columns[7]))
                {
                  if (!decimal.TryParse(columns[7], out dec))
                    dec = 0;
                }
                else
                {
                  dec = 0;
                }
                currentItem.speed = dec;

                //subsegment
                if (!string.IsNullOrEmpty(columns[9]))
                {
                  if (!bool.TryParse(columns[9], out b))
                    b = false;
                }
                else
                {
                  b = false;
                }
                currentItem.subsegment = b;

                #endregion

                if (currentItem.id != null)
                {
                  if (previousItem == null || !currentItem.subsegment || currentItem.id != previousItem.id)
                  {
                    currentAttribute =
                      TmcAttribute.GetTmcAttribute(currentItem.id.Replace('-', 'N').Replace('+', 'P'));
                  }
                }
                else
                {
                  _log.Error($"No TMC found for line {lineCtr}: {currentLine}");
                }
              }
              else
              {
                firstLine = false;
              }
            } while (currentLine != null);
          }
        }
      }
      catch (Exception ex)
      {
        //try to flush the output stream.
        if (_outStream != null)
          _outStream.Close();

        LogException("Main", ex);
        throw ex;
      }
    }

    private static void LogException(string location, Exception ex)
    {
      _log.Error($"{location} - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      if (ex.InnerException != null)
        LogException("Inner Exception", ex.InnerException);
    }
  }
}
