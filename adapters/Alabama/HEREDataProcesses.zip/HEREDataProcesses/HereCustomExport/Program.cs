﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Xml;

using NLog;
using ICSharpCode.SharpZipLib.GZip;

using CAPS.Utility.GIS.Geometry;

using HereSharedTypes.Models;

namespace HereCustomExport
{
  class Program
  {
    private static Logger _log;
    private static DateTime _start;
    private static string _workDir, _destDir, _archDir;
    private static string _currentFile;

    static void Main(string[] args)
    {
      _log = LogManager.GetLogger("HereExport");

      try
      {
        _start = DateTime.Now;
        _log.Info($"{new string('=', 40)}");
        _log.Info("Starting Here Custom Export");

        #region Load configuration settings
        _workDir = ConfigurationManager.AppSettings["work-directory"];
        if (string.IsNullOrEmpty(_workDir))
          throw new Exception("Required configuration setting, work-directory, was not found");
        if (!Directory.Exists(_workDir))
          Directory.CreateDirectory(_workDir);

        _destDir = ConfigurationManager.AppSettings["output-directory"];
        if (string.IsNullOrEmpty(_destDir))
          throw new Exception("Required configuration setting, output-directory, was not found");
        if (!Directory.Exists(_destDir))
          Directory.CreateDirectory(_destDir);

        _archDir = ConfigurationManager.AppSettings["archive-directory"];
        if (string.IsNullOrEmpty(_archDir))
          throw new Exception("Required configuration setting, archive-directory, was not found");
        if (!Directory.Exists(_archDir))
          Directory.CreateDirectory(_archDir);
        #endregion

        DateTime startJob = DateTime.Now;
        DateTime? fileStart = null, fileEnd = null, fileRecd = null;
        string fileName = Path.Combine(_workDir, "export.temp.txt");

        using (FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.Write))
        {
          StreamWriter sw = new StreamWriter(fs);

          sw.WriteLine("\"version 1.0\"");
          sw.WriteLine("\"id\"|\"description\"|\"start_time (UTC)\"|\"end_time (UTC)\"|" +
            "\"speed (kph)\"|\"volume (veh)\"|\"occupancy (%)\"|\"location ([lon,lat],...)\"");

          List<FileProcessLogItem> packages = FileProcessLogItem.GetLatestSession();
          foreach (FileProcessLogItem package in packages)
          {
            _currentFile = ExtractFile(package);

            if (!fileRecd.HasValue)
              fileRecd = package.DownloadDate;

            #region Process each XML file
            XmlDocument doc = new XmlDocument();
            doc.Load(_currentFile);

            XmlNamespaceManager mgr = new XmlNamespaceManager(doc.NameTable);
            mgr.AddNamespace("x", doc.DocumentElement.NamespaceURI);

            XmlNodeList rwsList = doc.DocumentElement.SelectNodes("//x:RWS[@TY=\"TMC\"]", mgr);

            DateTime dt;
            decimal d;

            int rowCt = 0;

            foreach (XmlNode rws in rwsList)
            {
              TmcExportItem currentItem = null;
              XmlNodeList rwList = rws.SelectNodes("x:RW", mgr);

              foreach (XmlNode rw in rwList)
              {
                string rw_li, rw_de, rw_pbts;
                DateTime? rw_pbt;

                XmlElement rwe = (XmlElement)rw;
                rw_li = rwe.HasAttribute("LI") ? rwe.Attributes["LI"].Value : null;
                rw_de = rwe.HasAttribute("DE") ? rwe.Attributes["DE"].Value : null;
                rw_pbts = rwe.HasAttribute("PBT") ? rwe.Attributes["PBT"].Value : null;
                rw_pbt = DateTime.TryParse(rw_pbts, out dt) ? dt : (DateTime?)null;

                if (fileStart.HasValue)
                  fileStart = fileStart < rw_pbt.Value.AddMinutes(-2) ? fileStart : rw_pbt.Value.AddMinutes(-2);
                else
                  fileStart = rw_pbt.Value.AddMinutes(-2);
                if (fileEnd.HasValue)
                  fileEnd = fileEnd > rw_pbt ? fileEnd : rw_pbt;
                else
                  fileEnd = rw_pbt;

                XmlNodeList fiList = rw.SelectNodes("descendant::x:FI", mgr);
                foreach (XmlNode fi in fiList)
                {
                  string tmc_pc, tmc_de, cf_ty, cf_sps, cf_sus, cf_ffs, cf_jfs, cf_cns, cf_ts;
                  decimal? cf_sp, cf_su, cf_ff, cf_jf, cf_cn;

                  XmlElement tmc = fi.SelectSingleNode("x:TMC", mgr) as XmlElement;
                  if (tmc != null)
                  {
                    tmc_pc = tmc.HasAttribute("PC") ? tmc.Attributes["PC"].Value : null;
                    tmc_de = tmc.HasAttribute("DE") ? tmc.Attributes["DE"].Value : null;
                  }
                  else
                  {
                    tmc_pc = tmc_de = null;
                  }

                  if (rw_li != null && tmc_de != null)
                  {
                    rw_li = rw_li.Replace("+", "P").Replace("-", "N");
                    if (TmcAttributes.ExistsAsync(rw_li, tmc_de).Result)
                    {
                      //Console.WriteLine($"Found - Row {rowCt}: {rw_li} - {tmc_de}");
                      TmcAttributes tmcAttr = TmcAttributes.GetAsync(rw_li, tmc_de).Result;

                      XmlElement cf = fi.SelectSingleNode("x:CF", mgr) as XmlElement;
                      if (cf != null)
                      {
                        cf_ty = cf.HasAttribute("TY") ? cf.Attributes["TY"].Value : null;
                        cf_sps = cf.HasAttribute("SP") ? cf.Attributes["SP"].Value : null;
                        cf_sp = decimal.TryParse(cf_sps, out d) ? d : (decimal?)null;
                        cf_sus = cf.HasAttribute("SU") ? cf.Attributes["SU"].Value : null;
                        cf_su = decimal.TryParse(cf_sus, out d) ? d : (decimal?)null;
                        cf_ffs = cf.HasAttribute("FF") ? cf.Attributes["FF"].Value : null;
                        cf_ff = decimal.TryParse(cf_ffs, out d) ? d : (decimal?)null;
                        cf_jfs = cf.HasAttribute("JF") ? cf.Attributes["JF"].Value : null;
                        cf_jf = decimal.TryParse(cf_jfs, out d) ? d : (decimal?)null;
                        cf_cns = cf.HasAttribute("CN") ? cf.Attributes["CN"].Value : null;
                        cf_cn = decimal.TryParse(cf_cns, out d) ? d : (decimal?)null;
                        cf_ts = cf.HasAttribute("TS") ? cf.Attributes["TS"].Value : null;

                        XmlNodeList ssList = cf.SelectNodes("descendant::x:SS", mgr);
                        if (ssList.Count > 0)
                        {
                          int ss_order = 1;
                          decimal ss_offset = 0;

                          foreach (XmlNode ss in ssList)
                          {
                            string ss_les, ss_sps, ss_sus, ss_ffs, ss_jfs, ss_ts;
                            decimal? ss_le, ss_sp, ss_su, ss_ff, ss_jf;

                            XmlElement sse = (XmlElement)ss;
                            ss_les = sse.HasAttribute("LE") ? sse.Attributes["LE"].Value : null;
                            ss_le = decimal.TryParse(ss_les, out d) ? d : (decimal?)null;
                            ss_sps = sse.HasAttribute("SP") ? sse.Attributes["SP"].Value : null;
                            ss_sp = decimal.TryParse(ss_sps, out d) ? d : (decimal?)null;
                            ss_sus = sse.HasAttribute("SU") ? sse.Attributes["SU"].Value : null;
                            ss_su = decimal.TryParse(ss_sus, out d) ? d : (decimal?)null;
                            ss_ffs = sse.HasAttribute("FF") ? sse.Attributes["FF"].Value : null;
                            ss_ff = decimal.TryParse(ss_ffs, out d) ? d : (decimal?)null;
                            ss_jfs = sse.HasAttribute("JF") ? sse.Attributes["JF"].Value : null;
                            ss_jf = decimal.TryParse(ss_jfs, out d) ? d : (decimal?)null;
                            ss_ts = sse.HasAttribute("TS") ? sse.Attributes["TS"].Value : null;

                            GisGeometry shape = null;
                            if (ss_le.HasValue)
                            {
                              try
                              {
                                shape =
                                  tmcAttr.Shape.GetSectionByMeasure((double)ss_offset, (double)(ss_offset + ss_le));
                              }
                              catch (Exception ex)
                              {
                                shape = null;
                              }
                              ss_offset += ss_le.Value;
                            }

                            currentItem = new TmcExportItem()
                            {
                              id = tmcAttr.Tmc,
                              description = $"{rw_de} & {tmc_de}, section {ss_order}",
                              start_time = rw_pbt.HasValue ? rw_pbt.Value.AddMinutes(-2) : (DateTime?)null,
                              end_time = rw_pbt.HasValue ? rw_pbt.Value : (DateTime?)null,
                              speed = ss_su,
                              location = shape == null ? (List<double[]>)null :
                                shape.Points.Select(p => new double[] { p.X, p.Y }).ToList()
                            };

                            ss_order++;

                            //write output
                            sw.WriteLine(currentItem.ToString());
                            sw.Flush();

                            rowCt++;
                          }
                        }
                        else
                        {
                          currentItem = new TmcExportItem()
                          {
                            id = tmcAttr.Tmc,
                            description = $"{rw_de} & {tmc_de}",
                            start_time = rw_pbt.HasValue ? rw_pbt.Value.AddMinutes(-2) : (DateTime?)null,
                            end_time = rw_pbt.HasValue ? rw_pbt.Value : (DateTime?)null,
                            speed = cf_su,
                            location = tmcAttr.Shape == null ? (List<double[]>)null :
                                tmcAttr.Shape.Points.Select(p => new double[] { p.X, p.Y }).ToList()
                          };

                          //write output
                          sw.WriteLine(currentItem.ToString());
                          sw.Flush();
                        }
                      }
                    }
                    else
                    {
                      //Console.WriteLine($"Not found - Row {rowCt}: {rw_li} - {tmc_de}");
                    }
                  }

                  rowCt++;
                }
              }
            }
            #endregion
          }

          sw.Flush();
          sw.Close();
          sw.Dispose();
          fs.Close();
          fs.Dispose();
        }

        string finalName = $"here_speed_" +
          $"{fileStart.Value.ToUniversalTime().ToString("yyyyMMddHHmm")}_" +
          $"{fileEnd.Value.ToUniversalTime().ToString("yyyyMMddHHmm")}_" +
          $"{fileRecd.Value.ToUniversalTime().ToString("yyyyMMddHHmm")}.txt";
        string finalPath = Path.Combine(_workDir, finalName);
        File.Move(fileName, finalPath);

        string compressed = CompresssFile(finalPath);
        _log.Info($"Output package: {compressed}");

        string archivePath = Path.Combine(_archDir,
          _start.Year.ToString("0000"),
          _start.Month.ToString("00"),
          _start.Day.ToString("00"),
          _start.Hour.ToString("00"));
        if (!Directory.Exists(archivePath))
          Directory.CreateDirectory(archivePath);
        archivePath = Path.Combine(archivePath, Path.GetFileName(compressed));
        
        File.Copy(compressed, archivePath);
        _log.Info($"Archive package: {archivePath}");
      }
      catch (Exception ex)
      {
        LogException("Main", ex);
      }
      finally
      {
        TimeSpan elapsed = DateTime.Now - _start;

        _log.Info($"Finishing Here Custom Export, elapsed: {elapsed}");
        _log.Info($"{new string('=', 40)}");
      }
    }

    private static void LogException(string location, Exception ex)
    {
      _log.Error($"{location} - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      if (ex.InnerException != null)
        LogException("Inner Exception", ex.InnerException);
    }

    private static string ExtractFile(FileProcessLogItem package)
    {
      string result = null;

      try
      {
        string filePath = package.ArchiveLocation;
        //<arch-loc>\xxxx.xml.gz -> <work-loc>\xxx.xml
        string destPath = Path.Combine(_workDir, package.FileName);

        if (!File.Exists(filePath))
          throw new Exception($"Source package, {filePath}, could not be found");

        using (FileStream input = new FileStream(filePath, FileMode.Open, FileAccess.Read))
        {
          using (FileStream output = new FileStream(destPath, FileMode.Create, FileAccess.Write))
          {
            GZip.Decompress(input, output, true);

            result = destPath;
          }
        }
      }
      catch (Exception ex)
      {
        LogException("ExtractFile", ex);
        throw ex;
      }

      return result;
    }

    private static string CompresssFile(string targetFile)
    {
      string result = null;

      try
      {
        string outputFileName = $"{Path.GetFileName(targetFile)}.gz";
        string destPath = Path.Combine(_destDir, outputFileName);

        if (!File.Exists(targetFile))
          throw new Exception($"Source file, {targetFile}, could not be found");

        using (FileStream input = new FileStream(targetFile, FileMode.Open, FileAccess.Read))
        {
          using (FileStream output = new FileStream(destPath, FileMode.Create, FileAccess.Write))
          {
            GZip.Compress(input, output, true);

            result = destPath;
          }
        }
      }
      catch (Exception ex)
      {
        LogException("CompressFile", ex);
        throw ex;
      }

      return result;
    }
  }
}
