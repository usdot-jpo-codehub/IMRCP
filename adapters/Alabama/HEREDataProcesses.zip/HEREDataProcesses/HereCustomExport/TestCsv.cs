﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HereCustomExport
{
  class TestCsv
  {
    static void Main(string[] args)
    {
      string srcFileName = "Alex IMRCP2-Alberto.csv";
      string srcFilePath = "d:\\temp";
      string destFileName = "Alex IMRCP2-Alberto.sample.csv";
      string srcFullName = Path.Combine(srcFilePath, srcFileName);
      string destFullName = Path.Combine(srcFilePath, destFileName);

      using (FileStream srcStream = new FileStream(srcFullName, FileMode.Open, FileAccess.Read))
      {
        using (FileStream destStream = new FileStream(destFullName, FileMode.Create, FileAccess.Write))
        {
          StreamReader sr = new StreamReader(srcStream);
          StreamWriter sw = new StreamWriter(destStream);

          for (int i = 0; i < 100; i++)
            sw.WriteLine(sr.ReadLine());

          sw.Flush();
          sw.Close();
          sr.Close();
        }
      }
    }
  }
}
