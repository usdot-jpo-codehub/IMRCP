﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CAPS.Utility.GIS.Geometry;

namespace Testing
{
  class InvertedPointsTask
  {
    private class TmcInfo
    {
      public string PointDesc { get; set; }
      public string PrimaryLinear { get; set; }
    }

    //private static readonly int WORK_BUFFER_SIZE = 0x4000;

    static void Main(string[] args)
    {
      string connStr = ConfigurationManager.ConnectionStrings["local"].ConnectionString;

      //Fetch identifying information on inverted geometries from status table
      string targetQuery = "SELECT POINT_DESC, PRIMARY_LINEAR FROM RouteGeometry_bak WHERE Id = 13";
      string dataQuery = "SELECT Id, CAST(Shape AS VARBINARY(MAX)) FROM RouteGeometry_bak WHERE POINT_DESC = @point_desc AND PRIMARY_LINEAR = @primary_linear";
      string updateQuery = "UPDATE RouteGeometry_bak SET Shape = @shape WHERE Id = @id";

      int procCount = 0;
      List<TmcInfo> tmcInfo = null;

      try
      {
        using (SqlConnection conn = new SqlConnection(connStr))
        {
          SqlCommand targetCmd = new SqlCommand(targetQuery, conn),
            dataCmd = new SqlCommand(dataQuery, conn),
            updateCmd = new SqlCommand(updateQuery, conn);

          conn.Open();

          SqlDataReader rdr = targetCmd.ExecuteReader();
          if (rdr.HasRows)
          {
            tmcInfo = new List<TmcInfo>();
            while (rdr.Read())
            {
              TmcInfo info = new TmcInfo();
              info.PointDesc = rdr.IsDBNull(0) ? null : rdr.GetString(0);
              info.PrimaryLinear = rdr.IsDBNull(1) ? null : rdr.GetString(1);
              tmcInfo.Add(info);
            }
          }

          rdr.Close();

          if (tmcInfo != null && tmcInfo.Count > 0)
          {
            int? currId;
            long shapeLen;
            byte[] shape = new byte[GisGeometry.WORK_BUFFER_SIZE];

            foreach (TmcInfo info in tmcInfo)
            {
              dataCmd.Parameters.Clear();
              dataCmd.Parameters.AddWithValue("@point_desc", info.PointDesc);
              dataCmd.Parameters.AddWithValue("@primary_linear", info.PrimaryLinear);

              currId = null;
              shapeLen = GisGeometry.WORK_BUFFER_SIZE;
              rdr = dataCmd.ExecuteReader();
              if (rdr.Read())
              {
                currId = rdr.IsDBNull(0) ? (int?)null : rdr.GetInt32(0);
                if (!rdr.IsDBNull(1))
                  shapeLen = rdr.GetBytes(1, 0, shape, 0, shape.Length);
              }

              rdr.Close();

              if (currId != null && shapeLen < GisGeometry.WORK_BUFFER_SIZE)
              {
                try
                {
                  Console.WriteLine($"Inverting {info.PointDesc}, {info.PrimaryLinear}");

                  GisGeometry geometry = GisGeometry.FromBytes(shape);
                  geometry.ReversePoints();

                  targetCmd = new SqlCommand(updateQuery, conn);
                  updateCmd.Parameters.Clear();
                  updateCmd.Parameters.AddWithValue("@id", currId);
                  updateCmd.Parameters.AddWithValue("@shape", geometry.ToBinary());

                  updateCmd.ExecuteNonQuery();

                  procCount++;
                }
                catch (Exception ex)
                {
                  Console.WriteLine($"{ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
                }
              }
            }
          }
          else
          {
            Console.WriteLine("No records found to convert");
          }
        }
      }
      catch (Exception ex)
      {
        Console.WriteLine($"{ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      }

      Console.Write($"{procCount} records processed. Press any key to exit...");
      Console.ReadKey();
    }
  }
}
