﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing
{
  public class SdmhTable
  {
    private static readonly char TOP_LEFT_CORNER = (char)0x250c;
    private static readonly char TOP_RIGHT_CORNER = (char)0x2510;
    private static readonly char BOTTOM_LEFT_CORNER = (char)0x2514;
    private static readonly char BOTTOM_RIGHT_CORNER = (char)0x2518;
    private static readonly char FOUR_CELL_CORNER = (char)0x253c;
    private static readonly char TOP_COLUMN_DIVIDER = (char)0x252c;
    private static readonly char CENTER_COLUMN_DIVIDER = (char)0x2502;
    private static readonly char BOTTOM_COLUMN_DIVIDER = (char)0x2534;
    private static readonly char LEFT_ROW_DIVIDER = (char)0x251c;
    private static readonly char CENTER_ROW_DIVIDER = (char)0x2500;
    private static readonly char RIGHT_ROW_DIVIDER = (char)0x2524;
    private static readonly int CELL_CHAR_WIDTH = 6;

    public string GetSdmhTable(List<SdmhTableCell> data)
    {
      string result = null;

      int rowUb = data.Max(c => c.Row);
      int colUb = data.Max(c => c.Col);

      List<string> colHeaders = data
        .Select(c => ($"{c.Timestamp.Hour.ToString("00")}:{c.Timestamp.Minute.ToString("00")}").PadLeft(CELL_CHAR_WIDTH))
        .Distinct()
        .ToList();
      //colHeaders.Sort();

      //Total number of columns is column upper bound + 1 + 1 row header column;
      result += GetTableTopBorder(colUb + 2);
      result += GetColumnHeaderLine(colHeaders);
      result += GetTableRowBorder(colUb + 2);

      for (int currRow = 0; currRow <= rowUb; currRow++)
      {
        List<SdmhTableCell> rowData = data.Where(c => c.Row == currRow).ToList();

        result += GetDataRowLine(rowData);

        if (currRow < rowUb)
          result += GetTableRowBorder(colUb + 2);
        else
          result += GetTableBottomBorder(colUb + 2);
      }

      return result;
    }

    #region Row borders

    private string GetTableTopBorder(int noCells)
    {
      string result = null;

      result += TOP_LEFT_CORNER;
      for (int col = 0; col < noCells; col++)
      {
        result += new string(CENTER_ROW_DIVIDER, CELL_CHAR_WIDTH);
        if (col < noCells - 1)
          result += TOP_COLUMN_DIVIDER;
        else
          result += TOP_RIGHT_CORNER;
      }

      result += "\r\n";

      return result;
    }

    private string GetTableBottomBorder(int noCells)
    {
      string result = null;

      result += BOTTOM_LEFT_CORNER;
      for (int col = 0; col < noCells; col++)
      {
        result += new string(CENTER_ROW_DIVIDER, CELL_CHAR_WIDTH);
        if (col < noCells - 1)
          result += BOTTOM_COLUMN_DIVIDER;
        else
          result += BOTTOM_RIGHT_CORNER;
      }

      result += "\r\n";

      return result;
    }

    private string GetTableRowBorder(int noCells)
    {
      string result = null;

      result += LEFT_ROW_DIVIDER;
      for (int col = 0; col < noCells; col++)
      {
        result += new string(CENTER_ROW_DIVIDER, CELL_CHAR_WIDTH);
        if (col < noCells - 1)
          result += FOUR_CELL_CORNER;
        else
          result += RIGHT_ROW_DIVIDER;
      }

      result += "\r\n";

      return result;
    }

    #endregion

    #region Column headers

    private string GetColumnHeaderLine(List<string> colHeaders)
    {
      string result = null;

      //Include a blank column for row headers
      result += CENTER_COLUMN_DIVIDER + new string(' ', CELL_CHAR_WIDTH) + CENTER_COLUMN_DIVIDER;
      foreach (string colHeader in colHeaders)
        result += colHeader.PadLeft(CELL_CHAR_WIDTH) + CENTER_COLUMN_DIVIDER;

      result += "\r\n";

      return result;
    }

    #endregion

    #region Row

    private string GetDataRowLine(List<SdmhTableCell> data)
    {
      string result = null;

      result = string.Empty + CENTER_COLUMN_DIVIDER
        + data.First().Milepoint.ToString().PadLeft(CELL_CHAR_WIDTH) + CENTER_COLUMN_DIVIDER;

      for (int currCol = 0; currCol < data.Count; currCol++)
        result += data.First(c => c.Col == currCol).Speed.ToString().PadLeft(CELL_CHAR_WIDTH) + CENTER_COLUMN_DIVIDER;

      result += "\r\n";

      return result;
    }

    #endregion

    public string GetSdmhCsv(List<SdmhTableCell> data)
    {
      string result = null;

      int rowUb = data.Max(c => c.Row);
      int colUb = data.Max(c => c.Col);

      List<string> colHeaders = data
        .Select(c => ($"{c.Timestamp.Hour.ToString("00")}:{c.Timestamp.Minute.ToString("00")}").PadLeft(CELL_CHAR_WIDTH))
        .Distinct()
        .ToList();
      //colHeaders.Sort();
      colHeaders.Insert(0, "Mile/Time");

      string currLine = string.Empty;

      foreach (string hdr in colHeaders)
      {
        if (currLine.Length > 0)
          currLine += ",";
        currLine += hdr;
      }
      currLine += "\r\n";
      result += currLine;

      for (int currRow = 0; currRow <= rowUb; currRow++)
      {
        currLine = data.First(c => c.Row == currRow).Milepoint.ToString();

        for (int currCol = 0; currCol <= colUb; currCol++)
        {
          currLine += ",";

          SdmhTableCell currCell = data.FirstOrDefault(c => c.Col == currCol && c.Row == currRow);
          if (currCell == null)
            currLine += "null";
          else
            currLine += currCell.Speed.ToString();
        }

        currLine += "\r\n";
        result += currLine;
      }

      return result;
    }
  }
}
