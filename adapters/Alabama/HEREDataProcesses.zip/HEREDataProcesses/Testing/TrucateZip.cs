﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testing
{
  class TrucateZip
  {
    static void Main(string[] args)
    {
      string fileIn = "d:\\temp\\here_speed_202306152106_202306152108_202306152108.txt.orig.gz";
      string fileOut = "d:\\temp\\here_speed_202306152106_202306152108_202306152108.txt.trunc.gz";
      int bytesToWrite = 479232;

      using (FileStream inStream = new FileStream(fileIn, FileMode.Open, FileAccess.Read))
      {
        using (FileStream outStream = new FileStream(fileOut, FileMode.Create, FileAccess.Write))
        {
          int bytesRead = 0;
          byte[] buffer = new byte[0x10000];

          while (bytesRead < bytesToWrite)
          {
            int bytesToRead = Math.Min(bytesToWrite - bytesRead, buffer.Length);
            bytesRead += inStream.Read(buffer, 0, bytesToRead);
            outStream.Write(buffer, 0, bytesToRead);
          }

          outStream.Flush();
          outStream.Close();
          inStream.Close();
        }
      }
    }
  }
}
