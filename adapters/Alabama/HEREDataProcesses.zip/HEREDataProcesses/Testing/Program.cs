﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

using RouteSpeedService.Data;
using RouteSpeedService.Models;

namespace Testing
{
  public class RouteSequenceDTO
  {
    public int SequenceId { get; set; }
    public string RouteDesignation { get; set; }
    public string Direction { get; set; }
    public bool MeasureAscending { get; set; }
    public int SegmentCount { get; set; }
    public decimal TotalLength { get; set; }
    public double MeasureStart { get; set; }
    public double MeasureEnd { get; set; }
  }

  //public class SdmhTableDataDTO
  //{
  //  public DateTime SessionTimestamp { get; set; }
  //  public string SegmentDescription { get; set; }
  //  public decimal CurrentSegmentSpeed { get; set; }
  //  public decimal? PreviousSegmentSpeed { get; set; }
  //  public decimal? DeltaSpeed { get; set; }
  //  public double MeasureFrom { get; set; }
  //  public double MeasureTo { get; set; }
  //  public long RowOrder { get; set; }
  //  public long ColumnOrder { get; set; }

  //  public override string ToString()
  //  {
  //    return $"{RowOrder},{ColumnOrder}:\t{SessionTimestamp}\t{SegmentDescription}\r\n\t{CurrentSegmentSpeed}\t{PreviousSegmentSpeed}\t{DeltaSpeed}\t{MeasureFrom}\t{MeasureTo}";
  //  }
  //}

  public class SdmhTableCell
  {
    public int Row { get; set; }
    public int Col { get; set; }
    public DateTime Timestamp { get; set; }
    public int Milepoint { get; set; }
    public decimal Speed { get; set; }

    public override string ToString()
    {
      return $"{Row},{Col}:\t{Timestamp}\t{Milepoint}\t{Speed}";
    }
  }

  class Program
  {
    static void Main(string[] args)
    {
      string connStr = ConfigurationManager.ConnectionStrings["archive"].ConnectionString;
      string sProc = "GetSdmhTableData_archive";

      SdmhTableDataParameters parameters = new SdmhTableDataParameters()
      {
        SequenceId = 18,
        StartTime = new DateTime(2018, 06, 15, 7, 30, 00),
        EndTime = new DateTime(2018, 06, 15, 08, 30, 00),
        StartMile = 250,
        EndMile = 275
      };

    //string seqInfo = "SELECT SequenceId, RouteDesignation, Direction, MeasureAscending, SegmentCount, TotalLength, MeasureStart, MeasureEnd " +
    //    "FROM InterstateRouteSequences " +
    //    "WHERE SequenceId = @sequenceId";

      RouteSequenceDTO seqDto = null;
      List<SdmhTableDataDTO> data = SdmhQuery.GetSdmhTableData_archive(parameters);

      //using (SqlConnection conn = new SqlConnection(connStr))
      //{
      //  //SqlCommand seqCmd = new SqlCommand(seqInfo, conn);
      //  //seqCmd.Parameters.AddWithValue("@sequenceId", sequenceId);

      //  SqlCommand cmd = new SqlCommand(sProc, conn);
      //  cmd.CommandType = CommandType.StoredProcedure;
      //  cmd.Parameters.AddWithValue("@sequenceId", parameters.SequenceId);
      //  cmd.Parameters.AddWithValue("@startTime", parameters.StartTime);
      //  cmd.Parameters.AddWithValue("@endTime", parameters.EndTime);
      //  cmd.Parameters.AddWithValue("@startMile", parameters.StartMile);
      //  cmd.Parameters.AddWithValue("@endMile", parameters.EndMile);

      //  conn.Open();

      //  SqlDataReader seqRdr = seqCmd.ExecuteReader();

      //  if (seqRdr.HasRows)
      //  {
      //    //The query could return multiple rows but in this case the first (or any) row
      //    //will have all the information needed
      //    if (seqRdr.Read())
      //    {
      //      seqDto = new RouteSequenceDTO()
      //      {
      //        SequenceId = seqRdr.GetInt32(0),
      //        RouteDesignation = seqRdr.GetString(1),
      //        Direction = seqRdr.GetString(2),
      //        MeasureAscending = seqRdr.GetBoolean(3),
      //        SegmentCount = seqRdr.GetInt32(4),
      //        TotalLength = seqRdr.GetDecimal(5),
      //        MeasureStart = seqRdr.GetDouble(6),
      //        MeasureEnd = seqRdr.GetDouble(7)
      //      };
      //    }
      //  }

      //  seqRdr.Close();

      //  SqlDataReader rdr = cmd.ExecuteReader();

      //  if (rdr.HasRows)
      //  {
      //    data = new List<SdmhTableDataDTO>();

      //    while (rdr.Read())
      //    {
      //      SdmhTableDataDTO dto = new SdmhTableDataDTO()
      //      {
      //        SessionTimestamp = rdr.GetDateTime(0),
      //        SegmentDescription = rdr.GetString(1),
      //        CurrentSegmentSpeed = rdr.GetDecimal(2),
      //        PreviousSegmentSpeed = rdr.IsDBNull(3) ? (decimal?)null : rdr.GetDecimal(3),
      //        DeltaSpeed = rdr.IsDBNull(4) ? (decimal?)null : rdr.GetDecimal(4),
      //        MeasureFrom = rdr.GetDouble(5),
      //        MeasureTo = rdr.GetDouble(6),
      //        RowOrder = rdr.GetInt64(7),
      //        ColumnOrder = rdr.GetInt64(8)
      //      };

      //      data.Add(dto);
      //    }
      //  }

      //  conn.Close();
      //}

      decimal prevSegSpeed = 0;

      foreach (SdmhTableDataDTO dto in data)
      {
        if (dto.SubsegmentOrder != null)
        {
          if (dto.MeasureFrom < dto.MeasureTo)
          {
            dto.MeasureFrom += dto.SubsegmentOffset.Value;
            dto.MeasureTo = dto.MeasureFrom + dto.SubegmentLength.Value;
          }
          else
          {
            dto.MeasureFrom -= dto.SubsegmentOffset.Value;
            dto.MeasureTo = dto.MeasureFrom - dto.SubegmentLength.Value;
          }
        }

        if (dto.RowOrder > 1)
        {
          dto.PreviousSegmentSpeed = prevSegSpeed;
          dto.DeltaSpeed = dto.CurrentSegmentSpeed - dto.PreviousSegmentSpeed;
        }
        prevSegSpeed = dto.CurrentSegmentSpeed;

        Console.WriteLine(dto);
      }

      ////One column per history session.
      //int colCt = (int)data.Max(r => r.ColumnOrder);
      ////The output rows are not the same as the rows input from the query.
      ////The input rows correspond to TMC segments or subsegments. The output rows are
      ////milepoints. The number of output rows contributed by any one input segment
      ////depends on how long it is (and a very short segment could be skipped entirely).
      //int rowCt = (int)(endMile - startMile + 1);
      //int currentMile = (int)(seqDto.MeasureAscending ?  startMile : endMile);

      //SdmhTableCell[,] SdmhTable = new SdmhTableCell[colCt, rowCt];

      //for (int row = 0; row < rowCt; row++)
      //{
      //  for (int col = 0; col < colCt; col++)
      //  {
      //    SdmhTableDataDTO currDto = (seqDto.MeasureAscending
      //        ? data.FirstOrDefault(dto => dto.ColumnOrder == col + 1 && dto.MeasureFrom <= currentMile && dto.MeasureTo >= currentMile)
      //        : data.FirstOrDefault(dto => dto.ColumnOrder == col + 1 && dto.MeasureFrom >= currentMile && dto.MeasureTo <= currentMile))
      //        //Just in case there's no match for the above criteria, avoid a null ptr ex.
      //        ?? new SdmhTableDataDTO();

      //    SdmhTable[col, row] = new SdmhTableCell()
      //    {
      //      Row = row,
      //      Col = col,
      //      Timestamp = data.First(dto => dto.ColumnOrder == col + 1).SessionTimestamp,
      //      Milepoint = currentMile,
      //      Speed = currDto.CurrentSegmentSpeed
      //    };
      //  }

      //  if (seqDto.MeasureAscending)
      //    currentMile++;
      //  else
      //    currentMile--;
      //}

      //List<SdmhTableCell> cList = new List<SdmhTableCell>();

      //foreach (SdmhTableCell cell in SdmhTable)
      //{
      //  cList.Add(cell);
      //  Console.WriteLine(cell.ToString());
      //}

      //SdmhTable t = new SdmhTable();
      //string table = t.GetSdmhCsv(cList);

      //Console.WriteLine();
      //Console.WriteLine(table);

      //FileStream fs = new FileStream("sdmh_i85n_current.2.csv", FileMode.Create);
      //StreamWriter sw = new StreamWriter(fs);
      //sw.Write(table);
      //sw.Flush();
      //sw.Close();

      Console.Write("Press any key...");
      Console.ReadKey();
    }
  }
}
