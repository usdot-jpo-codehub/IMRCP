﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NLog;

using CAPS.Utility.GIS.Geometry;
using HereSharedTypes.Models;

namespace HereOneOffTasks
{
  class Program
  {
    private static Logger _log;
    private static double _defaultTolerance;

    static void Main(string[] args)
    {
      List<TmcAttribute> tmcAttrs;
      TmcAttribute currentTmcAttr;
      TmcGeoItem currentGeoItem = null;
      GisPoint currentStartPoint, currentEndPoint;

      _log = LogManager.GetLogger("Main");

      try
      {
        string s = ConfigurationManager.AppSettings["default-float-equality-tolerance"];
        if (s == null)
          throw new Exception("Required configuration setting, default-float-equality-tolerance, was not found");
        if (!double.TryParse(s, out _defaultTolerance))
          throw new Exception($"Configuration setting, default-float-equality-tolerance, is not valid");

        tmcAttrs = TmcAttribute.GetTmcAttributes();

        foreach(TmcAttribute attr in tmcAttrs)
        {
          currentTmcAttr = attr;

          currentStartPoint = new GisPoint() { X = (double)attr.StartLon, Y = (double)attr.StartLat };
          currentEndPoint = new GisPoint() { X = (double)attr.EndLon, Y = (double)attr.EndLat };

          List<TmcGeoItem> geoItems = TmcGeoItem.GetTmcGeoItems(attr.Tmc);
          List<TmcGeoItem> candidates, ordered = new List<TmcGeoItem>();
          bool done = false, valid = false;

          while(!done)
          {
            candidates = geoItems.Where(i => WithinTolerance(i.Shape.Points.First(), currentStartPoint) ||
              WithinTolerance(i.Shape.Points.Last(), currentStartPoint)).ToList();

            if (candidates.Count == 0)
            {
              valid = false;
              done = true;
              _log.Error($"No matching link could be found to follow TMC: {currentTmcAttr.Tmc}, " +
                $"Link: {(currentGeoItem == null ? "root" : currentGeoItem.LinkId.ToString())}");
            }
            else if (candidates.Count > 1)
            {
              valid = false;
              done = true;
              _log.Error($"Multiple matching links found to follow TMC: {currentTmcAttr.Tmc}, " +
                $"Link: {(currentGeoItem == null ? "ruut" : currentGeoItem.LinkId.ToString())}");
            }
            else
            {
              currentGeoItem = candidates.First();
              if (WithinTolerance(currentGeoItem.Shape.Points.Last(), currentStartPoint))
              {
                currentGeoItem.Shape.Points.Reverse();
                currentGeoItem.DirTravel = currentGeoItem.DirTravel == "F" ? "T" : "F";
              }

              geoItems.Remove(currentGeoItem);
              ordered.Add(currentGeoItem);
              if (!currentGeoItem.Create())
                _log.Error($"Error creating geo for Tmc {currentGeoItem.Tmc}, Link {currentGeoItem.LinkId}");

              currentStartPoint = currentGeoItem.Shape.Points.Last();

              done = geoItems.Count == 0;
              valid = done && WithinTolerance(currentEndPoint, currentGeoItem.Shape.Points.Last());
              if (valid)
                _log.Info($"Found matching end point at Tmc {currentGeoItem.Tmc}, Link {currentGeoItem.LinkId} ");
            }
          }

          if (valid)
          {
            GisGeometry shape = null;

            foreach (TmcGeoItem item in ordered)
            {
              if (shape == null)
                shape = item.Shape;
              else
                shape = shape.ConcatenateLineString(item.Shape, _defaultTolerance);
            }
            shape.AllocateMeasure((double)currentTmcAttr.TmcLength, true);
            TmcShapeItem tmcShape = new TmcShapeItem()
            {
              ObjectId = currentTmcAttr.ObjectId,
              Tmc = currentTmcAttr.Tmc,
              Shape = shape
            };

            if (!tmcShape.Create())
              _log.Error($"Error creating shape for Tmc {currentTmcAttr.Tmc}");
          }
        }
      }
      catch(Exception ex)
      {
        _log.Error($"{ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      }
    }

    static bool WithinTolerance(GisPoint a, GisPoint b, double? tolerance = null)
    {
      double tol = tolerance ?? _defaultTolerance;

      bool result = Math.Abs(a.X - b.X) < tol && Math.Abs(a.Y - b.Y) < tol;

      return result;
    }
  }
}
