﻿using System;
using System.ServiceProcess;
using System.Threading;

using NLog;

using CustomExportUploadService.Process;

namespace CustomExportUploadService
{
  public partial class UploadService : ServiceBase
  {
    private Logger _log;
    private ProcessController _controller;
    private Thread _controllerThread;

    public UploadService()
    {
      InitializeComponent();

      _log = LogManager.GetLogger(this.GetType().Name);

      CanStop = true;
    }

    protected override void OnStart(string[] args)
    {
      try
      {
        _log.Info("Starting service...\r\n=====================================================================================\r\n");

        _controller = new ProcessController();
        _controllerThread = new Thread(_controller.Process);
        _controllerThread.Start();
      }
      catch (Exception ex)
      {
        _log.Error($"OnStart - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      }
    }

    protected override void OnStop()
    {
      try
      {
        _log.Info("Stopping service...\r\n=====================================================================================\r\n");

        _controllerThread.Abort();
      }
      catch (Exception ex)
      {
        _log.Error($"OnStop - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      }
    }
  }
}
