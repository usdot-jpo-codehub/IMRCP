﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;

using NLog;

using WinSCP;

using CustomExportUploadService.Events;

namespace CustomExportUploadService.Process
{
  public class FileUploader
  {
    private Logger _log;
    private string _hostName;
    private int _hostPort;
    private int _timeout;
    private string _hostKeyFingerprint;
    private string _hostRootPath;
    private string _privateKeyPath;
    private string _scpUsername;
    private string _scpPassword;
    private string _fileNamePattern;
    private Regex _fileNameRegex;

    public FileUploader()
    {
      _log = LogManager.GetLogger(this.GetType().Name);

      try
      {
        _hostName = ConfigurationManager.AppSettings["scp-host-name"];
        if (_hostName == null)
          throw new Exception("Required configuration setting, scp-host-name, was not found");
        string sPort = ConfigurationManager.AppSettings["scp-host-port"];
        if (sPort == null)
          throw new Exception("Required configuration setting, scp-host-port, was not found");
        if (!int.TryParse(sPort, out _hostPort))
          throw new Exception($"Configuration setting scp-host-port, {sPort}, is not valid");
        string sTimeout = ConfigurationManager.AppSettings["scp-timeout-in-seconds"];
        if (sTimeout == null)
          throw new Exception("Required configuration setting, scp-timeout-in-seconds, was not found");
        if (!int.TryParse(sTimeout, out _timeout))
          throw new Exception($"Configuration setting scp-timeout-in-seconds, {sTimeout}, is not valid");
        _hostKeyFingerprint = ConfigurationManager.AppSettings["scp-host-key-fingerprint"];
        if (_hostKeyFingerprint == null)
          throw new Exception("Required configuration setting, scp-host-key-fingerprint, was not found");
        _hostRootPath = ConfigurationManager.AppSettings["scp-root-path"];
        if (_hostRootPath == null)
          throw new Exception("Required configuration setting, scp-root-path, was not found");
        _privateKeyPath = ConfigurationManager.AppSettings["scp-private-key-path"];
        if (_privateKeyPath == null)
          throw new Exception("Required configuration setting, scp-private-key-path, was not found");
        _scpUsername = ConfigurationManager.AppSettings["scp-username"];
        if (_scpUsername == null)
          throw new Exception("Required configuration setting, scp-username, was not found");
        _scpPassword = ConfigurationManager.AppSettings["scp-password"];
        if (_scpPassword == null)
          throw new Exception("Required configuration setting, scp-password, was not found");
        _fileNamePattern = ConfigurationManager.AppSettings["file-name-pattern"];
        if (_fileNamePattern == null)
          throw new Exception("Required configuration setting, file-name-pattern, was not found");
        _fileNameRegex = new Regex(_fileNamePattern);
      }
      catch(Exception ex)
      {
        _log.Error($"ctor - {ex.Message}");
        throw ex;
      }
    }

    public void UploadFile(object sourceFilepath)
    {
      string filepath, filename, recd, monthdir, daydir;

      try
      {
        _log.Info($"Starting upload process for {sourceFilepath}");

        filepath = (string)sourceFilepath;
        if (!File.Exists(filepath))
        {
          _log.Error($"The source file, {filepath}, does not exist");
        }
        else
        {
          filename = Path.GetFileName(filepath);
          Match m = _fileNameRegex.Match(filename);
          if (!m.Success)
          {
            _log.Error($"File name, {filename}, does not match expected pattern");
          }
          else
          {
            recd = m.Groups["recd"].Value;
            monthdir = recd.Substring(0, 6);
            daydir = recd.Substring(0, 8);

            SessionOptions options = new SessionOptions()
            {
              Protocol = Protocol.Scp,
              HostName = _hostName,
              PortNumber = _hostPort,
              UserName = _scpUsername,
              Password = _scpPassword,
              SshHostKeyFingerprint = _hostKeyFingerprint,
              SshPrivateKeyPath = _privateKeyPath,
              TimeoutInMilliseconds = _timeout * 1000
            };

            using (Session session = new Session())
            {
              session.Open(options);

              string currentPath = $"{_hostRootPath}/{monthdir}";
              if (!session.FileExists(currentPath))
                session.CreateDirectory(currentPath);
              currentPath = $"{currentPath}/{daydir}";
              if (!session.FileExists(currentPath))
                session.CreateDirectory(currentPath);

              //Do not remove the file now because it may not have been released
              //by the process that created it.
              TransferEventArgs tArgs = session.PutFileToDirectory(filepath, currentPath, false);

              //Try to remove the source file from the local directory, retrying if
              //the file is still locked.
              int tries = 0;
              bool success = false;
              while (!success && tries < 3)
              {
                try
                {
                  File.Delete(filepath);
                  success = true;
                }
                catch
                {
                  tries++;
                  if (tries < 3)
                    Thread.Sleep(1000);
                  else
                    _log.Error($"Error removing file {filepath}");
                }
              }

              FileUploaderEventArgs args =
                new FileUploaderEventArgs($"Upload of {sourceFilepath}", tArgs);
              OnFileUploaderEvent(args);
            }
          }
        }

        _log.Info($"Finishing upload process for {sourceFilepath}");
      }
      catch (Exception ex)
      {
        LogException("UploadFile", ex);

        FileUploaderEventArgs args = 
          new FileUploaderEventArgs($"Exception uploading {sourceFilepath}", ex);
        OnFileUploaderEvent(args);
      }
    }

    private void LogException(string location, Exception ex)
    {
      _log.Error($"{location} - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      if (ex.InnerException != null)
        LogException("Inner Exception", ex.InnerException);
    }

    #region Events

    public event FileUploaderEventHandler FileUploaderEvent;

    private void OnFileUploaderEvent(FileUploaderEventArgs args)
    {
      FileUploaderEventHandler handler = FileUploaderEvent;

      if (handler != null)
        handler(this, args);
    }

    #endregion
  }
}
