﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using NLog;

using CustomExportUploadService.Events;

namespace CustomExportUploadService.Process
{
  public class ProcessController
  {
    private Logger _log;
    private string _workDirectory;
    private FileSystemWatcher _fileWatcher;
    private FileUploader _uploader;

    public ProcessController()
    {
      _log = LogManager.GetLogger(this.GetType().Name);

      try
      {
        _workDirectory = ConfigurationManager.AppSettings["source-work-directory"];
        if (_workDirectory == null)
          throw new Exception("Required configuration setting, source-work-directory, was not found");
        if (!Directory.Exists(_workDirectory))
          throw new Exception($"Configured work directory, {_workDirectory}, does not exist");

        _uploader = new FileUploader();
        _uploader.FileUploaderEvent += HandleFileUploaderEvent;

        _fileWatcher = new FileSystemWatcher(_workDirectory, "*.gz");
        _fileWatcher.Created += FileCreated;
      }
      catch (Exception ex)
      {
        LogException("ctor", ex);
        throw ex;
      }
    }

    public void Process()
    {
      _fileWatcher.EnableRaisingEvents = true;

      while (true)
        Thread.Sleep(1000);
    }

    private void HandleFileUploaderEvent(object sender, FileUploaderEventArgs args)
    {
      if (args.Result != null)
      {
        if (args.Result.Error != null)
        {
          _log.Error($"Error uploading file {args.Result.Destination}");
          LogException("HandleFileUploaderEvent", args.Result.Error);
        }
        else
        {
          _log.Info($"Uploaded file {args.Result.Destination}, {args.Result.Length} bytes");
        }
      }
    }

    private void LogException(string location, Exception ex)
    {
      _log.Error($"{location} - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      if (ex.InnerException != null)
        LogException("Inner Exception", ex.InnerException);
    }

    private void FileCreated(object sender, FileSystemEventArgs args)
    {
      _log.Info($"File created: {args.FullPath}");

      bool ready = false;
      int tries = 0;
      while (!ready && tries < 25)
      {
        try
        {
          FileStream fs = File.Open(args.FullPath, FileMode.Open, FileAccess.Read, FileShare.None);
          fs.Close();
          ready = true;
        }
        catch
        {
          tries++;
          Thread.Sleep(5000);
        }
      }

      if (ready)
      {
        Thread t = new Thread(_uploader.UploadFile);
        t.Start(args.FullPath);
      }
      else
      {
        _log.Error($"Cannot get access to file: {args.FullPath}");
      }
    }
  }
}
