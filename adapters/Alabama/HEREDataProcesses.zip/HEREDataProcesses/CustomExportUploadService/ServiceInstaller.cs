﻿using System.ComponentModel;

namespace CustomExportUploadService
{
  [RunInstaller(true)]
  public partial class ServiceInstaller : System.Configuration.Install.Installer
  {
    public ServiceInstaller()
    {
      InitializeComponent();
    }
  }
}
