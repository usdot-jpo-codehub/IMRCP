﻿using System;

using WinSCP;

namespace CustomExportUploadService.Events
{
  public delegate void FileUploaderEventHandler(object sender, FileUploaderEventArgs args);

  public class FileUploaderEventArgs : EventArgs
  {
    private string _message;
    private Exception _ex;
    private TransferEventArgs _tArgs;

    public string Message { get { return _message; } }

    public Exception Exception { get { return _ex; } }

    public TransferEventArgs Result { get { return _tArgs; } }

    public FileUploaderEventArgs(string message, TransferEventArgs result)
      : base()
    {
      _message = message;
      _ex = null;
      _tArgs = result;
    }

    public FileUploaderEventArgs(string message, Exception ex)
      : base()
    {
      _message = message;
      _ex = ex;
      _tArgs = null;
    }
  }
}
