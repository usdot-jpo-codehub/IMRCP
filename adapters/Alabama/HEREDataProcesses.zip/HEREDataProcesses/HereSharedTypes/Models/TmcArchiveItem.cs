﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CAPS.Utility.GIS.Geometry;

namespace HereSharedTypes.Models
{
  public partial class TmcArchiveItem : ModelBase
  {
    private static readonly decimal KM_PER_MILE = 1.609344m;

    public int PackageId { get; set; }
    public string tmc { get; set; }
    public string rw_de { get; set; }
    public string tmc_de { get; set; }
    public DateTime rw_pbt { get; set; }
    public decimal cf_su { get; set; }
    public int? ss_order { get; set; }
    public decimal? ss_su { get; set; }
    public decimal? ss_le { get; set; }
    public List<double[]> location { get; set; }
    public GisGeometry Shape { get; set; }

    private string id { get { return this.tmc; } }
    private string description { get { return $"{this.rw_de} & {this.tmc_de}"; } }
    public DateTime start_time { get { return this.rw_pbt.AddMinutes(-2); } }
    public DateTime end_time { get { return this.rw_pbt; } }
    private decimal speed { get { return this.ss_su.HasValue ? this.ss_su.Value : this.cf_su; } }
    private int? volume { get { return null; } }
    private int? occupancy { get { return null; } }

    public override string ToString()
    {
      string sloc = null, result = null;

      if (location != null)
      {
        foreach (double[] pt in location)
        {
          if (sloc != null)
            sloc += ",";
          sloc += $"[{pt[0].ToString("###.000000")},{pt[1].ToString("###.000000")}]";
        }
      }

      result = $"\"{this.id}\"|" +
        $"\"{this.description}\"|" +
        $"{this.start_time.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss")}|" +
        $"{this.end_time.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss")}|" +
        $"{(this.speed * KM_PER_MILE).ToString("##.0")}|" +
        $"{(this.volume.HasValue ? this.volume.Value.ToString() : string.Empty)}|" +
        $"{(this.occupancy.HasValue ? this.occupancy.Value.ToString("##.0") : string.Empty)}|" +
        $"{sloc}";

      return result;
    }

  }
}
