﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CAPS.Utility.GIS.Geometry;

namespace HereSharedTypes.Models
{
  public partial class TmcArchiveItem : ModelBase
  {
    public static List<TmcArchiveItem> GetExportItems(int packageId, string connSelector = null)
    {
      List<TmcArchiveItem> result = null;
      string connString;
      //string query = "SELECT a.TMC, i.RW_DE, i.TMC_DE, i.RW_PBT, i.CF_SU, " +
      //  "i.SS_ORDER, i.SS_SU, i.SS_LE, CAST(s.Shape AS VARBINARY(MAX)) " +
      //  "FROM HERE.dbo.TMC_ATTR_CURRENT a " +
      //  "JOIN TmcItems i WITH(NOLOCK) ON a.POINT_DESC = i.TMC_DE AND a.PRIMARY_LINEAR = i.LINEAR " +
      //  "LEFT OUTER JOIN HERE.dbo.TMC_SHAPES_CURRENT s ON a.TMC = s.TMC " +
      //  "WHERE i.PackageId = @packageId " +
      //  "ORDER BY a.TMC, i.SS_ORDER";
      string query = "GetExportItemsForPackage";

      try
      {
        #region Select conn string
        if (connSelector != null)
        {
          connString = ConfigurationManager.ConnectionStrings[connSelector].ConnectionString;
          if (connString == null)
            throw new Exception($"No conn string was found for specified selector: {connSelector}");
        }
        else
        {
          connString = _connString; //ModelBase default conn string
        }
        #endregion

        using (SqlConnection conn = new SqlConnection(connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.CommandType = System.Data.CommandType.StoredProcedure;
          cmd.CommandTimeout = 300;
          cmd.Parameters.AddWithValue("@packageId", packageId);

          conn.Open();

          SqlDataReader rdr = cmd.ExecuteReader();
          if (rdr.HasRows)
          {
            result = new List<TmcArchiveItem>();
            while (rdr.Read())
            {
              TmcArchiveItem item = new TmcArchiveItem()
              {
                PackageId = packageId,
                tmc = rdr.GetString(0),
                rw_de = rdr.GetString(1),
                tmc_de = rdr.GetString(2),
                rw_pbt = rdr.GetDateTime(3),
                cf_su = rdr.GetDecimal(4),
                ss_order = rdr.IsDBNull(5) ? (int?)null : rdr.GetInt32(5),
                ss_su = rdr.IsDBNull(6) ? (decimal?)null : rdr.GetDecimal(6),
                ss_le = rdr.IsDBNull(7) ? (decimal?)null : rdr.GetDecimal(7)
              };

              if (!rdr.IsDBNull(8))
              {
                byte[] buffer = new byte[1 * 1024 * 1024];
                long bufferCount = 0;
                bufferCount = rdr.GetBytes(8, 0, buffer, 0, buffer.Length);
                byte[] rawShape = new byte[bufferCount];
                Array.Copy(buffer, 0, rawShape, 0, bufferCount);

                item.Shape = GisGeometry.FromBytes(rawShape);
              }

              result.Add(item);
            }
          }

          conn.Close();
        }
      }
      catch (Exception ex)
      {
        LogException("TmcArchiveItem", "GetExprtItems", ex);
        throw ex;
      }

      return result;
    }
  }
}
