﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HereSharedTypes.Models
{
  public partial class FileProcessLogItem : ModelBase
  {
    public int Id { get; set; }
    public string PackageName { get; set; }
    public string FileName { get; set; }
    public string ArchiveLocation { get; set; }
    public DateTime DownloadDate { get; set; }
    public DateTime? ExtractionDate { get; set; }
    public DateTime? ProcessDate { get; set; }
    public DateTime? ArchiveDate { get; set; }
    public int? NumberProcessed { get; set; }
    public int? NumberFailed { get; set; }
    public DateTime? FileCreatedTimestamp { get; set; }
    public DateTime SessionTimestamp { get; set; }
  }
}
