﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace HereSharedTypes.Models
{
  public partial class EventInfo : ModelBase
  {
    public static List<EventInfo> GetEvents(DateTime start, DateTime end)
    {
      List<EventInfo> result = null;
      string query = "SELECT event_id, version, type, subtype, primary_road, cross_road, " +
        "lane_blocked, latitude, longitude, end_latitude, end_longitude, " +
        "start_time, end_time, modified_date " +
        "FROM unscheduled_event " +
        "WHERE modified_date >= @start AND modified_date< @end " +
        "ORDER BY modified_date";

      try
      {
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@start", start);
          cmd.Parameters.AddWithValue("@end", end);

          conn.Open();

          SqlDataReader rdr = cmd.ExecuteReader();
          if (rdr.HasRows)
          {
            result = new List<EventInfo>();
            while(rdr.Read())
            {
              result.Add(new EventInfo()
              {
                EventId = rdr.GetInt32(0),
                Version = rdr.GetInt32(1),
                Type = rdr.GetString(2),
                SubType = rdr.GetString(3),
                PrimaryRoad = rdr.IsDBNull(4) ? null : rdr.GetString(4),
                CrossRoad = rdr.IsDBNull(5) ? null : rdr.GetString(5),
                LaneBlocked = rdr.IsDBNull(6) ? null : rdr.GetString(6),
                Latitude = rdr.IsDBNull(7) ? (decimal?)null : rdr.GetDecimal(7),
                Longitude = rdr.IsDBNull(8) ? (decimal?)null : rdr.GetDecimal(8),
                EndLatitude = rdr.IsDBNull(9) ? (decimal?)null : rdr.GetDecimal(9),
                EndLongitude = rdr.IsDBNull(10) ? (decimal?)null : rdr.GetDecimal(10),
                StartTime = rdr.IsDBNull(11) ? (DateTime?)null : rdr.GetDateTime(11),
                EndTime = rdr.IsDBNull(12) ? (DateTime?)null : rdr.GetDateTime(12),
                ModifiedDate = rdr.GetDateTime(13)
              });
            }
          }

          conn.Close();
        }
      }
      catch(Exception ex)
      {
        LogException("EventInfo", "GetEvents", ex);
        throw ex;
      }

      return result;
    }
  }
}
