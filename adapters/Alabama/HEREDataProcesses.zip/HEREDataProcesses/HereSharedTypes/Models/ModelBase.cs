﻿using System;
using System.Configuration;

using NLog;

namespace HereSharedTypes.Models
{
  public class ModelBase
  {
    protected static string _connString;
    protected static Logger _slog;
    protected Logger _log;

    static ModelBase()
    {

      _slog = LogManager.GetLogger("ModelBase");

      _connString = ConfigurationManager.ConnectionStrings["model"].ConnectionString;
      if (_connString == null)
        throw new Exception("Required connection string, local, was not found in configuration.");
    }

    protected static void LogException(string model, string location, Exception ex)
    {
      _slog.Error($"{model}.{location} - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      if (ex.InnerException != null)
        LogException(model, "InnerException", ex.InnerException);
    }

    public ModelBase()
    {
      _log = LogManager.GetLogger(this.GetType().Name);
    }

    protected void LogException(string location, Exception ex)
    {
      _log.Error($"{location} - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      if (ex.InnerException != null)
        LogException("Inner Exception", ex.InnerException);
    }
  }
}
