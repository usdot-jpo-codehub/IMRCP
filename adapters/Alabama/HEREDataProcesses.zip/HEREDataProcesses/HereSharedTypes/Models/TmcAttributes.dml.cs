﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CAPS.Utility.GIS.Geometry;

namespace HereSharedTypes.Models
{
  public partial class TmcAttributes : ModelBase
  {
    public static async Task<bool> ExistsAsync(string linear, string pointDesc)
    {
      bool result = false;
      string query = "SELECT COUNT(*) " +
        "FROM TMC_ATTR_CURRENT " +
        "WHERE POINT_DESC = @pointDesc AND PRIMARY_LINEAR = @linear";

      try
      {
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@pointDesc", pointDesc);
          cmd.Parameters.AddWithValue("@linear", linear);

          conn.Open();

          result = (int)(await cmd.ExecuteScalarAsync()) > 0;

          conn.Close();
        }
      }
      catch(Exception ex)
      {
        throw ex;
      }

      return result;
    }

    public static async Task<TmcAttributes> GetAsync(string linear, string pointDesc)
    {
      TmcAttributes result = null;
      string query = "SELECT a.OBJECTID, a.TMC, a.POINT_DESC, a.ROAD_NUM, " +
        "CAST(a.TMC_LENGTH AS FLOAT), a.PRIMARY_LINEAR, g.Shape " +
        "FROM TMC_ATTR_CURRENT a " +
        "LEFT OUTER JOIN TMC_SHAPES_CURRENT g ON a.TMC = g.TMC " +
        "WHERE a.POINT_DESC = @pointDesc AND a.PRIMARY_LINEAR = @linear";

      try
      {
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@pointDesc", pointDesc);
          cmd.Parameters.AddWithValue("@linear", linear);

          conn.Open();

          SqlDataReader rdr = await cmd.ExecuteReaderAsync();
          if (rdr.Read())
          {
            result = new TmcAttributes()
            {
              ObjectId = rdr.GetInt32(0),
              Tmc = rdr.GetString(1),
              PointDesc = rdr.IsDBNull(2) ? null : rdr.GetString(2),
              RoadNum = rdr.IsDBNull(3) ? null : rdr.GetString(3),
              TmcLength = rdr.GetDouble(4),
              PrimaryLinear = rdr.GetString(5)
            };

            if (!rdr.IsDBNull(6))
            {
              byte[] buffer = new byte[8 * 1024];
              long bufferCount = 0;
              bufferCount = rdr.GetBytes(6, 0, buffer, 0, buffer.Length);
              byte[] rawShape = new byte[bufferCount];
              Array.Copy(buffer, 0, rawShape, 0, bufferCount);

              result.Shape = GisGeometry.FromBytes(rawShape);
            }
          }

          conn.Close();
        }
      }
      catch(Exception ex)
      {
        LogException("TmcAttributes", "GetAsync(string,string)", ex);
        throw ex;
      }

      return result;
    }

    public static async Task<TmcAttributes> GetAsync(string tmc)
    {
      TmcAttributes result = null;
      string query = "SELECT a.OBJECTID, a.TMC, a.POINT_DESC, a.ROAD_NUM, " +
        "CAST(a.TMC_LENGTH AS FLOAT), a.PRIMARY_LINEAR, g.Shape " +
        "FROM TMC_ATTR_CURRENT a " +
        "LEFT OUTER JOIN TMC_SHAPES_CURRENT g ON a.TMC = g.TMC " +
        "WHERE a.TMC = @tmc";

      try
      {
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@tmc", tmc);

          conn.Open();

          SqlDataReader rdr = await cmd.ExecuteReaderAsync();
          if (rdr.Read())
          {
            result = new TmcAttributes()
            {
              ObjectId = rdr.GetInt32(0),
              Tmc = rdr.GetString(1),
              PointDesc = rdr.IsDBNull(2) ? null : rdr.GetString(2),
              RoadNum = rdr.IsDBNull(3) ? null : rdr.GetString(3),
              TmcLength = rdr.GetDouble(4),
              PrimaryLinear = rdr.GetString(5)
            };

            if (!rdr.IsDBNull(6))
            {
              byte[] buffer = new byte[8 * 1024];
              long bufferCount = 0;
              bufferCount = rdr.GetBytes(6, 0, buffer, 0, buffer.Length);
              byte[] rawShape = new byte[bufferCount];
              Array.Copy(buffer, 0, rawShape, 0, bufferCount);

              result.Shape = GisGeometry.FromBytes(rawShape);
            }
          }

          conn.Close();
        }
      }
      catch (Exception ex)
      {
        LogException("TmcAttributes", "GetAsync(string)", ex);
        throw ex;
      }

      return result;
    }
  }
}
