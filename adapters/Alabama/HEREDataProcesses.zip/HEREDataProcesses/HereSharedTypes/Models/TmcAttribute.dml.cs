﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HereSharedTypes.Models
{
  public partial class TmcAttribute : ModelBase
  {
    public static List<TmcAttribute> GetTmcAttributes()
    {
      List<TmcAttribute> result = null;

      string query = "SELECT OBJECTID, TMC, ADMIN1, ADMIN2, ADMIN3, ADMIN4, ADMIN5, " +
        "POINT_DESC, ROAD_NAME, ROAD_NUM, LINEAR, PARENT_LIN, POS_OFF, NEG_OFF, " +
        "ROAD_DIR, TMC_ORDER, TMC_TYPE, CAST(START_LAT AS DECIMAL(10,6)), CAST(START_LON AS DECIMAL(10,6)), " +
        "CAST(END_LAT AS DECIMAL(10,6)), CAST(END_LON AS DECIMAL(10,6)), CAST(TMC_LENGTH AS DECIMAL(10,6)), " +
        "PRIMARY_LINEAR " +
        "FROM TMC_ATTR_CURRENT";

      try
      {
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);

          conn.Open();

          SqlDataReader rdr = cmd.ExecuteReader();
          if (rdr.HasRows)
          {
            result = new List<TmcAttribute>();
            while(rdr.Read())
            {
              result.Add(new TmcAttribute()
              {
                ObjectId = rdr.GetInt32(0),
                Tmc = rdr.GetString(1),
                Admin1 = rdr.GetString(2),
                Admin2 = rdr.GetString(3),
                Admin3 = rdr.GetString(4),
                Admin4 = rdr.GetString(5),
                Admin5 = rdr.GetString(6),
                PointDesc = rdr.GetString(7),
                RoadName = rdr.GetString(8),
                RoadNum = rdr.GetString(9),
                Linear = rdr.GetString(10),
                ParentLin = rdr.GetString(11),
                PosOff = rdr.GetString(12),
                NegOff = rdr.GetString(13),
                RoadDir = rdr.GetString(14),
                TmcOrder = rdr.GetInt16(15),
                TmcType = rdr.GetString(16),
                StartLat = rdr.GetDecimal(17),
                StartLon = rdr.GetDecimal(18),
                EndLat = rdr.GetDecimal(19),
                EndLon = rdr.GetDecimal(20),
                TmcLength = rdr.GetDecimal(21),
                PrimaryLinear = rdr.GetString(22)
              });
            }
          }

          conn.Close();
        }
      }
      catch(Exception ex)
      {
        throw ex;
      }

      return result;
    }

    public static TmcAttribute GetTmcAttribute(string tmc)
    {
      TmcAttribute result = null;

      string query = "SELECT OBJECTID, TMC, ADMIN1, ADMIN2, ADMIN3, ADMIN4, ADMIN5, " +
        "POINT_DESC, ROAD_NAME, ROAD_NUM, LINEAR, PARENT_LIN, POS_OFF, NEG_OFF, " +
        "ROAD_DIR, TMC_ORDER, TMC_TYPE, CAST(START_LAT AS DECIMAL(10,6)), CAST(START_LON AS DECIMAL(10,6)), " +
        "CAST(END_LAT AS DECIMAL(10,6)), CAST(END_LON AS DECIMAL(10,6)), CAST(TMC_LENGTH AS DECIMAL(10,6)), " +
        "PRIMARY_LINEAR " +
        "FROM TMC_ATTR_CURRENT " +
        "WHERE TMC = @tmc";

      try
      {
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);

          conn.Open();

          SqlDataReader rdr = cmd.ExecuteReader();
          if (rdr.HasRows)
          {
            if (rdr.Read())
            {
              result = new TmcAttribute()
              {
                ObjectId = rdr.GetInt32(0),
                Tmc = rdr.GetString(1),
                Admin1 = rdr.GetString(2),
                Admin2 = rdr.GetString(3),
                Admin3 = rdr.GetString(4),
                Admin4 = rdr.GetString(5),
                Admin5 = rdr.GetString(6),
                PointDesc = rdr.GetString(7),
                RoadName = rdr.GetString(8),
                RoadNum = rdr.GetString(9),
                Linear = rdr.GetString(10),
                ParentLin = rdr.GetString(11),
                PosOff = rdr.GetString(12),
                NegOff = rdr.GetString(13),
                RoadDir = rdr.GetString(14),
                TmcOrder = rdr.GetInt16(15),
                TmcType = rdr.GetString(16),
                StartLat = rdr.GetDecimal(17),
                StartLon = rdr.GetDecimal(18),
                EndLat = rdr.GetDecimal(19),
                EndLon = rdr.GetDecimal(20),
                TmcLength = rdr.GetDecimal(21),
                PrimaryLinear = rdr.GetString(22)
              };
            }
          }

          conn.Close();
        }
      }
      catch (Exception ex)
      {
        throw ex;
      }

      return result;
    }
  }
}
