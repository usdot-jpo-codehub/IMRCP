﻿using System;

namespace HereSharedTypes.Models
{
  public partial class EventInfo : ModelBase
  {
    public int EventId { get; set; }
    public int Version { get; set; }
    public string Type { get; set; }
    public string SubType { get; set; }
    public string PrimaryRoad { get; set; }
    public string CrossRoad { get; set; }
    public string LaneBlocked { get; set; }
    public int LaneBlockedCount
    {
      get
      {
        int result = 0;
        if (LaneBlocked != null)
        {
          for (int i = 0; i < LaneBlocked.Length; i++)
            if (LaneBlocked[i] != 'o')
              result++;
        }

        return result;
      }
    }
    public decimal? Latitude { get; set; }
    public decimal? Longitude { get; set; }
    public decimal? EndLatitude { get; set; }
    public decimal? EndLongitude { get; set; }
    public DateTime? StartTime { get; set; }
    public DateTime? EndTime { get; set; }
    public DateTime ModifiedDate { get; set; }

    public static string ExportHeaders
    {
      get
      {
        return "\"id\"|" +
          "\"event_type\"|" +
          "\"description\"|" +
          "\"start_time (UTC)\"|" +
          "\"end_time (UTC)\"|" +
          "\"update_time (UTC)\"|" +
          "\"lanes_affected\"|" +
          "\"speed_limit\"|" +
          "\"location ([lon,lat],...)\"";
      }
    }

    public string ToExport()
    {
      string startLoc = Longitude.HasValue && Latitude.HasValue
        ? $"[{Longitude.Value.ToString("0.000000")},{Latitude.Value.ToString("0.000000")}]"
        : null;
      string endLoc = EndLongitude.HasValue && EndLatitude.HasValue
        ? $"[{EndLongitude.Value.ToString("0.000000")},{EndLatitude.Value.ToString("0.000000")}]"
        : null;
      string location = startLoc;
      if (location != null && endLoc != null)
        location += $",{endLoc}";

      string result =
        $"\"{EventId}.{Version}\"|" +
        $"\"{Type}/{SubType}\"|" +
        $"\"{PrimaryRoad} & {CrossRoad}\"|" +
        $"{(StartTime.HasValue ? StartTime.Value.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss") : "")}|" +
        $"{(EndTime.HasValue ? EndTime.Value.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss") : "")}|" +
        $"{ModifiedDate.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss")}|" +
        $"{LaneBlockedCount}|" +
        $"|" + //speed limit n/a
        $"{location}";

      return result;
    }
  }
}
