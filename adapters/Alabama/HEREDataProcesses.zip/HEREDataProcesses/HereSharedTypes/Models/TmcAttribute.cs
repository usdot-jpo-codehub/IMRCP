﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HereSharedTypes.Models
{
  public partial class TmcAttribute : ModelBase
  {
    public int ObjectId { get; set; }
    public string Tmc { get; set; }
    public string Admin1 { get; set; }
    public string Admin2 { get; set; }
    public string Admin3 { get; set; }
    public string Admin4 { get; set; }
    public string Admin5 { get; set; }
    public string PointDesc { get; set; }
    public string RoadName { get; set; }
    public string RoadNum { get; set; }
    public string Linear { get; set; }
    public string ParentLin { get; set; }
    public string PosOff { get; set; }
    public string NegOff { get; set; }
    public string RoadDir { get; set; }
    public short TmcOrder { get; set; }
    public string TmcType { get; set; }
    public decimal StartLat { get; set; }
    public decimal StartLon { get; set; }
    public decimal EndLat { get; set; }
    public decimal EndLon { get; set; }
    public decimal TmcLength { get; set; }
    public string PrimaryLinear { get; set; }
  }
}
