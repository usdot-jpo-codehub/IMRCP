﻿using CAPS.Utility.GIS.Geometry;

namespace HereSharedTypes.Models
{
  public partial class TmcAttributes : ModelBase
  {
    public int ObjectId { get; set; }
    public string Tmc { get; set; }
    public string PointDesc { get; set; }
    public string RoadNum { get; set; }
    public double TmcLength { get; set; }
    public string PrimaryLinear { get; set; }
    public GisGeometry Shape { get; set; }
  }
}
