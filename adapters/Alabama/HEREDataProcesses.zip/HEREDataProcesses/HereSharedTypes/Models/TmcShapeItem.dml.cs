﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CAPS.Utility.GIS.Geometry;

namespace HereSharedTypes.Models
{
  public partial class TmcShapeItem : ModelBase
  {
    public bool Create()
    {
      bool result = false;

      string query = $"INSERT INTO TMC_SHAPES_CURRENT " +
        "VALUES (@objectId, @tmc, @shape)";

      try
      {
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@objectId", this.ObjectId);
          cmd.Parameters.AddWithValue("@tmc", this.Tmc);
          cmd.Parameters.AddWithValue("@shape", this.Shape.ToBinary());

          conn.Open();

          result = cmd.ExecuteNonQuery() > 0;

          conn.Close();
        }
      }
      catch(Exception ex)
      {
        LogException("Create", ex);
        throw ex;
      }

      return result;
    }
  }
}
