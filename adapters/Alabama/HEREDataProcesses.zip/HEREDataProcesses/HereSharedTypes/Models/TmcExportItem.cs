﻿using System;
using System.Collections.Generic;

namespace HereSharedTypes.Models
{
  public partial class TmcExportItem : ModelBase
  {
    private static readonly decimal KM_PER_MILE = 1.609344m;

    public string id { get; set; }
    public string description { get; set; }
    public bool subsegment { get; set; }
    public DateTime? start_time { get; set; }
    public DateTime? end_time { get; set; }
    public Decimal? speed { get; set; }
    public Decimal? length { get; set; }
    public int? volume { get; set; }
    public int? occupancy { get; set; }
    public List<double[]> location { get; set; }

    public override string ToString()
    {
      string sloc = null, result = null;

      if (location != null)
      {
        foreach (double[] pt in location)
        {
          if (sloc != null)
            sloc += ",";
          sloc += $"[{pt[0].ToString("###.000000")},{pt[1].ToString("###.000000")}]";
        }
      }

      result = $"\"{this.id}\"|" +
        $"\"{this.description}\"|" +
        $"{this.start_time.Value.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss")}|" +
        $"{this.end_time.Value.ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ss")}|" +
        $"{(this.speed.HasValue ? (this.speed.Value * KM_PER_MILE).ToString("##.0") : string.Empty)}|" +
        $"{(this.volume.HasValue ? this.volume.Value.ToString() : string.Empty)}|" +
        $"{(this.occupancy.HasValue ? this.occupancy.Value.ToString("##.0") : string.Empty)}|" +
        $"{sloc}";

      return result;
    }
  }
}
