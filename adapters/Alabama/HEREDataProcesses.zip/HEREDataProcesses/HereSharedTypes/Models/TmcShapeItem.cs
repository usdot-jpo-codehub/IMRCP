﻿using CAPS.Utility.GIS.Geometry;

namespace HereSharedTypes.Models
{
  public partial class TmcShapeItem : ModelBase
  {
    public int ObjectId { get; set; }
    public string Tmc { get; set; }
    public GisGeometry Shape { get; set; }
  }
}
