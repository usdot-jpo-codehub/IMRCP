﻿using CAPS.Utility.GIS.Geometry;

namespace HereSharedTypes.Models
{
  public partial class TmcGeoItem : ModelBase
  {
    public int ObjectId { get; set; }
    public string Tmc { get; set; }
    public int LinkId { get; set; }
    public string DirTravel { get; set; }
    public string Contracc { get; set; }
    public short FunClass { get; set; }
    public GisGeometry Shape { get; set; }
    public byte[] GdbGeomAttrData { get; set; }

  }
}
