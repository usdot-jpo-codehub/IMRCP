﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace HereSharedTypes.Models
{
  public partial class FileProcessLogItem : ModelBase
  {
    public static List<FileProcessLogItem> GetLatestSession()
    {
      List<FileProcessLogItem> result = null;
      string query = "SELECT Id, PackageName, FileName, ArchiveLocation, " +
        "DownloadDate, ExtractionDate, ProcessDate, ArchiveDate, " +
        "NumberProcessed, NumberFailed, FileCreatedTimestamp, " +
        "SessionTimestamp " +
        "FROM FileProcessLogItems " +
        "WHERE SessionTimestamp = " +
        "(SELECT TOP 1 SessionTimestamp " +
        "FROM FileProcessLogItems " +
        "WHERE ProcessDate IS NOT NULL " +
        "ORDER BY SessionTimestamp DESC)";

      try
      {
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);

          conn.Open();

          SqlDataReader rdr = cmd.ExecuteReader();
          if (rdr.HasRows)
          {
            result = new List<FileProcessLogItem>();
            while(rdr.Read())
            {
              result.Add(new FileProcessLogItem()
              {
                Id = rdr.GetInt32(0),
                PackageName = rdr.GetString(1),
                FileName = rdr.GetString(2),
                ArchiveLocation = rdr.GetString(3),
                DownloadDate = rdr.GetDateTime(4),
                ExtractionDate = rdr.IsDBNull(5) ? (DateTime?)null : rdr.GetDateTime(5),
                ProcessDate = rdr.IsDBNull(6) ? (DateTime?)null : rdr.GetDateTime(6),
                ArchiveDate = rdr.IsDBNull(7) ? (DateTime?)null : rdr.GetDateTime(7),
                NumberProcessed = rdr.IsDBNull(8) ? (int?)null : rdr.GetInt32(8),
                NumberFailed = rdr.IsDBNull(9) ? (int?)null : rdr.GetInt32(9),
                FileCreatedTimestamp = rdr.IsDBNull(10) ? (DateTime?)null : rdr.GetDateTime(10),
                SessionTimestamp = rdr.GetDateTime(11)
              });
            }
          }

          conn.Close();
        }
      }
      catch(Exception ex)
      {
        LogException("FileProcessLogItem.dml", "GetLatestSEssion", ex);
        throw ex;
      }

      return result;
    }

    public static List<FileProcessLogItem> GetPackageIdsFromTimestamp(DateTime timestamp)
    {
      List<FileProcessLogItem> result = null;
      string query = "SELECT Id, SessionTimestamp " +
        "FROM FileProcessLogItems " +
        "WHERE SessionTimestamp = " +
        "(SELECT TOP 1 SessionTimestamp FROM FileProcessLogItems " +
        "WHERE ProcessDate IS NOT NULL AND SessionTimestamp > @timestamp " +
        "ORDER BY SessionTimestamp)";

      try
      {
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@timestamp", timestamp);

          conn.Open();

          SqlDataReader rdr = cmd.ExecuteReader();
          if (rdr.HasRows)
          {
            result = new List<FileProcessLogItem>();
            while (rdr.Read())
            {
              result.Add(new FileProcessLogItem()
              {
                Id = rdr.GetInt32(0),
                SessionTimestamp = rdr.GetDateTime(1)
              });
            }
          }

          conn.Close();
        }
      }
      catch(Exception ex)
      {
        LogException("FileProcessLigItem.dml", "GetPackageIdsFromTimestamp", ex);
        throw ex;
      }

      return result;
    }
  }
}
