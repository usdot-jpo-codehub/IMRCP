﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CAPS.Utility.GIS.Geometry;

namespace HereSharedTypes.Models
{
  public partial class TmcGeoItem : ModelBase
  {
    public static List<TmcGeoItem> GetTmcGeoItems(string tmc)
    {
      List<TmcGeoItem> result = null;
      string sourceDataTable = ConfigurationManager.AppSettings["source-geo-table"];
      string query = "SELECT OBJECTID, TMC, LINK_ID, DIR_TRAVEL, CONTRACC, FUNCLASS, Shape " +
        $"FROM {sourceDataTable} " +
        "WHERE TMC = @tmc";

      try
      {
        if (sourceDataTable == null)
          throw new Exception("Required configuration setting, source-geo-table, was not found");

        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@tmc", tmc);

          conn.Open();

          SqlDataReader rdr = cmd.ExecuteReader();
          if (rdr.HasRows)
          {
            result = new List<TmcGeoItem>();
            while(rdr.Read())
            {
              TmcGeoItem item = new TmcGeoItem()
              {
                ObjectId = rdr.GetInt32(0),
                Tmc = rdr.GetString(1),
                LinkId = rdr.GetInt32(2),
                DirTravel = rdr.GetString(3),
                Contracc = rdr.GetString(4),
                FunClass = rdr.GetInt16(5)
              };

              if (!rdr.IsDBNull(6))
              {
                byte[] buffer = new byte[64 * 1024];
                long bufferCount = 0;
                bufferCount = rdr.GetBytes(6, 0, buffer, 0, buffer.Length);
                byte[] rawShape = new byte[bufferCount];
                Array.Copy(buffer, 0, rawShape, 0, bufferCount);

                item.Shape = GisGeometry.FromBytes(rawShape);
              }

              result.Add(item);
            }
          }

          conn.Close();
        }

      }
      catch(Exception ex)
      {
        LogException("TmcGeoItem", "GetTmcGeoItems", ex);
        throw ex;
      }

      return result;
    }

    public bool Create()
    {
      bool result = false;
      string destDataTable = ConfigurationManager.AppSettings["dest-geo-table"];
      string query = $"INSERT INTO {destDataTable} (OBJECTID, TMC, LINK_ID, DIR_TRAVEL, CONTRACC, FUNCLASS, SHAPE) " +
        $"VALUES " +
        $"(@objectId, @tmc, @linkId, @dirTravel, @contracc, @funClass, @shape)";

      try
      {
        if (destDataTable == null)
          throw new Exception("Required configuration setting, dest-geo-table, was not found");

        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);
          cmd.Parameters.AddWithValue("@objectId", this.ObjectId);
          cmd.Parameters.AddWithValue("@tmc", this.Tmc);
          cmd.Parameters.AddWithValue("@linkId", this.LinkId);
          cmd.Parameters.AddWithValue("@dirTravel", this.DirTravel);
          cmd.Parameters.AddWithValue("@contracc", this.Contracc);
          cmd.Parameters.AddWithValue("@funClass", this.FunClass);
          cmd.Parameters.AddWithValue("@shape", this.Shape.ToBinary());
          //cmd.Parameters.AddWithValue("@null", DBNull.Value);

          conn.Open();

          result = cmd.ExecuteNonQuery() > 0;

          conn.Close();
        }
      }
      catch (Exception ex)
      {
        LogException("Create", ex);
        throw ex;
      }

      return result;
    }
  }
}
