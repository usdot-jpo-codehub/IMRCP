﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

using NLog;

namespace HERE.Congestion
{
  class Program
  {
    private static Logger _log = LogManager.GetLogger("Main");
    private static string _connString;

    static void Main(string[] args)
    {
      DateTime maxDate, minDate, startTime = DateTime.Now;
      int daysToProcess;
      string msg;

      try
      {
        _connString = ConfigurationManager.ConnectionStrings["default"].ConnectionString;
        if (_connString == null)
          throw new Exception($"Configuration connection string, \"default\", is missing");

        string s = ConfigurationManager.AppSettings["max-date"];
        if (s == null || !DateTime.TryParse(s, out maxDate))
          throw new Exception($"Configuration setting, max-date, was missing or invalid: {s}");
        s = null;
        s = ConfigurationManager.AppSettings["min-date"];
        if (s == null || !DateTime.TryParse(s, out minDate))
          throw new Exception($"Configuration setting, min-date, was missing or invalid: {s}");
        s = null;
        s = ConfigurationManager.AppSettings["days-to-process"];
        if (s == null || !int.TryParse(s, out daysToProcess))
          throw new Exception($"Configuration setting, days-to-process, is missing or invalid: {s}");

        DateTime targetDate = maxDate;
        int daysProcessed = 0;
        int count = 0;

        string query = "SELECT MIN(RecordDate) FROM SegmentCongestion";
        using (SqlConnection conn = new SqlConnection(_connString))
        {
          SqlCommand cmd = new SqlCommand(query, conn);

          conn.Open();

          SqlDataReader rdr = cmd.ExecuteReader();
          if (rdr.HasRows)
          {
            DateTime? d = null;

            if (rdr.Read())
              d = rdr.IsDBNull(0) ? (DateTime?)null : rdr.GetDateTime(0);

            if (d.HasValue)
              targetDate = d.Value.AddDays(-1);
          }

          conn.Close();
        }

        _log.Info(new String('=', 40));
        _log.Info($"Starting segment congestion process for {daysToProcess} days beginng with {targetDate.ToString()}");

        while (daysProcessed < daysToProcess && targetDate >= minDate)
        {
          msg = $"Starting process for {targetDate.ToString()}";
          _log.Info(msg);
          Console.WriteLine(msg);

          using (SqlConnection conn = new SqlConnection(_connString))
          {
            SqlCommand cmd = new SqlCommand("DailySegmentCongestion", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandTimeout = 120;
            cmd.Parameters.AddWithValue("@start", targetDate);

            conn.Open();

            count = cmd.ExecuteNonQuery();

            conn.Close();
          }

          msg = $"{count} records added for {targetDate.ToString()}";
          _log.Info(msg);
          Console.WriteLine(msg);

          targetDate = targetDate.AddDays(-1);
          daysProcessed++;
        }

        _log.Info($"Finishing segment congestion process, elapsed: {DateTime.Now - startTime}");
        _log.Info(new string('=', 40));
      }
      catch (Exception ex)
      {
        msg = $"{ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}";
        _log.Error(msg);
        Console.WriteLine(msg);
      }
    }
  }
}
