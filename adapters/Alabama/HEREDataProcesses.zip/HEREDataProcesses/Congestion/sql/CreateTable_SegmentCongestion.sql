﻿IF EXISTS (SELECT * FROM sys.objects WHERE name = 'SegmentCongestion' AND type = 'U')
  DROP TABLE SegmentCongestion

CREATE TABLE SegmentCongestion
(
  ID INT IDENTITY,
  SegmentID INT NOT NULL,
  SegmentDescription VARCHAR(32) NOT NULL,
  SegmentDirection VARCHAR(16) NOT NULL,
  RecordDate DATETIME NOT NULL,
  HourOfDay INT NOT NULL,
  AvgSpeedDiff FLOAT NOT NULL,
  CONSTRAINT SegmentCongestion_ID_pk PRIMARY KEY (ID)
)