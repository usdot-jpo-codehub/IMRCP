﻿IF EXISTS (SELECT * FROM sys.objects WHERE name = 'DailySegmentCongestion' AND type = 'P')
  DROP PROCEDURE DailySegmentCongestion

GO

CREATE PROCEDURE DailySegmentCongestion
(
  @start DATETIME
)
AS
BEGIN
  DECLARE @stop DATETIME
  SET @stop = DATEADD(DAY, 1, @start)

  INSERT INTO SegmentCongestion (SegmentId, SegmentDescription, SegmentDirection, RecordDate, HourOfDay, AvgSpeedDiff)
  SELECT h.GeometryId, t.POINT_DESC, t.ROAD_DIR, @start, DATEPART(HOUR, h.RW_PBT),
    AVG(h.CurrentSegmentFF - h.CurrentSegmentSpeed)
  FROM RouteSpeedHistory h WITH (NOLOCK)
    JOIN TargetTmcs t ON h.GeometryId = t.IrgId
  WHERE h.RW_PBT >= @start AND h.RW_PBT < @stop
   GROUP BY h.GeometryId, t.POINT_DESC, t.ROAD_DIR, DATEPART(HOUR, h.RW_PBT)
   ORDER BY h.GeometryId, t.POINT_DESC, t.ROAD_DIR, DATEPART(HOUR, h.RW_PBT)
END

GO

GRANT EXECUTE ON DailySegmentCongestion TO hereDataSvc
