﻿SELECT a.TMC, g.Id IrgID, g.SequenceId, g.SequenceOrder, g.ROAD_NUM, g.ROAD_DIR, g.PRIMARY_LINEAR, g.POINT_DESC,
	g.TMC_ORDER, g.GeometryLength, g.MeasureAscending, g.MeasureFrom, g.MeasureTo 
	INTO TargetTMCs
	FROM InterstateRouteGeometry g
		JOIN TMC_ATTR_2 a ON g.ROAD_NUM = a.ROAD_NUM AND g.ROAD_DIR = a.ROAD_DIR AND g.POINT_DESC = a.POINT_DESC 
	WHERE g.ROAD_NUM = 'I-65' AND ParentId IS NULL
		AND ((MeasureAscending = 1 AND MeasureFrom < @end AND MeasureTo > @start)
			OR (MeasureAscending = 0 AND MeasureFrom >@start AND MeasureTo < @end))
