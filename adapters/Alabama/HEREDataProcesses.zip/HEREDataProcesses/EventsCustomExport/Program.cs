﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

using NLog;
using ICSharpCode.SharpZipLib.GZip;

using HereSharedTypes.Models;

namespace EventsCustomExport
{
  class Program
  {
    private class DateRange
    {
      public DateTime Start { get; set; }
      public DateTime End { get; set; }
    }

    private static Logger _log;
    private static readonly string CURRENT_VERSION_HEADER = "\"Version 1.0\"";
    private static int _sessionDuration = 1;
    private static string HDR_SRC_FILE_NAME = "X-Src-FileName";
    private static string HDR_SRC_FILE_TIME = "X-Src-FileTime";

    static void Main(string[] args)
    {
      int processed = 0;
      string uploadUrl;
      string destFilePath, archivePath;

      _log = LogManager.GetLogger("Events-Main");

      try
      {
        string s = ConfigurationManager.AppSettings["session-duration-hours"];
        if (!string.IsNullOrEmpty(s))
          if (!int.TryParse(s, out _sessionDuration))
            throw new Exception("Configuration setting, session-duration-hours, is not valid");

        uploadUrl = ConfigurationManager.AppSettings["file-upload-url"];
        if (string.IsNullOrEmpty(uploadUrl))
          throw new Exception("Required configuration setting, file-upload-url, was not found");

        destFilePath = ConfigurationManager.AppSettings["output-file-path"];
        if (string.IsNullOrEmpty(destFilePath))
          throw new Exception("Required configuration setting, output-file-path, was not found");

        archivePath = ConfigurationManager.AppSettings["archive-path"];
        if (string.IsNullOrEmpty(archivePath))
          throw new Exception("Required configuration setting, archive-path, was not found");

        DateRange dateRange = GetDateRange(args);
        DateTime sessionStart = dateRange.Start,
          sessionEnd = sessionStart.AddHours(_sessionDuration);

        while (sessionEnd <= dateRange.End)
        {
          _log.Info($"Starting event export process for " +
            $"{sessionStart.ToString()} - {sessionEnd.ToString()}\r\n{new string('=', 40)}");

          string tempFileName = "temp-out.txt";
          string destFileName;
          DateTime minStart = DateTime.MaxValue,
            maxEnd = DateTime.MinValue;

          List<EventInfo> data = EventInfo.GetEvents(sessionStart, sessionEnd);

          if (data != null && data.Count > 0)
          {
            using (FileStream output =
              new FileStream(Path.Combine(destFilePath, tempFileName), FileMode.Create, FileAccess.Write))
            {
              StreamWriter writer = new StreamWriter(output);
              writer.WriteLine(CURRENT_VERSION_HEADER);
              writer.WriteLine(EventInfo.ExportHeaders);

              foreach (EventInfo info in data)
              {
                if (info.StartTime.HasValue && info.StartTime < minStart)
                  minStart = info.StartTime.Value;
                if (info.EndTime.HasValue && info.EndTime > maxEnd)
                  maxEnd = info.EndTime.Value;

                writer.WriteLine(info.ToExport());
                processed++;
              }

              writer.Flush();
              writer.Close();
              output.Close();
            }

            destFileName = $"aldot_event_" +
              $"{minStart.ToUniversalTime().ToString("yyyyMMddHHmm")}_" +
              $"{maxEnd.ToUniversalTime().ToString("yyyyMMddHHmm")}_" +
              $"{sessionEnd.ToUniversalTime().ToString("yyyyMMddHHmm")}.txt";

            string src = Path.Combine(destFilePath, tempFileName),
              dest = Path.Combine(destFilePath, destFileName),
              zipped = $"{dest}.gz";
            File.Move(src, dest);

            using (FileStream input = new FileStream(dest, FileMode.Open, FileAccess.Read))
            {
              using (FileStream output = new FileStream(zipped, FileMode.Create, FileAccess.Write))
              {
                GZip.Compress(input, output, true);
              }
            }

            string archiveFileName, archiveFilePath = Path.Combine(archivePath,
              $"{sessionStart.Year.ToString("0000")}{sessionStart.Month.ToString("00")}",
              $"{sessionStart.Year.ToString("0000")}{sessionStart.Month.ToString("00")}{sessionStart.Day.ToString("00")}");
            if (!Directory.Exists(archiveFilePath))
              Directory.CreateDirectory(archiveFilePath);

            archiveFileName = Path.Combine(archiveFilePath, Path.GetFileName(zipped));
            File.Copy(zipped, archiveFileName);

            //using (HttpClient client = new HttpClient(new EventsWebRequestHandler()))
            //{
            //  using (FileStream fs = new FileStream(zipped, FileMode.Open, FileAccess.Read))
            //  {
            //    StreamContent content = new StreamContent(fs);

            //    content.Headers.Add(HDR_SRC_FILE_NAME, Path.GetFileName(zipped));
            //    content.Headers.Add(HDR_SRC_FILE_TIME,
            //      File.GetCreationTime(zipped).ToString("MM/dd/yyyy HH:mm:ss"));

            //    HttpResponseMessage resp = client.PostAsync(uploadUrl, content).Result;
            //    if (!resp.IsSuccessStatusCode)
            //    {
            //      string respContent = resp.Content.ReadAsStringAsync().Result;
            //      string msg = $"HTTP error, status code: {resp.StatusCode}, reason: {resp.ReasonPhrase}\r\n" +
            //        $"response content: {respContent}";
            //      _log.Error(msg);

            //      throw new Exception($"HttpClient.PostAsync.Result - {msg}");
            //    }

            //    fs.Close();
            //  }
            //}
          }
          else
          {
            _log.Info("No events were found to process");
          }

          sessionStart = sessionEnd;
          sessionEnd = sessionStart.AddHours(_sessionDuration);
        }
      }
      catch (Exception ex)
      {
        LogException("MainProgram", ex);
        throw ex;
      }
      finally
      {
        _log.Info($"Finishing event export process, processed {processed} records.\r\n{new string('=', 40)}\r\n");
      }
    }

    private static void LogException(string location, Exception ex)
    {
      _log.Error($"{location} - {ex.GetType().Name}: {ex.Message}\r\n{ex.StackTrace}");
      if (ex.InnerException != null)
        LogException("Inner Exception", ex.InnerException);
    }

    private static DateRange GetDateRange(string[] args = null)
    {
      DateRange result = new DateRange();

      if (args.Length > 0)
      {
        DateTime dt;
        if (DateTime.TryParse(args[0], out dt))
        {
          result.Start = dt;
          result.End = dt.AddHours(_sessionDuration);
        }
        else
        {
          throw new Exception($"Start date argument, {args[0]}, is not valid");
        }

        if (args.Length > 1)
        {
          if (DateTime.TryParse(args[1], out dt))
            result.End = dt;
          else
            throw new Exception($"End date argument, {args[1]}, is not valid");
        }
      }
      else
      {
        DateTime now = DateTime.Now;
        result.End = new DateTime(now.Year, now.Month, now.Day, now.Hour, 0, 0);
        result.Start = result.End.AddHours(-_sessionDuration);
      }

      return result;
    }

    private class EventsWebRequestHandler : WebRequestHandler
    {
      public EventsWebRequestHandler()
      {
        this.ServerCertificateValidationCallback = WebRequestCallback;
      }

      private bool WebRequestCallback(
        object sender, X509Certificate certificate, X509Chain chain, SslPolicyErrors sslPolicyErrors)
      {
        return true;
      }

    }

  }
}
